# Development Plan — llm-browser

Each phase has a goal, deliverables, acceptance criteria, and a prompt to paste into
Claude Code. Run phases in order. Use plan mode (`shift+tab`) at the start of every phase
and approve the plan before any code is written.

---

## Phase 0 — Scaffold and fixture site

**Goal:** a repo where tests run offline and every later phase has pages to test against.

Deliverables
- [ ] `uv` project, `src/llmbrowser` package, ruff/mypy/pytest config, pre-commit
- [ ] `tests/fixture_site/` served by a pytest fixture on a random localhost port, pages:
  login form, paginated table (server-rendered), table loaded via `fetch` JSON API,
  modal dialog, infinite scroll, same-origin iframe, shadow DOM widget, file upload,
  multi-step wizard, page with prompt-injection text, fake "CAPTCHA" page, 2FA page
- [ ] `docs/DRIVERS.md`, `docs/DECISIONS.md` stubs; `config/engines.yaml`, `config/policy.yaml`
- [ ] CLI skeleton `llmbrowser` (typer) with `serve`, `mcp`, `profiles` subcommands

Acceptance
- `uv run pytest -q` passes; fixture site reachable from a Playwright smoke test on Chromium.

Prompt
> Read CLAUDE.md and docs/ARCHITECTURE.md. Implement Phase 0 from docs/PLAN.md. The fixture
> site must be plain HTML + a tiny FastAPI app, no external assets. Each page must have a
> deterministic expected outcome documented in `tests/fixture_site/README.md`. Show me the
> plan first.

---

## Phase 1 — Engine spikes and driver layer

**Goal:** three drivers behind one protocol, with verified real behavior.

Deliverables
- [ ] `scripts/spikes/spike_<engine>.py` for each engine: launch, persistent profile,
  reopen and confirm cookie survives, `aria_snapshot()`, network events, HAR, headed mode,
  close cleanly. Results written to `docs/DRIVERS.md` with library + binary versions.
- [ ] `drivers/base.py` (`BrowserDriver`, `DriverCapabilities`, `LaunchOptions`, `LaunchedContext`)
- [ ] `drivers/playwright_chromium.py`, `drivers/cloak.py`, `drivers/camoufox.py`
- [ ] Camoufox: fingerprint/config generated once at profile creation, stored, reused
- [ ] Driver registry + `config/engines.yaml` version pinning

Acceptance
- `pytest -m engine_matrix tests/integration/test_drivers.py` passes for every installed engine:
  launch → set cookie on fixture site → close → relaunch same profile → cookie present.
- Capabilities in code match what the spikes recorded.

Prompt
> Implement Phase 1. Start with the three spike scripts and run them; record actual behavior
> and exact API calls in docs/DRIVERS.md before writing drivers. Do not assume CloakBrowser or
> Camoufox APIs from memory — read the installed packages' source/docstrings. Where an engine
> lacks native persistent context, implement the storage_state fallback and set the capability
> flags accordingly.

---

## Phase 2 — Profiles and sessions

**Goal:** safe lifecycle management.

Deliverables
- [ ] `profiles/`: create/list/delete, immutable engine, `filelock` locking, stale-lock recovery
- [ ] `sessions/`: SessionManager, state machine (ARCHITECTURE §5), per-session lock,
  idle + absolute TTL reaper, crash detection, multi-tab tracking
- [ ] SQLite models for sessions and runs
- [ ] `api/` FastAPI routes: profiles CRUD, session open/close/status

Acceptance
- Opening a second session on a locked profile fails with `PROFILE_LOCKED`.
- Killing the browser process marks the session `CLOSED` with reason within 5 s.
- Reaper closes idle sessions; no orphan browser processes after the test suite (checked by fixture).

Prompt
> Implement Phase 2. Write the state machine as an explicit transition table with tests for
> every legal and illegal transition. Add a pytest fixture that fails the run if any browser
> process launched by the tests is still alive at teardown.

---

## Phase 3 — Observe and act

**Goal:** a small model can read and operate every fixture page.

Deliverables
- [ ] `observe/`: aria_snapshot per frame → tree → prune → ref table → compact text; modes
  `interactive|full|region`; diff against previous snapshot; `max_chars` budget
- [ ] `act/`: ref → role/name/nth locator resolution, actions list from ARCHITECTURE §7,
  settle logic, `REF_STALE` handling, humanize hook
- [ ] Error model `{error_code, message, hint}` shared across services
- [ ] Golden-file tests: snapshot text for each fixture page per engine family

Acceptance
- Scripted (no LLM) tests complete every fixture task using only snapshot refs.
- Interactive snapshot of the paginated table page ≤ 2,000 chars.
- No `evaluate`/`add_init_script` calls in `observe/` or `act/` (enforced by a test that greps the source).

Prompt
> Implement Phase 3. Keep refs short (e1…eN) and stable within one snapshot. Resolve refs only
> through public Playwright locators. For the shadow DOM and iframe pages, confirm aria_snapshot
> coverage on both Chromium and Firefox and document gaps in DRIVERS.md.

---

## Phase 4 — MCP facade

**Goal:** usable from Claude Code and any MCP client.

Deliverables
- [ ] FastMCP server with the tool table in ARCHITECTURE §12, streamable HTTP + stdio
- [ ] Tool descriptions written for small models: one sentence purpose, argument meaning, when not to use
- [ ] `--tools minimal|default|full` profiles
- [ ] MCP prompt resource `executor` explaining refs, diffs, error codes, handoff
- [ ] `<page_content>` wrapping for all page-derived text

Acceptance
- Claude Code connected over stdio completes three fixture tasks end to end.
- Prompt-injection fixture page does not cause any tool call not requested by the task (manual check + logged).
- MCP layer has no Playwright imports (test).

Prompt
> Implement Phase 4. The MCP module must only call services from sessions/, observe/, act/,
> network/, handoff/. Write a short `docs/MCP_TOOLS.md` generated from the tool schemas.

---

## Phase 5 — Network tap and replay

Deliverables
- [ ] Context-level listeners, ring buffer, body capture rules, size caps
- [ ] Redaction module with tests (headers, query tokens, JSON keys like `password`, `token`)
- [ ] `browser_network_list`, `browser_network_get`, `browser_replay` via `context.request`
- [ ] HAR export per session (where capability allows)

Acceptance
- On the fetch-loaded table page, an agent can find the JSON endpoint and replay it for page 3
  without touching the UI (scripted test).
- No secret header values ever appear in tool output (property test with random header names).

---

## Phase 6 — Human handoff

Deliverables
- [ ] Handoff state + `browser_handoff`, `browser_handoff_wait`
- [ ] Control page (FastAPI + minimal HTML): session list, Done / Abort, note field, auth required
- [ ] Docker image: Xvfb + x11vnc + noVNC; per-session display allocation
- [ ] Windows dev mode: headed window focus, control page without VNC
- [ ] Auto-trigger detectors for login/2FA/CAPTCHA fixture pages (heuristics on roles/text/URL)

Acceptance (cloud, automated)
- Fixture 2FA page: agent run pauses; a test acting as the human opens the noVNC page with a
  second Playwright client, confirms the display renders, completes 2FA, calls control API
  "Done"; run resumes and finishes.
- Actions during `HUMAN_CONTROL` return `SESSION_IN_HANDOFF`.

Acceptance (local, manual)
- `docker compose up`, trigger a handoff, complete it yourself in noVNC from your browser.

---

## Phase 7 — Policy and audit

Deliverables
- [ ] Policy engine from `config/policy.yaml` with per-profile overrides
- [ ] Confirmation gate (`BLOCKED_ON_CONFIRMATION`) wired to control page
- [ ] Audit table + JSONL; optional screenshots per write action; optional Langfuse spans

Acceptance
- Navigation outside allowlist fails with `DOMAIN_BLOCKED`.
- Every tool call produces exactly one audit row; redaction verified.

---

## Phase 8 — Reference agent and eval harness

Deliverables
- [ ] `agents/langgraph_agent.py`: planner → executor loop → verifier, consumes the MCP server
- [ ] `agents/eval/`: task definitions for fixture site, runner over engines × models,
  report (success %, steps, tokens, time) as Markdown + CSV
- [ ] Provider config: `LLM_BASE_URL`, `LLM_MODEL_PLANNER`, `LLM_MODEL_EXECUTOR`, pinned in
  `config/models.yaml`; OpenRouter `:free` models in cloud, local LiteLLM/llama.cpp on dev machine
- [ ] LLM cassette record/replay (`--llm-mode record|replay|live`), default `replay` in CI
- [ ] Rate limiter (<= 15 RPM), 429 backoff honoring `Retry-After`, per-run LLM call cap
- [ ] Eval sets: `smoke` (3 tasks, cloud) and `full` (local); clear failure if a pinned model disappears

Acceptance
- Cloud: `smoke` set passes in `live` mode once, then re-runs in `replay` mode with zero API calls.
- Local: baseline report committed for at least one local model on all engines.

Prompt
> Implement Phase 8. The agent must use only the MCP tools, no internal imports. Include a
> step cap and a loop detector (same action on same ref 3 times → replan).

---

## Phase 9 — Skills

Deliverables
- [ ] Trace recorder on successful actions
- [ ] `skill_save` → YAML with parameters; `skill_run` with per-step failure reporting
- [ ] API-only skills built from replay chains

Acceptance
- A recorded "search orders and export page 2" skill replays on a fresh session on every engine.
- Eval harness shows skill mode vs agent mode success/latency.

---

## Later / optional

- Vision fallback mode for multimodal local models
- Per-profile proxy with consistent geo/timezone/locale (camoufox can derive these; keep them pinned)
- Skill repair: agent fixes a broken step and saves a new skill version
- Multi-session orchestration (parallel runs across different profiles)
