#!/bin/bash
# COPY THIS INTO: claude.ai/code -> environment "llm-browser" -> Setup script.
# Runs as root before Claude Code starts. Must exit 0 and finish in < ~5 min to be cached.
# Keep PLAYWRIGHT_VERSION identical to the version pinned in pyproject.toml.
# Steps run sequentially on purpose: `playwright install --with-deps` also uses apt,
# and two apt processes in parallel fail on the dpkg lock.
PLAYWRIGHT_VERSION="1.XX.0"

apt-get update -y || true
apt-get install -y xvfb x11vnc novnc websockify fonts-noto-cjk || true

pip install --break-system-packages "playwright==${PLAYWRIGHT_VERSION}" || true
python3 -m playwright install --with-deps chromium firefox || true

exit 0
