#!/bin/bash
# Project-level setup for Claude Code cloud sessions. No-op on local machines.
if [ "$CLAUDE_CODE_REMOTE" != "true" ]; then
  exit 0
fi

echo "[cloud_setup] environment: ${CLAUDE_CODE_ENVIRONMENT_NAME:-<not set>}"
if [ "${CLAUDE_CODE_ENVIRONMENT_NAME}" != "llm-browser" ]; then
  echo "[cloud_setup] WARNING: expected environment 'llm-browser'. Custom allowlist and setup script may be missing."
fi

# Python deps (fast when uv cache is warm)
if [ -f pyproject.toml ]; then
  uv sync || echo "[cloud_setup] uv sync failed"
fi

# Report browser availability; installation belongs to the environment setup script
python3 -m playwright --version 2>/dev/null || echo "[cloud_setup] playwright CLI not found"
ls ~/.cache/ms-playwright 2>/dev/null || echo "[cloud_setup] no Playwright browsers cached"

exit 0
