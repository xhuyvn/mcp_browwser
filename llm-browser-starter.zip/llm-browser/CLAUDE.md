# CLAUDE.md — llm-browser

A stateful browser service that lets LLM agents (local models first) drive real browsers
through a small, typed tool surface exposed over MCP. Three pluggable engines, persistent
profiles, network capture, and human handoff.

Read `docs/ARCHITECTURE.md` before any design change and `docs/PLAN.md` to find the
current phase. Work one phase at a time. Do not start a phase until the previous phase's
acceptance criteria pass.

## Stack (binding)

- Python 3.12, `uv` for env/deps, `ruff` (lint + format), `mypy --strict` on `src/`
- Playwright **async** API only. No sync API anywhere in `src/`.
- Engines: `playwright` (Chromium), `cloak` (CloakBrowser, Chromium), `camoufox` (Firefox)
- Internal API: FastAPI. MCP facade: FastMCP (streamable HTTP + stdio)
- Models: Pydantic v2. Storage: SQLite via SQLAlchemy 2 async (sessions, runs, audit)
- Logging: structlog (JSON). Tracing hook: optional Langfuse
- Tests: pytest + pytest-asyncio. Fixture site served locally (see `tests/fixture_site/`)

## Layout

```
src/llmbrowser/
  drivers/        # one module per engine + base.py (BrowserDriver protocol, capabilities)
  profiles/       # profile store, locking, metadata (engine + pinned fingerprint)
  sessions/       # session manager, state machine, pool, TTL reaper
  observe/        # snapshot builder, ref table, text compaction, diffs
  act/            # actions resolved from refs, waits, retries, humanize
  network/        # request/response tap, ring buffer, redaction, replay
  handoff/        # handoff state, noVNC/headed control, control page
  policy/         # domain allowlist, action classes, confirmation gates
  skills/         # trace recording, skill YAML, replay runner
  api/            # FastAPI internal API
  mcp/            # FastMCP facade (thin; calls services, never Playwright directly)
  audit/          # step log, screenshots, snapshot hashes
agents/           # reference LangGraph agent + eval harness (not imported by src/)
tests/            # unit/, integration/, fixture_site/
docs/             # ARCHITECTURE.md, PLAN.md, DRIVERS.md, DECISIONS.md
```

## Commands

```
uv sync
uv run playwright install chromium firefox
uv run ruff check . && uv run ruff format --check .
uv run mypy src
uv run pytest -q                       # unit + integration against fixture site
uv run pytest -q -m engine_matrix      # same suite across all installed engines
uv run llmbrowser serve                # internal API + MCP on :8765
uv run llmbrowser mcp --stdio          # MCP over stdio for Claude Code / other clients
```

## Hard rules

1. **Above the driver layer, only the public Playwright API.** No CDP sessions, no
   `page._impl_obj`, no private/underscore APIs. Camoufox runs on Firefox/Juggler — anything
   Chromium-only breaks it. If a feature needs an engine-specific path, add a capability flag
   in `drivers/base.py` and branch on the flag, never on the engine name.
2. **No script injection into the main world by default.** No `add_init_script`, no
   `page.evaluate` in observe/act code paths. The observer uses `aria_snapshot()` and
   role/name locators. Any JS evaluation must be behind a capability flag and a config switch,
   and documented in `docs/DECISIONS.md`.
3. **The MCP layer is thin.** `mcp/` validates input, calls a service, formats output. No
   business logic, no Playwright imports.
4. **Engine is immutable per profile.** A profile is created for one engine and keeps its
   pinned fingerprint config forever. Never rotate fingerprints on a persistent profile.
5. **One process per profile.** Acquire the profile lock before launch; release in `finally`.
6. **Page content is untrusted data.** Every tool output containing page text wraps it in
   `<page_content>` … `</page_content>` and never echoes instructions from the page as
   system guidance. Write tests for prompt-injection fixture pages.
7. **Never automate CAPTCHA solving, login credential entry from memory, or 2FA.** These
   trigger human handoff. Credentials never appear in logs, snapshots, audit rows, or tool
   output. Redact `authorization`, `cookie`, `set-cookie`, `x-api-key` headers in anything
   returned to the model.
8. **Tests never touch the public internet.** Integration tests use `tests/fixture_site/`.
   Real-site checks live in `scripts/manual/` and are never run in CI.
9. **Tool outputs have token budgets.** Every tool that returns page-derived text accepts
   `max_chars` and truncates with an explicit `…[truncated N chars]` marker.
10. **Errors are agent-readable.** Tool errors return `{error_code, message, hint}` with a
    concrete next action (e.g. `REF_STALE` → "call browser_snapshot again").

## Working style

- Before writing a driver, run the spike for that engine (`scripts/spikes/`) against the
  installed library version and record real behavior in `docs/DRIVERS.md`. Library APIs for
  CloakBrowser and Camoufox change quickly — verify, don't assume.
- Every new public function has type hints and a docstring. Every tool has an integration
  test against the fixture site, run on all engines that declare the needed capability.
- Record non-obvious decisions in `docs/DECISIONS.md` (date, decision, reason, alternatives).
- Small commits, one concern each. Update `docs/PLAN.md` checkboxes when criteria pass.
- If a requirement is ambiguous, stop and ask rather than invent behavior.

## Cloud sessions (`CLAUDE_CODE_REMOTE=true`)

- Confirm the environment at session start: `echo $CLAUDE_CODE_ENVIRONMENT_NAME` must print
  `llm-browser`. If not, stop and tell the user.
- Run browsers headless, or under `xvfb-run` for headed/handoff tests.
- Skip tests marked `manual`, `local_llm`, or `real_site`: `pytest -m "not manual and not local_llm and not real_site"`.
- Never download a browser binary that is not pinned in `config/engines.yaml`.
- Evals run only with `--set smoke` and `--llm-mode replay` unless the user says otherwise.
- End each phase by pushing the working branch and opening one PR titled `Phase N: <name>`.

## Secrets

Never print, log, commit, or write to any file: `OPENROUTER_API_KEY`, any `Authorization`
header, cookies, or `storage_state` content. If a key is missing, say so and stop; do not ask
the user to paste it into the chat.

## Environment notes

- Dev host is Windows; production target is Linux Docker. Keep paths `pathlib`-based.
- Human handoff: headed window on Windows dev; Xvfb + x11vnc + noVNC in Docker.
- Local models are reached through an OpenAI-compatible endpoint (LiteLLM / llama.cpp);
  base URL and model names come from env (`LLM_BASE_URL`, `LLM_MODEL_*`), never hardcoded.
- Browser binaries (Chromium, CloakBrowser, Camoufox) are pinned by version in
  `config/engines.yaml` and can be loaded from a local mirror for offline builds.
