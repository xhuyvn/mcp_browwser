# Review — <ID> (round <n>)
Date: YYYY-MM-DD · Branch: `feat/<ID>` · Commit reviewed: <sha>

## Checks run by supervisor
| Check | Command | Result |
|---|---|---|
| Tests | | |
| Lint / type | | |
| Secret / dependency scan | | |

## Verification steps
| Step | Result |
|---|---|

## Rubric
| # | Category | Score | Note |
|---|---|---|---|
| 1 | Correctness | | |
| 2 | Design conformance | | |
| 3 | Verification | | |
| 4 | Security | | |
| 5 | Scope discipline | | |
| 6 | Maintainability | | |
| 7 | Reliability | | |
| 8 | Handoff readiness | | |
| | **Total** | /16 | |

## Findings
| ID | Severity | File:line | Issue | Required fix |
|---|---|---|---|---|

## Verdict: Accept / Revise / Block

## Fix prompt for coder (if Revise)
Address findings <IDs> on `feat/<ID>`. Do not change anything else. Record each fix in the evidence file, then report ready for re-review.
