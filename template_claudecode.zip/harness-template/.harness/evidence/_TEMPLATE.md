# Evidence — <ID>
Branch: `feat/<ID>` · Last updated: YYYY-MM-DD

## Acceptance criteria
| # | Result | How verified (command / steps) |
|---|---|---|
| 1 | pass / fail / not verified | |

## Commands run (actual output summary)
- Tests:
- Lint / type check:

## Not verified
-

## Blockers / questions for supervisor
-

## Review findings addressed
| Finding | Fix | Commit |
|---|---|---|
