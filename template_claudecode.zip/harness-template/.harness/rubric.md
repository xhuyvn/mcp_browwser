# Review Rubric
<!-- Score 0 = fails, 1 = partial, 2 = meets. Calibrate: for the first 3–5 reviews, compare scores with the user's own judgment and adjust the "meets" bar below. -->

| # | Category | Meets (2) when |
|---|---|---|
| 1 | Correctness | Behavior matches `user_visible_behavior` and every verification step passes. |
| 2 | Design conformance | Matches referenced FR/NFR/SEC IDs: architecture, API contract, data model. |
| 3 | Verification | Supervisor re-ran tests, lint, type check; all green; new tests cover the feature incl. a negative case. |
| 4 | Security | No secrets; input validated; authZ enforced; no new high/critical dependency issue. |
| 5 | Scope discipline | Only files needed for this feature changed; no drive-by refactors. |
| 6 | Maintainability | Clear names, error handling, logging; follows `docs/STACK.md` conventions. |
| 7 | Reliability | Survives restart/rerun; baseline still green. |
| 8 | Handoff readiness | Evidence file is accurate and states what is NOT verified. |

## Verdict rules
- **Accept**: no 0, total ≥ 13/16, no open Critical/Major finding.
- **Revise**: any fixable 0, or Critical/Major finding.
- **Block**: design conflict, missing requirement, or blocker outside coder's control.
