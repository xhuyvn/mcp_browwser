# Handoff
<!-- Overwritten every session. Max 40 lines. -->
- Date / role / branch:

## Verified now
- Working:
- Verification actually run (command → result):

## Changed this session
-

## Broken or unverified
- Known defect:
- Unverified path:
- Risk for next session:

## Next step
- Feature:
- What counts as passing:
- Must not change:

## Commands
- Startup:
- Verify:
- Focused debug:
