# Progress

## Current Verified State
<!-- Supervisor keeps this true at all times. Read this; skip the log unless needed. -->
- Design version:
- Startup: `./init.sh` / `./init.ps1`
- Baseline verification: PASS / FAIL (date)
- Passing features:
- In progress / in review:
- Blocked:
- Next feature:

## Session Log
<!-- Newest first. Keep max 5 entries; /handoff moves older ones to archive/. -->

### S-001 — YYYY-MM-DD — supervisor
- Goal:
- Done:
- Verification run (actual):
- Commits:
- Open risks:
- Next step:
