# <ID> — <title>
Branch: `feat/<ID>` · Requirements: <FR-xx, SEC-xx> · Depends on: <IDs or none>

## Context
<2–4 lines: why this feature exists, where it sits in the architecture. Point to design sections, don't copy them: `docs/design.md#...`>

## Goal
<one sentence user-visible outcome>

## In scope
-

## Out of scope (do not touch)
-

## Likely files
-

## Acceptance criteria (each must be testable)
1.
2.
3. Negative case:

## Verification you must run
- Tests:
- Lint / type check:
- Manual check:

## Definition of done
Criteria met, tests added and passing, baseline green, `.harness/evidence/<ID>.md` written incl. what is NOT verified. Then tell the user it is ready for `/review <ID>`.
