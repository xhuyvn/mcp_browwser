# Clean State Checklist (run at /handoff)

- [ ] Init script runs; baseline verification result recorded honestly.
- [ ] Working tree clean or every uncommitted change explained in handoff.
- [ ] No feature marked `passing` without merged code + evidence on main.
- [ ] No test removed, skipped or weakened to get green.
- [ ] No secrets, real data or PII in the diff.
- [ ] Handoff names one concrete next step and what counts as passing.
- [ ] A fresh session can continue from repo files alone.
