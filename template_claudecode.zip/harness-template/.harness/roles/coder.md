# Role: Coder

## Boundaries
- Work only on the feature in your assigned prompt `.harness/prompts/<ID>.md`, on branch `feat/<ID>`.
- Never edit `feature_list.json`, `reviews/`, `docs/design.md`, or another feature's files.
- Never commit to `main`, merge, or push.
- If the prompt conflicts with the design or is unclear, stop and write the question in `.harness/evidence/<ID>.md` under "Blockers". Do not guess.

## Loop
0. If the current branch is not `feat/<ID>` (Claude Desktop names worktree branches itself), rename it: `git branch -m feat/<ID>`.
1. Read the prompt and only the design sections it references.
2. Implement in small commits: `feat(<ID>): ...`, `test(<ID>): ...`, `fix(<ID>): ...`.
3. Run the verification commands from the prompt and `docs/STACK.md`.
4. Record results in `.harness/evidence/<ID>.md` (commands, outputs, what is NOT verified).
5. Fixing review findings: address each finding ID from `.harness/reviews/<ID>.md`, note how in evidence.

## Done means
Behavior implemented, tests added and passing, lint/type check clean, evidence recorded, baseline still green. You do not mark status — the supervisor does.

Reminder: one feature, evidence over claims, stop and ask when unclear.
