#!/usr/bin/env python3
"""Small CLI over feature_list.json so agents read one feature, not the whole file.

  python .harness/state.py list                 # one line per feature
  python .harness/state.py show F-03            # full entry for one feature
  python .harness/state.py next                 # highest-priority actionable feature
  python .harness/state.py set F-03 in_review [--evidence PATH] [--note TEXT]

`set` is supervisor-only (enforced by .claude/hooks/guard.py).
"""
import argparse
import datetime as dt
import json
import sys
from pathlib import Path

PATH = Path(__file__).with_name("feature_list.json")
ACTIONABLE = ("changes_requested", "in_progress", "not_started")


def load():
    with PATH.open(encoding="utf-8") as f:
        return json.load(f)


def save(data):
    data["last_updated"] = dt.date.today().isoformat()
    with PATH.open("w", encoding="utf-8") as f:
        json.dump(data, f, indent=2, ensure_ascii=False)
        f.write("\n")


def find(data, fid):
    for feat in data["features"]:
        if feat["id"] == fid:
            return feat
    sys.exit(f"Feature {fid} not found.")


def deps_ok(data, feat):
    status = {f["id"]: f["status"] for f in data["features"]}
    return all(status.get(d) == "passing" for d in feat.get("depends_on", []))


def main():
    p = argparse.ArgumentParser()
    sub = p.add_subparsers(dest="cmd", required=True)
    sub.add_parser("list")
    sub.add_parser("next")
    s = sub.add_parser("show")
    s.add_argument("id")
    st = sub.add_parser("set")
    st.add_argument("id")
    st.add_argument("status")
    st.add_argument("--evidence")
    st.add_argument("--note")
    a = p.parse_args()
    data = load()

    if a.cmd == "list":
        for f in sorted(data["features"], key=lambda x: x["priority"]):
            print(f'{f["id"]:<6} {f["status"]:<18} P{f["priority"]} {f.get("phase",""):<4} {f["title"]}')
    elif a.cmd == "show":
        print(json.dumps(find(data, a.id), indent=2, ensure_ascii=False))
    elif a.cmd == "next":
        cands = [f for f in data["features"] if f["status"] in ACTIONABLE and deps_ok(data, f)]
        cands.sort(key=lambda f: (ACTIONABLE.index(f["status"]), f["priority"]))
        if not cands:
            print("No actionable feature (all passing, blocked, in review, or waiting on dependencies).")
            return
        print(json.dumps(cands[0], indent=2, ensure_ascii=False))
    elif a.cmd == "set":
        if a.status not in data["status_legend"]:
            sys.exit(f"Unknown status {a.status}. Use one of: {', '.join(data['status_legend'])}")
        feat = find(data, a.id)
        if a.status == "passing" and not (a.evidence or feat.get("evidence")):
            sys.exit("Refusing: 'passing' requires --evidence.")
        feat["status"] = a.status
        if a.status == "in_progress" and not feat.get("branch"):
            feat["branch"] = f"feat/{a.id}"
        if a.evidence:
            feat.setdefault("evidence", []).append(a.evidence)
        if a.note:
            feat["notes"] = (feat.get("notes", "") + f" [{dt.date.today()}] {a.note}").strip()
        save(data)
        print(f"{a.id} -> {a.status}")


if __name__ == "__main__":
    main()
