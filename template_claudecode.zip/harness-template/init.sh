#!/usr/bin/env bash
# Standard startup + baseline verification. Mirrors docs/STACK.md §3.
set -euo pipefail
ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd "$ROOT_DIR"

echo "==> Root:   $PWD"
echo "==> Branch: $(git rev-parse --abbrev-ref HEAD 2>/dev/null || echo n/a)"
echo "==> Role:   ${HARNESS_ROLE:-unset}"
[ -f .env ] || { echo "Missing .env — copy .env.example and fill it in."; exit 1; }

echo "==> Services"
docker compose --env-file config/ports.env --env-file .env -f docker-compose.dev.yml up -d --wait

echo "==> Install"
(cd backend && uv sync --locked)
(cd frontend && npm ci --no-audit --no-fund)

echo "==> Migrate"
(cd backend && uv run alembic upgrade head)

echo "==> Baseline verification"
fail=0
python3 scripts/check_ports.py || fail=1
(cd backend && uv run ruff check . && uv run ruff format --check . && uv run mypy app \
  && uv run lint-imports && uv run alembic check && uv run pytest -q) || fail=1
(cd frontend && npm run lint && npm run typecheck && npm run test -- --run && npm run build) || fail=1

if [ "$fail" = 0 ]; then echo "BASELINE: PASS"; else echo "BASELINE: FAIL — fix the baseline before new work."; exit 1; fi
echo "==> Dev: (backend) uv run fastapi dev app/main.py --host \$BACKEND_HOST --port \$BACKEND_PORT · (frontend) npm run dev"
