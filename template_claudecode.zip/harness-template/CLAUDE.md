# CLAUDE.md

Long-running, multi-session project. Two roles share this repo: **supervisor** (plans, reviews, merges) and **coder** (implements). Repo files are the system of record — never rely on chat history.

## Hard rules (enforced by hooks — do not try to bypass)
- One active feature per session. Work only inside its scope.
- Never claim done without runnable evidence. Never weaken or delete tests to pass.
- Only the supervisor edits `.harness/feature_list.json` and `.harness/reviews/`.
- Nobody edits `docs/design.md` — it is the approved input. Report conflicts instead.
- Coder never commits to `main`. Merge and push need explicit user approval.
- Never commit secrets, real data or PII.

## Session start
Run `/start <supervisor|coder>`. It loads your role file and the current state.
If baseline verification fails, fix the baseline before any new work.

## Where things are
| Need | Location |
|---|---|
| Requirements (IDs FR/NFR/SEC) | `docs/design.md` |
| Stack, commands, conventions | `docs/STACK.md` |
| Feature state | `python .harness/state.py show <ID>` (don't read the whole JSON) |
| Current verified state | top of `.harness/progress.md` |
| Last session's handoff | `.harness/handoff.md` |
| Task prompt for coder | `.harness/prompts/<ID>.md` |
| Coder's evidence | `.harness/evidence/<ID>.md` |
| Review results | `.harness/reviews/<ID>.md` |

## Context discipline
- Read pointers, not whole files. Fetch only the design sections your feature references.
- End the session at a feature boundary with `/handoff`, then start a fresh session. Compact only mid-feature.

## Accuracy
Report only what you verified by running commands or reading code. If something was not run, say so.

## Language
All output in English. Start each reply by restating the user's message in correct English (translate if Vietnamese; correct grammar if English, max 3 short notes). Skip for very short replies and pasted content.

---
Reminder: evidence before status, one feature at a time, no merge/push without approval.
