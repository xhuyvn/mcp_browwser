# Claude Code Harness Template — Supervisor / Coder

Reusable harness for long-running projects built with Claude Code. Two sessions share one repo: a **supervisor** that plans, reviews and merges, and a **coder** that implements in its own git worktree. Repo files carry all state, so any session can be closed and a fresh one continues from files alone.

Adapted from [walkinglabs/learn-harness-engineering — templates](https://github.com/walkinglabs/learn-harness-engineering/tree/main/docs/en/resources/templates) (progress log, feature list, init script, handoff, clean-state checklist, evaluator rubric, quality document), extended with role separation, hooks and on-demand commands.

## Layout
```
CLAUDE.md                 Invariants + pointers (kept short; loaded every session)
init.sh / init.ps1        Install + baseline verification (mirror docs/STACK.md)
docs/design.md            Approved design with FR/NFR/SEC IDs (read-only for agents)
docs/STACK.md             Fullstack profile: pinned versions, commands, layer rules
docs/stack/                Reference configs: backend-pyproject.toml (ruff, mypy, pytest,
                          import-linter), settings.py (pydantic-settings), vite.config.ts
config/ports.env          Host & port catalog — single source for every endpoint
scripts/check_ports.py    Fails verification on port duplicates or hard-coded host:port
docker-compose.dev.yml    Postgres / Redis / Qdrant pinned for dev, ports from catalog
.env.example              Secrets + per-environment hosts (copy to .env)
.harness/
  roles/                  supervisor.md, coder.md — loaded by /start <role>
  feature_list.json       Feature state (supervisor-only)
  state.py                CLI: list | show <ID> | next | set <ID> <status>
  progress.md             Current Verified State + last 5 sessions
  handoff.md              ≤40-line note, overwritten each session
  clean-state.md          End-of-session checklist
  rubric.md               Review scoring, 8 × 0–2
  quality.md              Per-phase quality snapshot
  prompts/ evidence/ reviews/   Per-feature files (+ _TEMPLATE.md each)
  archive/                Old progress entries
.claude/
  settings.json           Permissions (ask/deny) + hooks
  hooks/guard.py          Blocks role violations, design edits, secrets, --no-verify
  hooks/session_start.py  Prints role + branch at session start
  commands/               /start /plan /next /review /merge /handoff
```

## Setup (once per project)
1. Copy this folder's contents into the project repo root and commit.
2. Replace `docs/design.md` with the Final design. Adjust `config/ports.env` if ports clash on your machine; `init.sh` / `init.ps1` already mirror `docs/STACK.md`.
3. Copy `.env.example` to `.env` and fill secrets. Start `backend/pyproject.toml`, `backend/app/core/settings.py` and `frontend/vite.config.ts` from the files in `docs/stack/`.
4. Check `python` resolves on your machine (macOS/Linux may need `python3` in `.claude/settings.json`).
5. Install gitleaks as a git pre-commit hook for stronger secret checks than the guard regexes.

## Daily flow (Windows PowerShell)
```powershell
# Supervisor — main checkout
$env:HARNESS_ROLE="supervisor"; claude
/start supervisor      # then /plan (first time) or /next

# Coder — separate worktree on the feature branch
git worktree add ..\<repo>-coder -b feat/F-01
cd ..\<repo>-coder
$env:HARNESS_ROLE="coder"; claude
/start coder           # give it .harness/prompts/F-01.md

# Back in supervisor when coder reports ready
/review F-01           # Revise → coder fixes → /review again
/merge F-01            # asks for your approval
/handoff               # end of session, then open a fresh one
```
bash: `HARNESS_ROLE=supervisor claude`.

## How the known weaknesses are handled
| Weakness | Mechanism |
|---|---|
| Long-running tasks / compaction | One feature per session; `/handoff` writes state to files; fresh session resumes via `/start`. Compact only mid-feature. |
| Instruction bloat | `CLAUDE.md` holds invariants only; role rules load via `/start`; procedures live in commands loaded on call; enforceable rules are hooks (no tokens). |
| Lost in the middle | Hard rules at top + one-line reminder at bottom of each file; `state.py show` returns one feature, not the whole JSON; progress capped at 5 entries; prompts are self-contained and point to design sections. |
| Self-approval | Coder cannot change status, reviews or prompts (hook). Supervisor re-runs checks itself and scores with the rubric. |

## Maintenance
- Calibrate `rubric.md` over the first 3–5 reviews against your own judgment.
- Periodically remove one harness rule, run a few features, and restore it only if quality drops.
- Hook and permission syntax follows Claude Code's `settings.json` format; verify against the current Claude Code docs after upgrades.
