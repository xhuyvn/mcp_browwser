#!/usr/bin/env python3
"""Enforce config/ports.env as the single source of truth for hosts and ports.

Checks:
  1. Every *_PORT in the catalog is an integer 1-65535 and unique.
  2. No host:port literal in backend/app, frontend/src or frontend/vite.config.* .
  3. docker-compose*.yml publishes ports only via ${..._PORT} variables.
  4. .env.example does not redefine catalog ports (overrides belong in .env only).
Exit 1 on any violation. Part of baseline verification.
"""
import re
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
CATALOG = ROOT / "config" / "ports.env"
SCAN = [ROOT / "backend" / "app", ROOT / "frontend" / "src"]
SCAN_FILES = list((ROOT / "frontend").glob("vite.config.*"))
EXTS = {".py", ".ts", ".tsx", ".js", ".jsx", ".mjs", ".cjs"}
HOSTPORT = re.compile(r"(?:localhost|127\.0\.0\.1|0\.0\.0\.0|\[::1\])\s*:\s*\d{2,5}|https?://[\w.\-]+:\d{2,5}")
ALLOW = "ports-ok"  # put `# ports-ok: <reason>` on a line to allow it explicitly

errors: list[str] = []


def parse_env(path: Path) -> dict[str, str]:
    out = {}
    for raw in path.read_text(encoding="utf-8").splitlines():
        line = raw.strip()
        if line and not line.startswith("#") and "=" in line:
            k, v = line.split("=", 1)
            out[k.strip()] = v.strip()
    return out


if not CATALOG.exists():
    sys.exit(f"Missing {CATALOG.relative_to(ROOT)}")
cat = parse_env(CATALOG)

# 1. catalog sanity
seen: dict[int, str] = {}
for key, val in cat.items():
    if key.endswith("_PORT"):
        if not val.isdigit() or not 1 <= int(val) <= 65535:
            errors.append(f"ports.env: {key}={val} is not a valid port")
            continue
        if int(val) in seen:
            errors.append(f"ports.env: {key} and {seen[int(val)]} both use {val}")
        seen[int(val)] = key

# 2. no literals in source
files = [p for d in SCAN if d.exists() for p in d.rglob("*") if p.suffix in EXTS] + SCAN_FILES
for path in files:
    if "node_modules" in path.parts:
        continue
    for n, line in enumerate(path.read_text(encoding="utf-8", errors="ignore").splitlines(), 1):
        if HOSTPORT.search(line) and ALLOW not in line:
            errors.append(f"{path.relative_to(ROOT)}:{n}: host:port literal — read it from config/ports.env")

# 3. compose uses variables
for compose in ROOT.glob("docker-compose*.yml"):
    for n, line in enumerate(compose.read_text(encoding="utf-8").splitlines(), 1):
        m = re.search(r'["\']?([\d.]+:)?(\$\{\w+\}|\d+):\d+["\']?', line)
        if "ports" in line and m and not re.search(r"\$\{\w+_PORT\}", line):
            errors.append(f"{compose.name}:{n}: published port must use a ${{..._PORT}} variable")

# 4. .env.example must not shadow catalog ports
example = ROOT / ".env.example"
if example.exists():
    for key in parse_env(example):
        if key in cat and key.endswith("_PORT"):
            errors.append(f".env.example: {key} duplicates config/ports.env")

if errors:
    print("PORT CATALOG: FAIL")
    print("\n".join(f"  - {e}" for e in errors))
    sys.exit(1)
print(f"PORT CATALOG: OK ({sum(k.endswith('_PORT') for k in cat)} ports, {len(files)} files scanned)")
