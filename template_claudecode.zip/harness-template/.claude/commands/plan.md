---
description: Supervisor — break the design into features
---
Supervisor only.

1. Read the requirement list (IDs FR/NFR/SEC) and roadmap in `docs/design.md`. If requirements have no IDs, stop and ask the user to fix the design first.
2. Propose features for `.harness/feature_list.json`, each with: `id` (F-01...), `priority`, `phase` (MVP/P2...), `title`, `reqs` (design IDs), `user_visible_behavior`, `verification` (testable steps), `depends_on`.
3. Every feature must fit in one session. Split anything larger.
4. Show a coverage table: each requirement ID → feature IDs. Flag uncovered requirements.
5. Wait for user approval, then write the file and commit `plan: <summary>` on `main`.
