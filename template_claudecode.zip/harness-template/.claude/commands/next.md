---
description: Supervisor — write the coder prompt for the next feature
argument-hint: [feature ID, optional]
---
Supervisor only. Feature: $ARGUMENTS (if empty, use `python .harness/state.py next`).

1. `python .harness/state.py show <ID>`; check dependencies are `passing`.
2. Read only the design sections listed in its `reqs`.
3. Write `.harness/prompts/<ID>.md` from `.harness/prompts/_TEMPLATE.md`. It must be self-contained: a coder reading only this file plus the referenced design sections can finish the work.
4. Set status `in_progress`, branch `feat/<ID>`: `python .harness/state.py set <ID> in_progress`.
5. Commit `assign(<ID>): <title>` on `main`.
6. Tell the user how to start the coder:
   - **Claude Desktop:** new session on this project with **Worktree ON**, then run `/start coder` and give it `.harness/prompts/<ID>.md`. The worktree has no `.harness-role`, so it is coder by default.
   - **CLI:** `git worktree add ../<repo>-coder -b feat/<ID>`, put `coder` in `../<repo>-coder/.harness-role`, open Claude Code there, run `/start coder`.
