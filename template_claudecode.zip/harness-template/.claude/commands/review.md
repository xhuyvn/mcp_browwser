---
description: Supervisor — independently review a feature branch
argument-hint: <feature ID>
---
Supervisor only. Review **$ARGUMENTS** on branch `feat/$ARGUMENTS`.

0. `python .harness/state.py set $ARGUMENTS in_review`.
1. Read the prompt `.harness/prompts/$ARGUMENTS.md` and evidence `.harness/evidence/$ARGUMENTS.md`.
2. `git diff main...feat/$ARGUMENTS --stat`, then read the diff.
3. Run the checks yourself in the coder worktree (`.claude/worktrees/<name>` in Desktop, `../<repo>-coder` in CLI) or a temporary review worktree — never switch your own `main` checkout: full test suite, lint, type check, dependency/secret scan (commands in `docs/STACK.md`). Record actual results.
4. Walk through each `verification` step of the feature. Mark each: verified / failed / not verifiable.
5. Check against the referenced design IDs: scope, architecture, API contract, data model, security (OWASP basics).
6. Score with `.harness/rubric.md`. List findings with IDs `R<ID>-01...` and severity.
7. Write `.harness/reviews/$ARGUMENTS.md` from `_TEMPLATE.md`. Verdict:
   - **Accept** → status stays `in_review` until `/merge`.
   - **Revise** → status `changes_requested`; write a fix prompt section at the end of the review file for the coder.
   - **Block** → status `blocked`, explain why, escalate to the user.
8. Commit the review on `main`. Report verdict + findings count to the user.

Reminder: run checks yourself; the coder's evidence is a claim, not proof.
