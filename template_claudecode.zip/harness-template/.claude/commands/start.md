---
description: Start a session in a role (supervisor or coder)
argument-hint: <supervisor|coder>
---
Start a session as **$ARGUMENTS**.

1. Read `.harness/roles/$ARGUMENTS.md`. Follow it for the whole session.
2. Run `git status` and `git log --oneline -5`. Note the current branch.
3. Read the "Current Verified State" section of `.harness/progress.md` (top only) and `.harness/handoff.md`.
4. Run the init script (`./init.sh` or `./init.ps1`). If verification fails, stop and report — fixing the baseline is the first task.
5. Identify the one feature for this session:
   - supervisor: `python .harness/state.py next`
   - coder: the feature whose prompt you were given; `python .harness/state.py show <ID>`
6. Reply with: role, branch, baseline result, selected feature, planned next action. Then wait for confirmation.
