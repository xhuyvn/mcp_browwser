---
description: End the session cleanly so a fresh session can continue
---
1. Run the init script. Record the result honestly.
2. Go through `.harness/clean-state.md`; fix or document every unchecked item.
3. Overwrite `.harness/handoff.md` from its template. Keep it under 40 lines.
4. Append a session entry to `.harness/progress.md` (supervisor) or to `.harness/evidence/<ID>.md` (coder). Update "Current Verified State" only if you are supervisor.
5. Supervisor: if `progress.md` has more than 5 session entries, move the oldest to `.harness/archive/progress-<YYYY-MM>.md`.
6. Commit (`handoff: <summary>`) on your own branch. Tell the user: "Safe to close. Start a new session with /start <role>."
