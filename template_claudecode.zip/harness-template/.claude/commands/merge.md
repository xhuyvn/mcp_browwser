---
description: Supervisor — merge an accepted feature (needs user approval)
argument-hint: <feature ID>
---
Supervisor only. Merge **$ARGUMENTS**.

1. Confirm `.harness/reviews/$ARGUMENTS.md` verdict is **Accept** and no Critical/Major finding is open. Otherwise stop.
2. Show the user: feature, commits, files changed, review score. **Ask for approval and wait.**
3. After approval: `git checkout main && git merge --squash feat/$ARGUMENTS && git commit -m "feat($ARGUMENTS): <title>"`.
4. Run the init script on `main`. If verification fails, revert the merge commit and report.
5. `python .harness/state.py set $ARGUMENTS passing --evidence ".harness/reviews/$ARGUMENTS.md"`.
6. Update "Current Verified State" in `.harness/progress.md`; commit `state($ARGUMENTS): passing`.
7. Suggest cleanup: `git worktree remove ../<repo>-coder` and `git branch -d feat/$ARGUMENTS`. Do not push unless the user asks.
