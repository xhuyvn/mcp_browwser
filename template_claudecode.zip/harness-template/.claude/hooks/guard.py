#!/usr/bin/env python3
"""PreToolUse guard. Exit code 2 blocks the tool call; stderr is shown to the agent.

Role: env HARNESS_ROLE, else the `.harness-role` file in the repo/worktree root, else coder (strictest).
Escape hatches (set by the user, never by the agent):
  HARNESS_ALLOW_DESIGN_EDIT=1   allow editing docs/design.md
"""
import json
import os
import re
import subprocess
import sys

def _role():
    env = os.environ.get("HARNESS_ROLE", "").strip().lower()
    if env:
        return env
    try:
        root = subprocess.run(["git", "rev-parse", "--show-toplevel"],
                              capture_output=True, text=True, timeout=10).stdout.strip()
        with open(os.path.join(root or ".", ".harness-role"), encoding="utf-8") as f:
            return f.read().strip().lower() or "coder"
    except Exception:
        return "coder"


ROLE = _role()
SUPERVISOR_ONLY = (".harness/feature_list.json", ".harness/reviews/", ".harness/rubric.md",
                   ".harness/progress.md", ".harness/prompts/")
SECRET_PATTERNS = [
    r"-----BEGIN (RSA |EC |OPENSSH |DSA )?PRIVATE KEY-----",
    r"AKIA[0-9A-Z]{16}",
    r"ghp_[A-Za-z0-9]{36}",
    r"sk-[A-Za-z0-9_\-]{20,}",
    r"xox[baprs]-[A-Za-z0-9\-]{10,}",
    r"(?i)(api[_-]?key|secret|password|passwd|token)\s*[:=]\s*['\"][^'\"\s]{12,}['\"]",
]


def block(msg):
    print(f"BLOCKED by harness guard ({ROLE}): {msg}", file=sys.stderr)
    sys.exit(2)


def git(*args):
    try:
        return subprocess.run(["git", *args], capture_output=True, text=True, timeout=15).stdout
    except Exception:
        return ""


def norm(path):
    return path.replace("\\", "/")


def check_file(path):
    p = norm(path)
    if p.endswith(".harness-role"):
        block("The role file is set by the user only.")
    if p.endswith("docs/design.md") and os.environ.get("HARNESS_ALLOW_DESIGN_EDIT") != "1":
        block("docs/design.md is the approved input. Report the conflict to the user instead of editing it.")
    if ROLE != "supervisor" and any(s in p for s in SUPERVISOR_ONLY):
        block(f"{p} is supervisor-only. Record results in .harness/evidence/<ID>.md instead.")
    if ROLE == "supervisor":
        q = "/" + p
        if "/.claude/worktrees/" in q:
            block("Supervisor must not edit files inside a coder worktree.")
        allowed = "/.harness/" in q or "/.claude/" in q or p.endswith(("docs/STACK.md", "CHANGELOG.md"))
        if not allowed:
            block("Supervisor must not edit product code. Write a finding or a prompt for the coder.")


def check_bash(cmd):
    c = " ".join(cmd.split())
    if "HARNESS_ROLE" in c or ".harness-role" in c:
        block("Agents cannot change their own role.")
    if "--no-verify" in c:
        block("--no-verify is not allowed.")
    if re.search(r"rm\s+-[a-z]*r[a-z]*f?\s+.*\.(harness|git)\b", c):
        block("Deleting .harness or .git is not allowed.")
    if ROLE != "supervisor":
        if re.search(r"\bgit\s+(push|merge)\b", c):
            block("Coder never pushes or merges. Report ready for /review.")
        if re.search(r"\bgit\s+(checkout|switch)\s+(main|master)\b", c):
            block("Coder stays on its feat/<ID> branch.")
        if re.search(r"state\.py\s+set\b", c):
            block("Only the supervisor changes feature status.")
    if re.search(r"\bgit\s+commit\b", c):
        branch = git("rev-parse", "--abbrev-ref", "HEAD").strip()
        if ROLE != "supervisor" and branch in ("main", "master"):
            block(f"Coder cannot commit on {branch}.")
        added = [l[1:] for l in git("diff", "--cached", "-U0").splitlines()
                 if l.startswith("+") and not l.startswith("+++")]
        for line in added:
            for pat in SECRET_PATTERNS:
                if re.search(pat, line):
                    block(f"Possible secret in staged changes (pattern {pat!r}). Use an env var placeholder.")


def main():
    try:
        data = json.load(sys.stdin)
    except Exception:
        sys.exit(0)
    tool = data.get("tool_name", "")
    inp = data.get("tool_input", {}) or {}
    if tool == "Bash":
        check_bash(inp.get("command", ""))
    elif tool in ("Edit", "Write", "MultiEdit", "NotebookEdit"):
        check_file(inp.get("file_path") or inp.get("notebook_path") or "")
    sys.exit(0)


if __name__ == "__main__":
    main()
