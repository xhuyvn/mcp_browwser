#!/usr/bin/env python3
"""SessionStart hook: prints a tiny orientation block into the session context."""
import os
import subprocess

role = os.environ.get("HARNESS_ROLE", "").strip().lower()
source = "env"
top = ""
if not role:
    try:
        top = subprocess.run(["git", "rev-parse", "--show-toplevel"],
                             capture_output=True, text=True, timeout=10).stdout.strip()
        with open(os.path.join(top or ".", ".harness-role"), encoding="utf-8") as f:
            role, source = f.read().strip().lower(), ".harness-role"
    except Exception:
        if "/.claude/worktrees/" in top.replace("\\", "/"):
            role, source = "coder", "Desktop worktree default"
try:
    branch = subprocess.run(["git", "rev-parse", "--abbrev-ref", "HEAD"],
                            capture_output=True, text=True, timeout=10).stdout.strip()
except Exception:
    branch = "unknown"

if role not in ("supervisor", "coder"):
    print("HARNESS: no role set (HARNESS_ROLE or .harness-role) — guard treats this session as coder. "
          "Ask the user which role this session is.")
else:
    print(f"HARNESS: role={role} (from {source}) branch={branch}. Run /start {role} before any work.")
