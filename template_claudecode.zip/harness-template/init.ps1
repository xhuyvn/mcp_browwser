# Standard startup + baseline verification (Windows). Mirrors docs/STACK.md §3.
$ErrorActionPreference = "Stop"
Set-Location $PSScriptRoot

function Run([string]$dir, [string]$cmd) {
    Push-Location $dir
    try { Invoke-Expression $cmd; if ($LASTEXITCODE -ne 0) { throw "failed: $cmd" } }
    finally { Pop-Location }
}

Write-Host "==> Root:   $PWD"
Write-Host "==> Branch: $(git rev-parse --abbrev-ref HEAD 2>$null)"
Write-Host "==> Role:   $($env:HARNESS_ROLE)"
if (-not (Test-Path .env)) { Write-Host "Missing .env - copy .env.example and fill it in."; exit 1 }

Write-Host "==> Services"
Run "." "docker compose --env-file config/ports.env --env-file .env -f docker-compose.dev.yml up -d --wait"

Write-Host "==> Install"
Run "backend"  "uv sync --locked"
Run "frontend" "npm ci --no-audit --no-fund"

Write-Host "==> Migrate"
Run "backend" "uv run alembic upgrade head"

Write-Host "==> Baseline verification"
$ok = $true
try { Run "." "python scripts/check_ports.py" } catch { Write-Host $_; $ok = $false }
$be = @("uv run ruff check .", "uv run ruff format --check .", "uv run mypy app", "uv run lint-imports", "uv run alembic check", "uv run pytest -q")
$fe = @("npm run lint", "npm run typecheck", "npm run test -- --run", "npm run build")
try { foreach ($c in $be) { Run "backend" $c } } catch { Write-Host $_; $ok = $false }
try { foreach ($c in $fe) { Run "frontend" $c } } catch { Write-Host $_; $ok = $false }

if ($ok) { Write-Host "BASELINE: PASS" }
else { Write-Host "BASELINE: FAIL - fix the baseline before new work."; exit 1 }
Write-Host "==> Dev: (backend) uv run fastapi dev app/main.py  |  (frontend) npm run dev"
