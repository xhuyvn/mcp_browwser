// Reference for frontend/vite.config.ts — dev server and /api proxy from config/ports.env.
import { readFileSync } from "node:fs";
import { resolve } from "node:path";
import { defineConfig } from "vite";
import react from "@vitejs/plugin-react";
import tailwindcss from "@tailwindcss/vite";

function loadCatalog(): Record<string, string> {
  const text = readFileSync(resolve(__dirname, "../config/ports.env"), "utf-8");
  const out: Record<string, string> = {};
  for (const raw of text.split(/\r?\n/)) {
    const line = raw.trim();
    if (!line || line.startsWith("#") || !line.includes("=")) continue;
    const i = line.indexOf("=");
    out[line.slice(0, i).trim()] = line.slice(i + 1).trim();
  }
  return { ...out, ...process.env } as Record<string, string>; // env overrides catalog
}

const p = loadCatalog();
const backend = `http://${p.BACKEND_HOST}:${p.BACKEND_PORT}`;

export default defineConfig({
  plugins: [react(), tailwindcss()],
  server: {
    host: p.FRONTEND_HOST,
    port: Number(p.FRONTEND_PORT),
    strictPort: true, // fail instead of silently picking another port
    proxy: { [p.API_BASE_PATH]: { target: backend, changeOrigin: false } },
  },
  define: { __API_BASE_PATH__: JSON.stringify(p.API_BASE_PATH) },
});
