# Reference for backend/app/core/settings.py — loads the port catalog, then .env overrides.
from functools import lru_cache
from pathlib import Path

from pydantic import SecretStr
from pydantic_settings import BaseSettings, SettingsConfigDict

ROOT = Path(__file__).resolve().parents[3]  # repo root (backend/app/core/settings.py)


class Settings(BaseSettings):
    model_config = SettingsConfigDict(
        env_file=(ROOT / "config" / "ports.env", ROOT / ".env"),  # later file wins
        extra="ignore",
    )

    backend_host: str
    backend_port: int
    api_base_path: str = "/api/v1"

    postgres_host: str
    postgres_port: int
    postgres_user: str
    postgres_password: SecretStr
    postgres_db: str

    redis_host: str
    redis_port: int
    redis_password: SecretStr

    qdrant_host: str
    qdrant_http_port: int
    qdrant_api_key: SecretStr

    @property
    def database_url(self) -> str:
        pw = self.postgres_password.get_secret_value()
        return f"postgresql+psycopg://{self.postgres_user}:{pw}@{self.postgres_host}:{self.postgres_port}/{self.postgres_db}"

    @property
    def qdrant_url(self) -> str:
        return f"http://{self.qdrant_host}:{self.qdrant_http_port}"


@lru_cache
def get_settings() -> Settings:
    return Settings()
