# Stack & Conventions — Fullstack Profile
<!-- Standard profile for Python API + React SPA + AI/RAG projects. Agents read this for versions, commands and rules.
Change a rule here once; init scripts, configs and reviews follow. -->

## 1. Versions (pinned — never use `latest`)
| Component | Pin | Notes |
|---|---|---|
| Python | 3.13.x (`requires-python = ">=3.13,<3.14"`) | 3.12 accepted for existing projects. Move to 3.14 when all deps support it. |
| uv | latest stable, `uv.lock` committed | Only tool for Python envs and packages. No pip/poetry. |
| Ruff | locked in `uv.lock` | Lint + format (replaces black, isort, flake8). |
| mypy | locked, `strict` | Type check; uses SQLAlchemy 2.0 `Mapped[]` types. |
| FastAPI · Pydantic v2 · pydantic-settings | locked | |
| SQLAlchemy | 2.0.x | 2.0 style only (§5). |
| Alembic | locked | Only way to change schema (§5). |
| LangGraph | `langgraph~=1.2` | |
| Node.js | 24 LTS, or 26 once nodejs.org lists it as LTS | `.nvmrc` + `package.json#engines`. |
| npm | bundled with Node, `package-lock.json` committed | `npm ci` only in scripts/CI. |
| React · TypeScript | React 19 · TS `strict` | |
| Vite | 8.x · `@vitejs/plugin-react` 6.x | |
| Tailwind CSS | `tailwindcss` + `@tailwindcss/vite` ≥ 4.2.2 | |
| Vitest · Playwright | locked | Unit/component · e2e. |
| PostgreSQL | 18.7 (`postgres:18.7`) | Every environment, incl. tests. No SQLite. |
| Redis | 8.12 (`redis:8.12`) | Cache/queue only. Check license fit (§7). |
| Qdrant | 1.20.0 (`qdrant/qdrant:v1.20.0`) | Upgrade one minor at a time. |

## 2. Repository layout (monorepo)
```
backend/   app/{api/v1,schemas,services,models,runner,agent,pipelines,providers,kb,connectors,storage,core}
           tests/  alembic/  pyproject.toml  uv.lock
frontend/  src/{pages,features,components,api,hooks,lib}  e2e/  package.json  package-lock.json  vite.config.ts
config/ports.env        Host & port catalog (§4)
scripts/check_ports.py  Catalog enforcement
docker-compose.dev.yml  .env.example  init.sh  init.ps1
```
Reference configs: `docs/stack/backend-pyproject.toml`, `docs/stack/settings.py`, `docs/stack/vite.config.ts`.

## 3. Commands (single source — init scripts mirror these)
| Purpose | Command (run in `backend/` or `frontend/`) |
|---|---|
| Services up | `docker compose --env-file config/ports.env --env-file .env -f docker-compose.dev.yml up -d --wait` (repo root) |
| Install | BE `uv sync --locked` · FE `npm ci` |
| Add dependency | BE `uv add <pkg>` · FE `npm install <pkg>` — then record license (§7) |
| Migrate | `uv run alembic upgrade head` |
| New migration | `uv run alembic revision --autogenerate -m "<feature-id>_<what>"` — review by hand |
| Port catalog | `python scripts/check_ports.py` (repo root) |
| Lint / format | BE `uv run ruff check . && uv run ruff format --check .` · FE `npm run lint` |
| Type check | BE `uv run mypy app` · FE `npm run typecheck` |
| Layer check | `uv run lint-imports` |
| Schema drift | `uv run alembic check` (models vs migrations) |
| Test | BE `uv run pytest -q` · FE `npm run test -- --run` · e2e `npx playwright test` |
| Build FE | `npm run build` |
| Secret scan | `gitleaks git --staged` (pre-commit) · `gitleaks dir .` (review) |
| Dependency audit | `uv run pip-audit` · `npm audit --omit=dev` |
| Dev servers | `uv run fastapi dev app/main.py` · `npm run dev` (host/port from catalog) |

Required npm scripts: `dev`, `build`, `lint`, `typecheck` (`tsc -b --noEmit`), `test` (`vitest`), `e2e` (`playwright test`).

**Verify = port catalog + BE (lint, format, types, layers, schema drift, tests) + FE (lint, types, tests, build).** All must pass before review. Playwright e2e runs at review and before merge.

## 4. Host & port catalog
- `config/ports.env` is the **only** place a host or port is defined. Docker compose, backend settings and Vite read it; `.env` may override a key per environment.
- Frontend calls **relative** `API_BASE_PATH` (same-origin). It never knows backend host/port; in dev the Vite proxy forwards, in prod the reverse proxy does.
- Vite uses `strictPort: true` — a port clash fails loudly instead of moving silently.
- New endpoint = new catalog entry with a comment (consumer → provider, protocol) + egress allowlist entry if outbound. Reviewed as design conformance.
- `scripts/check_ports.py` fails on: duplicate ports, host:port literals in `backend/app`, `frontend/src` or `vite.config`, compose ports not using `${..._PORT}`, `.env.example` shadowing a catalog port. Explicit exception: comment `ports-ok: <reason>` on the line.

## 5. Backend rules
### Layers (enforced by import-linter, see `docs/stack/backend-pyproject.toml`)
| Layer | Does | Must not |
|---|---|---|
| `api/v1` | Routers. **Authorization granted here**: one permission area per router + ownership guard on owned records. | Business logic, ORM queries. |
| `schemas` | Pydantic v2 request/response, action param specs (JSON Schema at `GET /api/v1/action-types`). | Import `models`. |
| `services` | Business logic; `api_side/` and `worker_side/`. | Import `api`. |
| `models` | SQLAlchemy 2.0 ORM. | Import `services`, `runner`, `agent`. |
| `runner` | Task executor + action registry. | Import `api`. |
| `agent` | `understand → retrieve → rerank → evidence → generate → verify` (LangGraph). | Call models except via `providers`. |
| `pipelines` | pdf_to_markdown, translate, chunk, clauses, metadata, expert. Pure. | Import `models`, `services`, `sqlalchemy`. |
| `providers` · `kb` · `connectors` · `storage` | Adapters: ollama/openai_compat/openrouter/local · Qdrant + embeddings · Trino(read)/Doris(write)/transfer · local/S3. | Import `services`, `runner`, `agent`, `models`. |
| `core` | Settings (loads catalog), secrets, egress allowlist, logging. | Import any other app layer. |

### SQLAlchemy 2.0
- Declarative with `Mapped[...]` + `mapped_column()`; no untyped `Column` on models.
- Queries with `select()` / `session.execute()` / `session.scalars()`; no legacy `session.query()`.
- One session per request via FastAPI dependency; services receive the session, never create engines.
- Sync vs async is decided once per project in the design and not mixed.
- Shared `MetaData(naming_convention=...)` so constraint names are stable for Alembic.

### Alembic
- Every schema change = one migration, message starts with the feature ID; autogenerate output is reviewed and edited by hand.
- Every migration has a working `downgrade()`; data migrations are separate from schema migrations.
- `alembic check` must be clean (no drift between models and migrations).
- Never edit a migration that is already on `main`; add a new one.

## 6. Frontend rules
- Server state: TanStack Query only. Transport: one Axios instance in `src/api/client.ts` with `baseURL = API_BASE_PATH`; no raw `fetch`.
- Same-origin REST/JSON/SSE; no tokens in `localStorage`.
- Action forms rendered from JSON Schema; never hand-code a form that has a schema.
- TypeScript `strict: true`; no `any` without a comment explaining why.
- Vitest for units/components; Playwright for user flows in `e2e/`, one spec per user-visible feature.

## 7. Security & compliance
- Secrets only from env / secret store via `core/settings`; `.env.example` committed, `.env` never.
- Every outbound host is in the egress allowlist and the port catalog. OpenRouter is metered and off-network: never send restricted data; gate by data classification.
- Auth: LDAP/AD (LDAPS); no local password store in prod.
- Licenses: record each new dependency's license; copyleft (AGPL/GPL/SSPL) needs review before adoption. Redis 8 is RSALv2/SSPLv1/AGPLv3 — confirm acceptable or use Valkey.

## 8. Testing rules
- Every feature adds tests incl. at least one negative case (authZ denial, invalid input).
- Every router has an authZ test: wrong permission area → 403; not owner → 403/404.
- Backend tests use a throwaway Postgres database; no network to providers/connectors (fake them).
