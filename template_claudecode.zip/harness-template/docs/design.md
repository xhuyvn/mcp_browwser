# Design (placeholder)
<!-- Replace with the Final design.md exported from the solution-architect workspace.
Requirements must carry stable IDs: FR-xx (functional), NFR-xx (non-functional), SEC-xx (security).
This file is read-only for agents (enforced by hook). -->
