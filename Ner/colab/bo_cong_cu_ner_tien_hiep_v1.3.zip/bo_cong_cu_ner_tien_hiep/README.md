# Bộ công cụ NER truyện tiên hiệp

**Phiên bản 1.3 — 17/11/2026**

Bộ công cụ để **xây dựng dữ liệu gán nhãn** và **fine-tune mô hình nhận diện thực thể (NER)** cho truyện tiên hiệp tiếng Việt.

- **6 nhãn:** `NHAN_VAT` · `DIA_DANH` · `VU_KHI` · `CONG_PHAP` · `DI_HOA` · `THE_LUC`
- **Mô hình gốc:** [`Fsoft-AIC/videberta-base`](https://huggingface.co/Fsoft-AIC/videberta-base)
- **Công cụ gán nhãn:** Label Studio (mã nguồn mở)

---

## Mục lục

1. [Bộ công cụ có gì](#1-bộ-công-cụ-có-gì)
2. [Quy trình tổng quan](#2-quy-trình-tổng-quan)
3. [Cài đặt](#3-cài-đặt)
4. [Chạy thử nhanh với dữ liệu mẫu](#4-chạy-thử-nhanh-với-dữ-liệu-mẫu)
5. [Quy trình với dữ liệu thật](#5-quy-trình-với-dữ-liệu-thật)
6. [Tham chiếu lệnh](#6-tham-chiếu-lệnh)
7. [Định dạng file](#7-định-dạng-file)
8. [Xử lý sự cố](#8-xử-lý-sự-cố)
9. [Lưu ý quan trọng](#9-lưu-ý-quan-trọng)

---

## 1. Bộ công cụ có gì

```
bo_cong_cu_ner_tien_hiep/
├── README.md                               ← tài liệu này
├── huong_dan_gan_nhan_ner_tien_hiep.docx   ← quy tắc gán nhãn, phát cho người gán nhãn
├── gan_nhan_nhap_tu_dien.py                ← gán nhãn nháp bằng từ điển + tìm tên mới
├── xay_dung_du_lieu.py                     ← pipeline dữ liệu: prepare / select / agreement / split / score
├── ner_finetune_tieng_viet.ipynb           ← huấn luyện, đánh giá, dự đoán
├── ner_colab_tron_goi.ipynb                ← chạy trọn gói trên Google Colab (huấn luyện + kiểm tra + lưu Drive)
├── label_studio_config.xml                 ← cấu hình giao diện Label Studio
├── tu_dien_mau.json, tu_dien_mau.csv       ← từ điển tên mẫu (2 định dạng, nội dung giống nhau)
├── requirements.txt                        ← thư viện cho notebook và lệnh score
├── requirements-label-studio.txt           ← Label Studio (cài ở môi trường riêng)
├── trien_khai/                             ← dùng mô hình sau khi train: xử lý file, API, Docker, gộp tên (xem trien_khai/README.md)
├── truyen_mau/                             ← 4 bộ truyện GIẢ LẬP để chạy thử (truyen_a … truyen_d)
└── vi_du_export/export_mau.json            ← file export Label Studio mẫu đã gán nhãn (600 câu)
```

| File | Ai dùng | Dùng để làm gì |
|---|---|---|
| `huong_dan_gan_nhan_ner_tien_hiep.docx` | Người gán nhãn, người review | Định nghĩa 6 nhãn, 8 quy tắc chung, 20 ca khó, bài tập, checklist |
| `gan_nhan_nhap_tu_dien.py` | Trưởng nhóm dữ liệu | Thử nhanh một từ điển trên văn bản, tìm cụm viết hoa chưa có trong từ điển để bổ sung. Script `xay_dung_du_lieu.py` cũng gọi lại các hàm trong file này |
| `xay_dung_du_lieu.py` | Trưởng nhóm dữ liệu, kỹ sư ML | Toàn bộ quy trình dữ liệu: tách câu, chọn câu cần gán nhãn, đo độ đồng thuận, tạo train/dev/test |
| `ner_finetune_tieng_viet.ipynb` | Kỹ sư ML | Huấn luyện ViDeBERTa, đánh giá F1 từng nhãn, phân tích lỗi, dự đoán văn bản mới |
| `ner_colab_tron_goi.ipynb` | Kỹ sư ML | Như trên nhưng **trọn gói trên Google Colab**: cài đặt, Drive, huấn luyện, lưu mô hình, chạy thử xử lý file, gộp tên, API (xem 3.4) |
| `trien_khai/` | Kỹ sư ML, kỹ sư hệ thống | Xử lý hàng loạt file truyện (CSV, HTML), API FastAPI, Docker, gộp tên đồng nhất (`gop_ten.py`) |

> ⚠️ **Hai file `.py` phải nằm cùng thư mục**, vì `xay_dung_du_lieu.py` dùng lại các hàm trong `gan_nhan_nhap_tu_dien.py`.

---

## 2. Quy trình tổng quan

```
[Bước 1] Thu thập truyện (.txt) + lập từ điển tên
    │
[Bước 2] gan_nhan_nhap_tu_dien.py ──► candidates.csv ──► bổ sung từ điển (lặp 2–3 lần)
    │
[Bước 3] xay_dung_du_lieu.py prepare ──► work/pool.jsonl   (tách câu, nhãn nháp, giữ riêng bộ test)
    │
[Bước 4] Cài Label Studio + phát tài liệu hướng dẫn cho người gán nhãn
    │
[Bước 5] Gán thử 100 câu ──► agreement ──► F1 ≥ 0,90 ?
    │                                         └─ chưa đạt ──► sửa quy tắc, gán thử lại
    │ đạt
[Bước 6] Vòng gán nhãn: select ──► Label Studio ──► export JSON ◄─┐
    │                                                             │ còn nhãn chưa đủ chỉ tiêu (❌)
    │ mọi nhãn đều ✅ ────────────────────────────────────────────┘
[Bước 7] split ──► data/train.jsonl, dev.jsonl, test.jsonl
    │
[Bước 8] Notebook: huấn luyện ──► ner-final/
    │
[Bước 9] (tuỳ chọn) score: mô hình tạo nhãn nháp + tìm câu khó ──► quay lại Bước 6
    │
[Bước 10] Triển khai: trien_khai/ (xử lý file hàng loạt, API, Docker)
    │
[Bước 11] Gộp tên đồng nhất: gop_ten.py ──► thuc_the.csv (danh sách nhân vật, địa danh…)
```

**Phân vai:**

| Vai trò | Phụ trách bước |
|---|---|
| **Trưởng nhóm dữ liệu** | 1, 2, 3, 4, 5 (đo đồng thuận, trả lời câu hỏi, ghi Sổ quyết định), 6 (chọn câu, import, export), 7 |
| **Người gán nhãn** | Đọc tài liệu `.docx`, làm bài tập, gán thử (5), gán nhãn các vòng (6) |
| **Người review** | Kiểm tra ngẫu nhiên khoảng 10% số câu mỗi vòng, báo lỗi kèm mã quy tắc |
| **Kỹ sư ML** | 8, 9, 10 (cùng kỹ sư hệ thống nếu triển khai API), 11 (người duyệt điền `can_duyet.csv`) |

---

## 3. Cài đặt

### 3.1 Hai script xử lý dữ liệu

Cần **Python 3.8 trở lên**. Không cần cài thư viện nào (chỉ dùng thư viện chuẩn).

```bash
python --version          # kiểm tra phiên bản
```

> Trên macOS/Linux, nếu lệnh `python` không có, hãy dùng `python3`.

### 3.2 Notebook huấn luyện

Cần **GPU** (khuyến nghị 16 GB VRAM) và **PyTorch ≥ 2.6**. Có thể chạy trên Google Colab (dùng bản trọn gói, xem 3.4), Amazon SageMaker hoặc một máy có GPU.

```bash
# 1. Cài PyTorch theo hướng dẫn tại https://pytorch.org (chọn đúng phiên bản CUDA)
# 2. Cài các thư viện còn lại
pip install -r requirements.txt
```

### 3.3 Label Studio

Nên cài trong **một môi trường ảo riêng**, vì Label Studio có nhiều thư viện phụ thuộc và dễ xung đột với `transformers`.

```bash
python -m venv .venv-ls
source .venv-ls/bin/activate        # Windows: .venv-ls\Scripts\activate
pip install -r requirements-label-studio.txt
label-studio start                  # mở trình duyệt tại http://localhost:8080
```

Khi nhiều người cùng gán nhãn, hãy nhờ bộ phận IT cài Label Studio trên một **máy chủ nội bộ** thay vì trên máy cá nhân.

### 3.4 Chạy trên Google Colab (không cần cài gì trên máy)

Dùng **`ner_colab_tron_goi.ipynb`**: chỉ cần **Run all**, notebook tự cài thư viện, lấy bộ công cụ từ Google Drive, huấn luyện, đánh giá, **lưu mô hình và báo cáo lên Drive**, rồi chạy thử `xu_ly_file.py`, `gop_ten.py` và API.

1. Trong **My Drive**, tạo thư mục `ner_tien_hiep`. Tải lên đó file zip của bộ công cụ và file `ner_colab_tron_goi.ipynb`.
2. Nhấp đúp file `.ipynb` trong Drive, chọn **Open with → Google Colaboratory**.
3. Chọn **Runtime → Change runtime type → T4 GPU**, rồi **Runtime → Run all**.

Lần đầu, giữ `DATA_SOURCE = demo` để chạy thử. Khi có dữ liệu thật:
- Tải các file export Label Studio (JSON) lên `ner_tien_hiep/exports/` và chọn `DATA_SOURCE = label_studio`.
- Hoặc đặt `train/dev/test.jsonl` vào `ner_tien_hiep/data/` và chọn `DATA_SOURCE = jsonl`.

Hướng dẫn chi tiết và bảng xử lý sự cố nằm ngay trong notebook.

> ⚠️ Đưa truyện có bản quyền hoặc dữ liệu nội bộ lên Google Drive/Colab tức là đưa dữ liệu ra ngoài hạ tầng của tổ chức. Hãy kiểm tra quy định nội bộ trước.

---

## 4. Chạy thử nhanh với dữ liệu mẫu

Phần này giúp bạn làm quen với toàn bộ quy trình trong khoảng **15–20 phút**, chưa cần dữ liệu thật hay người gán nhãn.

> `truyen_mau/` gồm 4 bộ truyện **giả lập**, sinh từ các mẫu câu và tên ngẫu nhiên. Đây không phải văn bản truyện thật.

Mở terminal và chuyển vào thư mục bộ công cụ:

```bash
cd bo_cong_cu_ner_tien_hiep
```

### 4.1 Thử từ điển

```bash
python gan_nhan_nhap_tu_dien.py --dict tu_dien_mau.json --input truyen_mau/truyen_a --out nhap/
```

Mở `nhap/report.txt` để xem mỗi nhãn tìm được bao nhiêu thực thể. Mở `nhap/candidates.csv` để xem các tên **chưa có trong từ điển** kèm nhãn gợi ý.

### 4.2 Chuẩn bị pool câu

```bash
python xay_dung_du_lieu.py prepare --input truyen_mau/ --dict tu_dien_mau.json --out work/ --test-novels truyen_d
```

Lệnh này tách các truyện thành khoảng 1.000 câu, bỏ câu trùng, và giữ riêng `truyen_d` làm tập test. Kết quả nằm trong `work/pool.jsonl`, báo cáo trong `work/prepare_report.txt`.

### 4.3 Chọn câu cho vòng 1

```bash
python xay_dung_du_lieu.py select --pool work/pool.jsonl --budget 200 --test-size 60 --target 100 --out work/vong1
```

Kết quả: `work/vong1/tasks_label_studio.json` (200 câu train + 60 câu test, có nhãn nháp) và báo cáo `work/vong1/select_report.txt`.

### 4.4 Xem thử trên Label Studio

1. Mở Label Studio, chọn **Create Project**, đặt tên là "Thử nghiệm".
2. Ở bước **Labeling Setup**, chọn **Custom template**, rồi dán toàn bộ nội dung `label_studio_config.xml` vào ô **Code**.
3. Ở bước **Data Import**, chọn file `work/vong1/tasks_label_studio.json`.
4. Bấm **Label All Tasks** và thử gán vài câu theo tài liệu hướng dẫn.

### 4.5 Đo đồng thuận và tạo dữ liệu huấn luyện

Bạn không cần gán hết 260 câu: dùng file export mẫu đã gán nhãn sẵn. Trong file này có 80 câu được 2 người cùng gán.

```bash
python xay_dung_du_lieu.py agreement --input vi_du_export/export_mau.json --out work/dong_thuan
python xay_dung_du_lieu.py split --input vi_du_export/export_mau.json --out data/ --target 100
```

- `agreement` in ra F1 đồng thuận của từng nhãn và ghi `work/dong_thuan/bat_dong.csv`. File mẫu được tạo sẵn với một số lỗi cố ý, nên F1 khoảng 0,87.
- `split` tạo `data/train.jsonl`, `dev.jsonl`, `test.jsonl`. Với dữ liệu mẫu, báo cáo sẽ có vài nhãn ❌ và cảnh báo: đây là ví dụ để bạn biết cách đọc báo cáo.

### 4.6 Huấn luyện

Mở `ner_finetune_tieng_viet.ipynb`, đặt `USE_DEMO_DATA = False` trong ô cấu hình, rồi chọn **Run All**.

> Muốn chạy thử notebook **mà không cần làm các bước trên**: giữ `USE_DEMO_DATA = True`. Notebook sẽ tự sinh 2.000 câu mẫu.

---

## 5. Quy trình với dữ liệu thật

### Bước 1. Thu thập truyện

Tạo thư mục `truyen/`. **Mỗi bộ truyện là một thư mục con, mỗi chương là một file `.txt`:**

```
truyen/
├── dau_pha_thuong_khung/
│   ├── chuong_001.txt
│   ├── chuong_002.txt
│   └── ...
├── pham_nhan_tu_tien/
├── tien_nghich/
├── the_gioi_hoan_my/
└── nguyen_ton/
```

**Yêu cầu:**
- **Từ 5 bộ truyện trở lên, của nhiều tác giả khác nhau.** Nếu chỉ dùng một bộ, mô hình sẽ học thuộc tên thay vì học ngữ cảnh.
- File lưu dạng **UTF-8**.
- Xoá quảng cáo website, chú thích của người dịch, mục lục.
- Chọn sẵn **1 bộ** (nên là bộ của tác giả khác) để **giữ riêng làm test**. Bộ này không bao giờ được dùng để train.
- Tên file chương có số (`chuong_001`, `chuong_2`…) để script sắp xếp đúng thứ tự.

### Bước 2. Lập từ điển tên

Tạo file `tu_dien.json` (hoặc `tu_dien.csv` nếu bạn quen soạn bằng Excel), theo mẫu `tu_dien_mau.json` / `tu_dien_mau.csv`:

```json
{
  "nhân vật":  ["Tiêu Viêm", "Nạp Lan Yên Nhiên", "Dược Lão"],
  "địa danh":  ["Vân Lam Sơn", "Ô Thản Thành"],
  "vũ khí":    ["Huyền Trọng Thước"],
  "công pháp": ["Phần Quyết", "Phật Nộ Hỏa Liên"],
  "dị hỏa":    ["Thanh Liên Địa Tâm Hỏa"],
  "thế lực":   ["Vân Lam Tông", "Tiêu gia"]
}
```

- Tên nhãn có thể viết tiếng Việt có dấu như trên, hoặc dùng mã (`NHAN_VAT`…).
- Nguồn gợi ý: trang wiki hoặc danh sách nhân vật của từng bộ truyện. Mỗi bộ khoảng 50–300 tên là đủ để bắt đầu.

Chạy thử từ điển và **bổ sung tên mới** (lặp 2–3 lần):

```bash
python gan_nhan_nhap_tu_dien.py --dict tu_dien.json --input truyen/ --out nhap/
```

Mở `nhap/candidates.csv`, chép các tên **đúng** vào từ điển với **đúng nhãn**, rồi chạy lại. Mở thêm `nhap/report.txt` để xem cảnh báo, ví dụ tên bị trùng ở 2 nhãn.

### Bước 3. Chuẩn bị pool câu

```bash
python xay_dung_du_lieu.py prepare --input truyen/ --dict tu_dien.json --out work/ --test-novels nguyen_ton
```

(`nguyen_ton` là tên **thư mục** của bộ truyện giữ riêng làm test.)

Kiểm tra `work/prepare_report.txt`:
- Số câu của từng bộ truyện, và bộ test có đúng như bạn chọn không.
- Số thực thể tìm được theo từng nhãn.
- Các cảnh báo, nếu có.

> **Nếu sau này bổ sung từ điển và chạy lại `prepare`:** luôn giữ nguyên `--test-novels`. Mã của mỗi câu được tính từ nội dung câu, nên các câu đã gán nhãn vẫn được nhận ra đúng.

### Bước 4. Cài Label Studio và chuẩn bị người gán nhãn

**Trưởng nhóm:**
1. Tạo **tài khoản riêng** cho từng người gán nhãn. Không dùng chung tài khoản, vì hệ thống cần biết ai gán câu nào để đo đồng thuận.
2. Tạo project chính, dán `label_studio_config.xml` vào **Labeling Interface → Code**.
3. Bật tùy chọn **dùng predictions để gán nhãn trước** (pre-label), để nhãn nháp hiện sẵn khi người gán mở câu. Tùy phiên bản, tùy chọn này nằm ở **Settings → Annotation** hoặc **Settings → Machine Learning**, và có thể phải chọn phiên bản mô hình: `dictionary`, hoặc `model` sau Bước 9.

**Người gán nhãn:**
1. Đọc `huong_dan_gan_nhan_ner_tien_hiep.docx`, từ mục 1 đến mục 5.
2. Làm bài tập ở mục 6.2 và tự chấm theo Phụ lục C (cần đạt từ 10/11 điểm).
3. Đọc mục 7 để biết cách thao tác trên Label Studio.

### Bước 5. Gán thử và đo độ đồng thuận

Chọn 100 câu thử. Đặt `--test-size 0` để không dùng tới phần test:

```bash
python xay_dung_du_lieu.py select --pool work/pool.jsonl --budget 100 --test-size 0 --out work/gan_thu
```

**Cách đơn giản và chạy được trên mọi phiên bản Label Studio:**
1. Tạo **2 project thử**, ví dụ "Gán thử – An" và "Gán thử – Bình", với cùng cấu hình.
2. Import **cùng một file** `work/gan_thu/tasks_label_studio.json` vào cả hai project.
3. Mỗi người gán toàn bộ project của mình, **không trao đổi với nhau**.
4. Export cả hai project ở định dạng **JSON** (`export_thu_an.json`, `export_thu_binh.json`).

```bash
python xay_dung_du_lieu.py agreement --input export_thu_an.json export_thu_binh.json --out work/dong_thuan
```

| F1 đồng thuận | Việc tiếp theo |
|---|---|
| **≥ 0,90** | Bắt đầu gán chính thức |
| **0,80 – 0,90** | Đọc `bat_dong.csv` cùng nhau, làm rõ quy tắc, gán thử thêm 50 câu |
| **< 0,80** | Sửa tài liệu hướng dẫn ở chỗ chưa rõ, gán thử lại 100 câu mới |

Mọi quyết định mới (cho các tình huống chưa có trong tài liệu) phải được ghi vào **Sổ quyết định** (xem mục 8.3 của tài liệu `.docx`).

### Bước 6. Các vòng gán nhãn

**Vòng 1.** Lệnh này cũng chọn luôn câu test, mặc định 300 câu:

```bash
python xay_dung_du_lieu.py select --pool work/pool.jsonl --budget 500 --already export_thu_an.json --out work/vong1
```

- `--already export_thu_an.json`: các câu đã gán trong vòng thử được tính là đã có, nên không bị chọn lại.
- Import `work/vong1/tasks_label_studio.json` vào **project chính**. Mọi người gán. Người review kiểm tra khoảng 10%.
- Xong vòng: export project chính ở định dạng **JSON**, đặt tên `export_vong1.json`.

**Vòng 2, 3…**

```bash
python xay_dung_du_lieu.py select --pool work/pool.jsonl --budget 500 \
       --already export_thu_an.json export_vong1.json --out work/vong2
```

> Nếu mọi vòng đều import vào **cùng một project chính**, file export mới nhất đã chứa toàn bộ câu đã gán, nên chỉ cần truyền file đó. Truyền thừa các file cũ cũng không sao: câu trùng được tự loại.

**Đọc `select_report.txt` sau mỗi vòng:**
- Cột `= tổng` so với `chỉ tiêu`: **dừng khi mọi nhãn đều ✅** (mặc định 300 thực thể mỗi nhãn trong train). Thường mất 3–6 vòng.
- Nhãn nào ❌ mà cột `+vòng này` bằng 0 và cột `+câu gợi ý` thấp: từ điển còn thiếu tên của nhãn đó. Hãy bổ sung từ `work/candidates.csv` rồi chạy lại `prepare` (Bước 3).
- Muốn ưu tiên riêng nhãn hiếm: thêm `--targets DI_HOA=400,VU_KHI=350`.

**Mỗi vòng nên đo đồng thuận lại:** cho khoảng 5% số câu được 2 người cùng gán (dùng 2 project như Bước 5), để phát hiện sớm khi mọi người bắt đầu gán lệch nhau.

### Bước 7. Tạo dữ liệu huấn luyện

```bash
python xay_dung_du_lieu.py split --input export_vong_cuoi.json --out data/
```

Đọc `data/split_report.txt`:

| Cột / cảnh báo | Ý nghĩa | Nếu không đạt |
|---|---|---|
| `train` so với `chỉ tiêu` | Số thực thể mỗi nhãn | Gán thêm một vòng |
| `#tên khác nhau` | Độ đa dạng của tên | Thêm câu từ các bộ truyện khác |
| `tên phổ biến nhất` > 30% | Một tên chiếm quá nhiều, mô hình dễ học thuộc tên đó | Thêm câu có tên khác; giảm `--max-per-name` khi chạy `select` |
| `test: tên mới` < 30% | Tập test chưa đo được khả năng nhận tên lạ | Chọn bộ test của tác giả khác |
| `test chỉ có N thực thể` | F1 của nhãn đó trên test không ổn định | Tăng `--test-size` hoặc `--test-target` ở vòng sau |
| `Câu không có thực thể` | Tỉ lệ mẫu âm, nên ở mức 10–30% | Tăng hoặc giảm `--neg-frac` khi chạy `select` |

Dev được tách **theo chương**. Test là **bộ truyện giữ riêng** từ Bước 3.

### Bước 8. Huấn luyện mô hình

1. Đặt thư mục `data/` **cạnh** file notebook (như cấu trúc của bộ công cụ).
2. Mở notebook, đặt `USE_DEMO_DATA = False`.
3. **Run All**. Với khoảng 3.000 câu, GPU 16 GB thường chạy xong trong vài chục phút.
4. Xem **mục 7** của notebook: F1 trên test **theo từng nhãn**. Xem **mục 8**: các câu mô hình đoán sai.
5. Mô hình được lưu vào `ner-final/`.

**Đọc kết quả:**
- Nhãn có F1 thấp: thường do **ít dữ liệu** (gán thêm) hoặc **gán không nhất quán** (đọc mục 8 của notebook, đối chiếu với tài liệu).
- F1 trên dev cao nhưng trên test thấp: mô hình đang **học thuộc tên**. Cần thêm bộ truyện và thêm tên đa dạng.

### Bước 9. (Tuỳ chọn) Dùng mô hình để tăng tốc gán nhãn

Sau khi có mô hình đầu tiên, nó gán nhãn nháp tốt hơn từ điển và chỉ ra được những câu nó còn chưa chắc chắn:

```bash
python xay_dung_du_lieu.py score --model ner-final --pool work/pool.jsonl --out work/pool_scored.jsonl
python xay_dung_du_lieu.py select --pool work/pool_scored.jsonl --uncertainty-weight 1.0 \
       --already export_vong_cuoi.json --out work/vong_tiep
```

Lệnh `score` cần `torch` và `transformers` (cài theo `requirements.txt`), và nên chạy trên máy có GPU. Khi import task mới, trong Label Studio chọn phiên bản mô hình `model` để hiện nhãn nháp từ mô hình.

### Bước 10. Triển khai mô hình

Xem chi tiết trong **[`trien_khai/README.md`](trien_khai/README.md)**. Tóm tắt:

```bash
cd trien_khai
pip install -r requirements-deploy.txt

# Thử nhanh 1 câu
python xu_ly_file.py --model ../ner-final --text "Tiêu Viêm thi triển Phật Nộ Hỏa Liên."

# Xử lý cả thư mục truyện -> entities.csv, tong_hop.csv (danh sách tên), HTML tô màu
python xu_ly_file.py --model ../ner-final --input ../truyen/ --out ket_qua/ --dict ../tu_dien.json --html

# API nội bộ (tài liệu tương tác tại http://localhost:8000/docs)
MODEL_DIR=../ner-final API_KEY=doi-mat-khau-nay uvicorn api:app --host 0.0.0.0 --port 8000
```

Trong notebook (mục 10) vẫn có sẵn hàm `extract_entities(text)` để thử nhanh.

### Bước 11. Gộp tên đồng nhất

Gom các cách gọi của cùng một thực thể ("Nạp Lan Yên Nhiên" / "Yên Nhiên", "Ô Thản Thành" / "Ô Thản"…) thành một mã thực thể. Xem mục **D** trong [`trien_khai/README.md`](trien_khai/README.md).

```bash
cd trien_khai
python gop_ten.py gop --input ket_qua/entities.jsonl --out lien_ket/
# điền cột quyet_dinh trong lien_ket/can_duyet.csv (y/n), rồi:
python gop_ten.py ap-dung --review lien_ket/can_duyet.csv --alias bi_danh.json
python gop_ten.py gop --input ket_qua/entities.jsonl --alias bi_danh.json --out lien_ket/
```

Kết quả `xung_dot_nhan.csv` (tên bị gán 2 nhãn) và `tu_dien_mo_rong.json` (từ điển tên đã gộp) dùng được để cải thiện vòng gán nhãn tiếp theo.

---

## 6. Tham chiếu lệnh

Xem đầy đủ tham số bằng `python xay_dung_du_lieu.py <lệnh> --help`.

### `gan_nhan_nhap_tu_dien.py`

| Tham số | Mặc định | Ý nghĩa |
|---|---|---|
| `--dict` | *(bắt buộc)* | Từ điển `.json` hoặc `.csv` |
| `--input` | *(bắt buộc)* | File `.txt` hoặc thư mục |
| `--out` | `nhap` | Thư mục kết quả |
| `--keep-empty` | `0.2` | Tỉ lệ giữ lại câu không có thực thể |
| `--ignore-case` | tắt | Khớp không phân biệt hoa/thường. Dễ khớp nhầm chữ thường như "hỏa", nên không khuyến khích |

### `xay_dung_du_lieu.py prepare`

| Tham số | Mặc định | Ý nghĩa |
|---|---|---|
| `--input` | *(bắt buộc)* | Thư mục truyện (mỗi bộ một thư mục con) |
| `--dict` | — | Từ điển tên |
| `--out` | `work` | Thư mục kết quả |
| `--test-novels` | tự chọn | Tên thư mục bộ truyện giữ riêng làm test. Nếu không truyền: có từ 3 bộ trở lên thì tự chọn một bộ chiếm khoảng 15% số câu; ít hơn 3 bộ thì lấy các chương cuối |
| `--min-tokens` / `--max-tokens` | `4` / `80` | Bỏ câu quá ngắn hoặc quá dài |

### `xay_dung_du_lieu.py select`

| Tham số | Mặc định | Ý nghĩa |
|---|---|---|
| `--pool` | *(bắt buộc)* | `work/pool.jsonl`, hoặc `pool_scored.jsonl` sau khi chạy `score` |
| `--budget` | `500` | Số câu **train** chọn trong vòng này |
| `--already` | — | Các file export của những vòng trước |
| `--target` | `300` | Chỉ tiêu số thực thể mỗi nhãn trong train |
| `--targets` | — | Chỉ tiêu riêng từng nhãn, ví dụ `DI_HOA=400,VU_KHI=350` |
| `--test-size` | `300` | **Tổng** số câu test cần có (tính cả các vòng trước) |
| `--max-per-name` | `15` | Một tên đã xuất hiện quá số lần này thì gần như không còn được ưu tiên |
| `--max-novel-share` | `0.35` | Tỉ lệ tối đa số câu lấy từ một bộ truyện |
| `--random-frac` / `--neg-frac` | `0.15` / `0.10` | Tỉ lệ câu chọn ngẫu nhiên / câu không có thực thể |
| `--uncertainty-weight` | `0` | Đặt `1.0` sau khi chạy `score` để ưu tiên câu mô hình chưa chắc chắn |

### `xay_dung_du_lieu.py agreement` / `split` / `score`

| Lệnh | Tham số chính |
|---|---|
| `agreement` | `--input` (1 file export có 2 annotation mỗi câu, **hoặc** 2 file export), `--out` |
| `split` | `--input` (các file export), `--out data`, `--dev-ratio 0.1`, `--target`, `--targets` |
| `score` | `--model ner-final`, `--pool`, `--out`, `--batch-size 32`, `--max-len 256` |

---

## 7. Định dạng file

| File | Định dạng |
|---|---|
| Truyện | `.txt` UTF-8, mỗi bộ truyện một thư mục con |
| Từ điển | JSON `{"nhãn": ["tên", ...]}`, hoặc CSV có 2 cột `name,label` |
| `work/pool.jsonl` | Mỗi dòng là một câu: `sid`, `novel`, `chapter`, `text`, `entities` (nhãn nháp), `candidates`, `cues`, `split` |
| `tasks_label_studio.json` | Task Label Studio: `data` (gồm text, sid, novel, chapter, split) + `predictions` |
| Export Label Studio | Hỗ trợ định dạng **JSON** (khuyên dùng) và **JSON-MIN** |
| `data/*.jsonl` | Mỗi dòng: `{"tokens": [...], "ner_tags": ["B-NHAN_VAT", "I-NHAN_VAT", "O", ...], "novel", "chapter", "sid"}` |

**Tách từ:** mọi công cụ dùng **chung một cách tách từ** (`simple_tokenize`: tách theo âm tiết và dấu câu, giữ nguyên số kiểu `5.000.000`). Khi tự viết code mới, hãy dùng đúng hàm này để kết quả khớp với lúc huấn luyện.

---

## 8. Xử lý sự cố

| Vấn đề | Cách xử lý |
|---|---|
| `Không đọc được câu nào` | Kiểm tra đường dẫn `--input`, đuôi file `.txt` và mã hoá UTF-8 (Notepad: *Save As → Encoding: UTF-8*) |
| Tiếng Việt hiển thị lỗi trên Windows | Script đã tự xử lý. Nếu vẫn lỗi, chạy `set PYTHONUTF8=1` trước khi chạy lệnh |
| `ModuleNotFoundError: gan_nhan_nhap_tu_dien` | Hai file `.py` phải nằm cùng thư mục |
| Label Studio không hiện nhãn nháp | Bật tùy chọn pre-label bằng predictions (Bước 4). Kiểm tra cấu hình giữ đúng `name="label"` và `name="text"` |
| `Không có câu nào được ≥ 2 người gán nhãn` | Dùng 2 project và 2 tài khoản khác nhau, rồi truyền 2 file export (Bước 5) |
| Báo cáo `select` có nhãn ❌ mãi không tăng | Từ điển thiếu tên của nhãn đó: bổ sung từ `candidates.csv`, chạy lại `prepare`. Hoặc tăng `--targets` cho nhãn đó |
| Notebook: lỗi khi nạp `pytorch_model.bin` | Nâng PyTorch lên ≥ 2.6 |
| Notebook: lỗi tokenizer | Cài `sentencepiece` và `protobuf`. Notebook đã bật sẵn `use_fast=True` |
| Notebook: `CUDA out of memory` | Giảm `BATCH_SIZE` (16 → 8) hoặc `MAX_LEN` (256 → 128) |
| Notebook: loss bằng `nan` | Giảm `LEARNING_RATE` xuống `2e-5`. Notebook đã ưu tiên bf16 nếu GPU hỗ trợ |
| Mô hình nhận đúng tên nhưng sai ranh giới | Thường do dữ liệu gán không nhất quán (quy tắc R2): rà lại bằng mục 8 của notebook |
| Muốn thêm hoặc bớt nhãn | Sửa `label_studio_config.xml` và tài liệu `.docx`, rồi gán lại dữ liệu liên quan. Notebook và script tự đọc danh sách nhãn từ dữ liệu |

---

## 9. Lưu ý quan trọng

- **Bản quyền:** văn bản truyện thường có bản quyền. Chỉ dùng **nội bộ cho mục đích nghiên cứu**. Không công bố lại dữ liệu hay mô hình khi chưa được phép.
- **Bảo mật:** chạy Label Studio và huấn luyện trên hạ tầng được tổ chức phê duyệt.
- **Dữ liệu mẫu** trong `truyen_mau/` và `vi_du_export/` là **giả lập**, chỉ dùng để chạy thử. Điểm số trên dữ liệu này không phản ánh chất lượng trên truyện thật.
- **Tên riêng trong tài liệu hướng dẫn** lấy từ truyện Đấu Phá Thương Khung; một số tên được đặt thêm để minh hoạ. Nếu dự án dùng bản dịch khác, hãy thay bằng tên trong bản dịch đó.
- **Tình trạng kiểm thử của phiên bản 1.0:**
  - ✅ Đã chạy thử trên dữ liệu giả lập: `gan_nhan_nhap_tu_dien.py`; các lệnh `prepare`, `select`, `agreement`, `split`; phần dữ liệu của notebook (sinh dữ liệu, đọc, chia tập, thống kê, tra từ điển).
  - ⚠️ **Chưa chạy thử:** phần huấn luyện và dự đoán của notebook, lệnh `score` (cần GPU), và việc import/export trên giao diện Label Studio thật. Khi chạy lần đầu, hãy thử với ít dữ liệu trước.

### Lịch sử phiên bản

| Phiên bản | Ngày | Thay đổi |
|---|---|---|
| 1.0 | 12/11/2026 | Bản đầu tiên |
| 1.1 | 12/11/2026 | Thêm thư mục `trien_khai/`: xử lý file hàng loạt, API FastAPI, Docker |
| 1.2 | 13/11/2026 | Thêm `trien_khai/gop_ten.py` (gộp tên đồng nhất) và `bi_danh_mau.json` |
| 1.2.1 | 17/11/2026 | Sửa lỗi bf16 trên GPU T4 (Colab miễn phí) |
| 1.3 | 17/11/2026 | Thêm `ner_colab_tron_goi.ipynb`; bỏ ví dụ ngân hàng còn sót trong notebook |
