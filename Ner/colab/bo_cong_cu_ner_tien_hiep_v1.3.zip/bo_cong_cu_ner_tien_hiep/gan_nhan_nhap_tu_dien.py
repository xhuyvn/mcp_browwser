#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Gán nhãn nháp NER bằng từ điển (dictionary-based pre-labeling) cho truyện tiên hiệp.

Đầu vào
  - Từ điển tên thực thể: JSON  {"NHAN_VAT": ["Tiêu Viêm", ...], "DI_HOA": [...]}
                         hoặc CSV có 2 cột: name,label
  - Văn bản thô: một hoặc nhiều file .txt, hoặc thư mục chứa .txt (UTF-8)

Đầu ra (trong --out)
  - draft.jsonl               : mỗi dòng {"tokens", "ner_tags", ...} -> đưa thẳng vào notebook
  - label_studio_tasks.json   : task kèm "predictions" -> import vào Label Studio để người sửa
  - candidates.csv            : cụm viết hoa CHƯA có trong từ điển + nhãn gợi ý -> để bổ sung từ điển
  - report.txt                : thống kê

Cách chạy
  python gan_nhan_nhap_tu_dien.py --dict tu_dien.json --input truyen/ --out nhap/
  python gan_nhan_nhap_tu_dien.py --dict tu_dien.csv --input chuong1.txt chuong2.txt --keep-empty 0.1

LƯU Ý: đây là nhãn NHÁP. Từ điển không hiểu ngữ cảnh và bỏ sót tên chưa có trong từ điển,
nên luôn cần người kiểm tra lại trước khi dùng để huấn luyện.
"""

import argparse
import csv
import json
import os
import random
import re
import sys
import unicodedata
from collections import Counter, defaultdict

# ---------------------------------------------------------------------------
# Tách từ: PHẢI giống hàm simple_tokenize trong notebook
# ---------------------------------------------------------------------------
TOKEN_RE = re.compile(r"\w+(?:[.,/:\-]\w+)*|[^\w\s]", re.UNICODE)

# Cho phép viết nhãn bằng tiếng Việt trong từ điển
LABEL_ALIASES = {
    "nhân vật": "NHAN_VAT",
    "địa danh": "DIA_DANH",
    "vũ khí": "VU_KHI",
    "công pháp": "CONG_PHAP",
    "dị hỏa": "DI_HOA",
    "thế lực": "THE_LUC",
    "tông môn": "THE_LUC",
}

# Khi một tên nằm trong nhiều nhãn: nhãn đứng trước được ưu tiên
LABEL_PRIORITY = ["DI_HOA", "CONG_PHAP", "VU_KHI", "NHAN_VAT", "THE_LUC", "DIA_DANH"]

# Gợi ý nhãn cho cụm chưa có trong từ điển (dựa vào từ đứng trước / từ cuối cụm)
CONTEXT_BEFORE = {
    "CONG_PHAP": ["thi triển", "vận chuyển", "tu luyện", "thi pháp", "chiêu", "đấu kỹ", "công pháp", "bí kỹ"],
    "DIA_DANH": ["tại", "đến", "tới", "rời khỏi", "đỉnh", "núi", "thành", "trấn", "sơn mạch", "đại lục"],
    "VU_KHI": ["thanh", "cây", "nắm chặt", "rút", "vung", "cầm"],
    "NHAN_VAT": ["nói với", "nhìn", "gọi", "lão", "thiếu niên", "cô gái", "nàng", "hắn và"],
}
HEAD_WORD_LAST = {  # từ cuối cụm -> nhãn gợi ý
    "Hỏa": "DI_HOA", "Viêm": None,  # "Viêm" thường là tên người -> không gợi ý
    "Sơn": "DIA_DANH", "Thành": "DIA_DANH", "Cốc": "DIA_DANH", "Trấn": "DIA_DANH", "Lục": "DIA_DANH",
    "Tông": "THE_LUC", "Môn": "THE_LUC", "Gia": "THE_LUC", "Các": "THE_LUC", "Điện": "THE_LUC",
    "Quyết": "CONG_PHAP", "Chưởng": "CONG_PHAP", "Quyền": "CONG_PHAP", "Chỉ": "CONG_PHAP",
    "Kiếm": "VU_KHI", "Đao": "VU_KHI", "Thước": "VU_KHI", "Thương": "VU_KHI",
}


def nfc(s):
    """Chuẩn hoá Unicode NFC: tránh lỗi chữ Việt dựng sẵn / tổ hợp trông giống nhau nhưng khác mã."""
    return unicodedata.normalize("NFC", s)


def tokenize_with_offsets(text):
    return [(m.group(), m.start(), m.end()) for m in TOKEN_RE.finditer(text)]


def split_sentences(text):
    """Tách câu theo . ! ? … và xuống dòng; giữ dấu ngoặc kép đóng đi kèm câu."""
    parts = re.split(r"(?<=[.!?…])\s+|(?<=[.!?…][\"”’)\]])\s+|\n+", text)
    return [p.strip() for p in parts if p and p.strip()]


# ---------------------------------------------------------------------------
# Từ điển
# ---------------------------------------------------------------------------
def normalize_label(label):
    lab = nfc(label.strip())
    lab = LABEL_ALIASES.get(lab.lower(), lab)
    lab = lab.upper().replace(" ", "_")
    if not re.fullmatch(r"[A-Z0-9_]+", lab):
        raise ValueError(f"Tên nhãn không hợp lệ: '{label}'. Dùng mã không dấu, ví dụ NHAN_VAT.")
    return lab


def load_dictionary(path):
    pairs = []
    if path.lower().endswith(".json"):
        with open(path, encoding="utf-8") as f:
            data = json.load(f)
        for label, names in data.items():
            for name in names:
                pairs.append((name, label))
    elif path.lower().endswith(".csv"):
        with open(path, encoding="utf-8-sig", newline="") as f:
            for row in csv.DictReader(f):
                if row.get("name") and row.get("label"):
                    pairs.append((row["name"], row["label"]))
    else:
        raise ValueError("Từ điển phải là .json hoặc .csv")

    entries, conflicts = {}, defaultdict(set)
    for name, label in pairs:
        name, label = nfc(name.strip()), normalize_label(label)
        if not name:
            continue
        key = tuple(TOKEN_RE.findall(name))
        conflicts[key].add(label)
        old = entries.get(key)
        if old is None or _priority(label) < _priority(old):
            entries[key] = label

    conflict_list = {" ".join(k): sorted(v) for k, v in conflicts.items() if len(v) > 1}
    return entries, conflict_list


def _priority(label):
    return LABEL_PRIORITY.index(label) if label in LABEL_PRIORITY else len(LABEL_PRIORITY)


def build_index(entries, ignore_case):
    """Nhóm theo từ đầu tiên để tra nhanh; sắp xếp cụm dài trước (longest match)."""
    index = defaultdict(list)
    for key, label in entries.items():
        k = tuple(w.lower() for w in key) if ignore_case else key
        index[k[0]].append((k, label))
    for first in index:
        index[first].sort(key=lambda x: -len(x[0]))
    return index


# ---------------------------------------------------------------------------
# Gán nhãn
# ---------------------------------------------------------------------------
def label_sentence(words, index, ignore_case):
    cmp = [w.lower() for w in words] if ignore_case else words
    tags = ["O"] * len(words)
    spans = []  # (start_tok, end_tok_exclusive, label)
    i = 0
    while i < len(words):
        matched = False
        for key, label in index.get(cmp[i], []):
            n = len(key)
            if tuple(cmp[i:i + n]) == key:
                tags[i] = f"B-{label}"
                for j in range(i + 1, i + n):
                    tags[j] = f"I-{label}"
                spans.append((i, i + n, label))
                i += n
                matched = True
                break
        if not matched:
            i += 1
    return tags, spans


def is_cap(w):
    return w[:1].isupper() and w.isalpha()


def find_candidates(words, tags, sent):
    """Tìm cụm >= 2 từ viết hoa liên tiếp chưa được gán nhãn."""
    out = []
    i = 0
    while i < len(words):
        if tags[i] == "O" and is_cap(words[i]):
            j = i
            while j < len(words) and tags[j] == "O" and is_cap(words[j]):
                j += 1
            if j - i >= 2:
                phrase = " ".join(words[i:j])
                before = " ".join(words[max(0, i - 3):i]).lower()
                out.append((phrase, suggest_label(words[i:j], before), sent))
            i = j
        else:
            i += 1
    return out


def suggest_label(phrase_words, before):
    last = phrase_words[-1]
    if last in HEAD_WORD_LAST and HEAD_WORD_LAST[last]:
        return HEAD_WORD_LAST[last]
    for label, cues in CONTEXT_BEFORE.items():
        if any(before.endswith(c) for c in cues):
            return label
    return ""


# ---------------------------------------------------------------------------
# Đọc file
# ---------------------------------------------------------------------------
def collect_files(inputs):
    files = []
    for p in inputs:
        if os.path.isdir(p):
            for root, _, names in os.walk(p):
                files += [os.path.join(root, n) for n in sorted(names) if n.lower().endswith(".txt")]
        elif os.path.isfile(p):
            files.append(p)
        else:
            print(f"⚠️ Bỏ qua, không tìm thấy: {p}")
    return files


def run(dict_path, inputs, out_dir, ignore_case=False, keep_empty=0.2, seed=42, min_tokens=3):
    rng = random.Random(seed)
    entries, conflicts = load_dictionary(dict_path)
    index = build_index(entries, ignore_case)
    os.makedirs(out_dir, exist_ok=True)

    records, ls_tasks = [], []
    ent_counter, name_counter = Counter(), Counter()
    cand_counter, cand_label, cand_example = Counter(), {}, {}
    n_sent = n_empty_kept = 0

    for path in collect_files(inputs):
        with open(path, encoding="utf-8") as f:
            text = nfc(f.read())
        for sent in split_sentences(text):
            toks = tokenize_with_offsets(sent)
            if len(toks) < min_tokens:
                continue
            n_sent += 1
            words = [t[0] for t in toks]
            tags, spans = label_sentence(words, index, ignore_case)

            for phrase, sug, ex in find_candidates(words, tags, sent):
                cand_counter[phrase] += 1
                if sug and not cand_label.get(phrase):
                    cand_label[phrase] = sug
                cand_example.setdefault(phrase, ex)

            if not spans:
                if rng.random() >= keep_empty:
                    continue
                n_empty_kept += 1

            for s, e, lab in spans:
                ent_counter[lab] += 1
                name_counter[(" ".join(words[s:e]), lab)] += 1

            records.append({"tokens": words, "ner_tags": tags, "text": sent,
                            "source": os.path.basename(path), "n_entities": len(spans)})
            ls_tasks.append({
                "data": {"text": sent, "source": os.path.basename(path)},
                "predictions": [{
                    "model_version": "dictionary_v1",
                    "result": [{
                        "id": f"r{k}",
                        "from_name": "label", "to_name": "text", "type": "labels",
                        "value": {"start": toks[s][1], "end": toks[e - 1][2],
                                  "text": sent[toks[s][1]:toks[e - 1][2]], "labels": [lab]},
                    } for k, (s, e, lab) in enumerate(spans)],
                }],
            })

    # ---- Ghi file ----
    with open(os.path.join(out_dir, "draft.jsonl"), "w", encoding="utf-8") as f:
        for r in records:
            f.write(json.dumps(r, ensure_ascii=False) + "\n")
    with open(os.path.join(out_dir, "label_studio_tasks.json"), "w", encoding="utf-8") as f:
        json.dump(ls_tasks, f, ensure_ascii=False, indent=1)
    with open(os.path.join(out_dir, "candidates.csv"), "w", encoding="utf-8-sig", newline="") as f:
        w = csv.writer(f)
        w.writerow(["name", "count", "suggested_label", "example"])
        for phrase, c in cand_counter.most_common():
            w.writerow([phrase, c, cand_label.get(phrase, ""), cand_example[phrase]])

    lines = [
        f"Từ điển: {len(entries)} tên | xung đột nhãn: {len(conflicts)}",
        f"Số câu đã xử lý: {n_sent}",
        f"Số câu xuất ra: {len(records)} (trong đó {n_empty_kept} câu không có thực thể, giữ làm mẫu âm)",
        "",
        "Số thực thể theo nhãn:",
        *[f"  {lab:<12} {c}" for lab, c in ent_counter.most_common()],
        "",
        "Tên khớp nhiều nhất:",
        *[f"  {n:<30} {lab:<12} {c}" for (n, lab), c in name_counter.most_common(20)],
        "",
        "Tên trong từ điển KHÔNG xuất hiện lần nào:",
        *[f"  {' '.join(k)} ({lab})" for k, lab in entries.items()
          if (" ".join(k), lab) not in name_counter][:50],
        "",
        f"Cụm viết hoa chưa có trong từ điển: {len(cand_counter)} (xem candidates.csv)",
        *[f"  {p:<30} x{c:<4} gợi ý: {cand_label.get(p, '?')}" for p, c in cand_counter.most_common(20)],
    ]
    if conflicts:
        lines += ["", "⚠️ Tên có nhiều nhãn (đã chọn theo LABEL_PRIORITY):",
                  *[f"  {n}: {labs}" for n, labs in conflicts.items()]]
    report = "\n".join(lines)
    with open(os.path.join(out_dir, "report.txt"), "w", encoding="utf-8") as f:
        f.write(report + "\n")
    print(report)
    print(f"\n✅ Đã ghi kết quả vào: {out_dir}")
    return records


def main():
    # Tránh lỗi hiển thị tiếng Việt / emoji trên console Windows
    for _s in (sys.stdout, sys.stderr):
        try:
            _s.reconfigure(encoding="utf-8", errors="replace")
        except Exception:
            pass
    ap = argparse.ArgumentParser(description="Gán nhãn nháp NER bằng từ điển")
    ap.add_argument("--dict", required=True, help="File từ điển .json hoặc .csv")
    ap.add_argument("--input", required=True, nargs="+", help="File .txt hoặc thư mục")
    ap.add_argument("--out", default="nhap", help="Thư mục đầu ra (mặc định: nhap)")
    ap.add_argument("--ignore-case", action="store_true",
                    help="Khớp không phân biệt hoa/thường (dễ khớp nhầm từ thường, vd. 'hỏa')")
    ap.add_argument("--keep-empty", type=float, default=0.2,
                    help="Tỉ lệ giữ lại câu không có thực thể (0-1, mặc định 0.2)")
    ap.add_argument("--min-tokens", type=int, default=3, help="Bỏ câu ngắn hơn N từ")
    ap.add_argument("--seed", type=int, default=42)
    a = ap.parse_args()
    run(a.dict, a.input, a.out, a.ignore_case, a.keep_empty, a.seed, a.min_tokens)


if __name__ == "__main__":
    main()
