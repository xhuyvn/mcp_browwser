#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Xây dựng bộ dữ liệu NER hiệu quả cho truyện tiên hiệp — pipeline bán tự động.

Cấu trúc thư mục truyện (tên thư mục con = tên bộ truyện, tên file = chương):
    truyen/
      dau_pha_thuong_khung/   chuong_001.txt, chuong_002.txt, ...
      pham_nhan_tu_tien/      ...
      tien_nghich/            ...

Các lệnh:
  prepare   : đọc truyện -> tách câu -> khử trùng lặp -> gán nhãn nháp bằng từ điển
              -> chọn bộ/chương giữ riêng làm TEST -> pool.jsonl
  select    : chọn câu cần gán nhãn theo chỉ tiêu (bù nhãn hiếm, trộn nhiều bộ truyện,
              giới hạn tên lặp lại) -> file import Label Studio
  agreement : đo độ đồng thuận giữa 2 người gán nhãn trên cùng các câu
  split     : export Label Studio -> BIO, chia train/dev/test theo bộ truyện & chương,
              kiểm tra chỉ tiêu -> train/dev/test.jsonl cho notebook
  score     : (tuỳ chọn, từ vòng 2) mô hình đã train chấm độ "khó" + gán nhãn nháp cho pool

Ví dụ:
  python xay_dung_du_lieu.py prepare --input truyen/ --dict tu_dien.json --out work/
  python xay_dung_du_lieu.py select  --pool work/pool.jsonl --budget 500 --out work/vong1
  python xay_dung_du_lieu.py agreement --input export_thu_nghiem.json --out work/dong_thuan
  python xay_dung_du_lieu.py select  --pool work/pool.jsonl --budget 500 --already export_vong1.json --out work/vong2
  python xay_dung_du_lieu.py split   --input export_vong1.json export_vong2.json --out data/

Yêu cầu: Python 3.8+, file gan_nhan_nhap_tu_dien.py nằm cùng thư mục.
Lệnh score cần thêm: torch, transformers.
"""

import argparse
import csv
import hashlib
import json
import math
import os
import random
import re
import sys
from collections import Counter, defaultdict

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from gan_nhan_nhap_tu_dien import (  # noqa: E402
    nfc, tokenize_with_offsets, split_sentences,
    load_dictionary, build_index, label_sentence, find_candidates,
)

# Từ khoá ngữ cảnh: nếu câu có cụm viết hoa CHƯA có trong từ điển và chứa các từ này,
# câu đó có khả năng chứa thực thể của nhãn tương ứng -> ưu tiên chọn để gán nhãn.
KEYWORD_CUES = {
    "DI_HOA": ["dị hỏa", "dị hoả", "ngọn lửa", "hỏa diễm", "hoả diễm", "luyện hóa", "luyện hoá", "thôn phệ"],
    "VU_KHI": ["kiếm", "đao", "thước", "thương", "binh khí", "pháp bảo", "vũ khí", "rút", "vung"],
    "CONG_PHAP": ["thi triển", "công pháp", "đấu kỹ", "bí kỹ", "võ kỹ", "tu luyện", "pháp quyết"],
    "DIA_DANH": ["sơn mạch", "đại lục", "đế quốc", "thành trì", "rời khỏi", "đi tới", "tiến vào"],
    "THE_LUC": ["tông", "gia tộc", "môn phái", "đệ tử", "trưởng lão", "tông chủ"],
}
_CUE_RE = {lab: re.compile(r"(?<!\w)(?:" + "|".join(map(re.escape, kws)) + r")(?!\w)")
           for lab, kws in KEYWORD_CUES.items()}
_STRIP_CHARS = set(" \t\r\n.,;:!?\"'“”‘’()[]…-–—")


# ---------------------------------------------------------------------------
# Tiện ích
# ---------------------------------------------------------------------------
def read_jsonl(path):
    with open(path, encoding="utf-8") as f:
        return [json.loads(line) for line in f if line.strip()]


def write_jsonl(path, rows):
    os.makedirs(os.path.dirname(os.path.abspath(path)), exist_ok=True)
    with open(path, "w", encoding="utf-8") as f:
        for r in rows:
            f.write(json.dumps(r, ensure_ascii=False) + "\n")


def write_text(path, text):
    with open(path, "w", encoding="utf-8") as f:
        f.write(text + "\n")


def text_key(s):
    norm = re.sub(r"\s+", " ", nfc(s).strip().lower())
    return hashlib.sha1(norm.encode("utf-8")).hexdigest()[:16]


def natkey(s):
    return [int(t) if t.isdigit() else t for t in re.split(r"(\d+)", s)]


def parse_targets(s):
    out = {}
    for part in (s or "").split(","):
        if "=" in part:
            k, v = part.split("=", 1)
            out[k.strip().upper()] = int(v)
    return out


def keyword_cues(sentence):
    low = sentence.lower()
    return {lab for lab, rx in _CUE_RE.items() if rx.search(low)}


def bio_spans(tags):
    """BIO -> list (start_tok, end_tok_exclusive, label); chấp nhận I- đứng đầu."""
    spans, cur = [], None
    for i, t in enumerate(tags + ["O"]):
        if t.startswith("B-") or t == "O" or (t.startswith("I-") and (cur is None or cur[2] != t[2:])):
            if cur:
                spans.append((cur[0], i, cur[2]))
                cur = None
            if t != "O":
                cur = [i, None, t[2:]]
    return spans


def iter_corpus(inputs):
    """Sinh (bộ truyện, chương, đường dẫn) cho mọi file .txt."""
    for root in inputs:
        if os.path.isfile(root):
            stem = os.path.splitext(os.path.basename(root))[0]
            yield stem, stem, root
            continue
        if not os.path.isdir(root):
            print(f"⚠️ Bỏ qua, không tìm thấy: {root}")
            continue
        for dirpath, dirnames, names in os.walk(root):
            dirnames.sort()
            for n in sorted(names, key=natkey):
                if not n.lower().endswith(".txt"):
                    continue
                p = os.path.join(dirpath, n)
                rel = os.path.relpath(p, root).split(os.sep)
                if len(rel) == 1:
                    novel = chapter = os.path.splitext(rel[0])[0]
                else:
                    novel, chapter = rel[0], os.path.splitext("/".join(rel[1:]))[0]
                yield novel, chapter, p


def ents(r):
    """Thực thể dự kiến của câu: dự đoán mô hình (nếu có) + từ điển (không chồng lấn)."""
    model = r.get("model_entities")
    if model is None:
        return r.get("entities", [])
    out = list(model)
    for e in r.get("entities", []):
        if all(e["end"] <= m["start"] or e["start"] >= m["end"] for m in model):
            out.append(e)
    return out


# ---------------------------------------------------------------------------
# 1) PREPARE
# ---------------------------------------------------------------------------
def assign_test_split(pool, test_novels, chapter_frac):
    novels = Counter(r["novel"] for r in pool)
    if test_novels:
        unknown = set(test_novels) - set(novels)
        if unknown:
            print(f"⚠️ Không có bộ truyện: {sorted(unknown)}. Các bộ hiện có: {sorted(novels)}")
        chosen = set(test_novels) & set(novels)
        mode = "novel"
    elif len(novels) >= 3:
        total = sum(novels.values())
        chosen = {min(novels, key=lambda n: abs(novels[n] - 0.15 * total))}
        mode = "novel"
    else:
        chosen, mode = set(), "chapter"

    if mode == "novel" and chosen:
        for r in pool:
            r["split"] = "test" if r["novel"] in chosen else "train"
        return f"theo BỘ TRUYỆN: {sorted(chosen)}"

    chapters = defaultdict(set)
    for r in pool:
        chapters[r["novel"]].add(r["chapter"])
    test_ch = set()
    for n, chs in chapters.items():
        chs = sorted(chs, key=natkey)
        if len(chs) > 1:
            k = max(1, round(len(chs) * chapter_frac))
            test_ch |= {(n, c) for c in chs[-k:]}
    for r in pool:
        r["split"] = "test" if (r["novel"], r["chapter"]) in test_ch else "train"
    if not test_ch:
        return "⚠️ KHÔNG có tập test (mỗi bộ chỉ có 1 chương). Hãy thêm chương hoặc bộ truyện."
    return f"theo CHƯƠNG CUỐI của mỗi bộ ({len(test_ch)} chương) — nên có ≥ 3 bộ để giữ riêng cả bộ"


def cmd_prepare(a):
    entries, conflicts = load_dictionary(a.dict) if a.dict else ({}, {})
    index = build_index(entries, False)
    os.makedirs(a.out, exist_ok=True)

    pool, seen = [], set()
    n_raw = n_dup = n_len = 0
    cand_count, cand_novels, cand_ex, cand_lab = Counter(), defaultdict(set), {}, {}

    for novel, chapter, path in iter_corpus(a.input):
        with open(path, encoding="utf-8", errors="replace") as f:
            text = nfc(f.read())
        for k, sent in enumerate(split_sentences(text)):
            n_raw += 1
            toks = tokenize_with_offsets(sent)
            if not (a.min_tokens <= len(toks) <= a.max_tokens):
                n_len += 1
                continue
            key = text_key(sent)
            if key in seen:
                n_dup += 1
                continue
            seen.add(key)
            words = [t[0] for t in toks]
            tags, spans = label_sentence(words, index, False)
            cands = find_candidates(words, tags, sent)
            cues = {lab for _, lab, _ in cands if lab}
            if cands:
                cues |= keyword_cues(sent)
            for phrase, lab, _ in cands:
                cand_count[phrase] += 1
                cand_novels[phrase].add(novel)
                cand_ex.setdefault(phrase, sent)
                if lab and not cand_lab.get(phrase):
                    cand_lab[phrase] = lab
            pool.append({
                "sid": key, "novel": novel, "chapter": chapter, "pos": k, "text": sent,
                "entities": [{"start": toks[s][1], "end": toks[e - 1][2], "label": lab,
                              "name": " ".join(words[s:e])} for s, e, lab in spans],
                "candidates": [c for c, _, _ in cands],
                "cues": sorted(cues),
            })

    if not pool:
        sys.exit("❌ Không đọc được câu nào. Kiểm tra --input (file .txt, UTF-8).")

    split_info = assign_test_split(pool, a.test_novels, a.test_chapter_frac)
    write_jsonl(os.path.join(a.out, "pool.jsonl"), pool)

    with open(os.path.join(a.out, "candidates.csv"), "w", encoding="utf-8-sig", newline="") as f:
        w = csv.writer(f)
        w.writerow(["name", "count", "n_novels", "suggested_label", "example"])
        for p, c in cand_count.most_common():
            if c >= a.min_candidate_count:
                w.writerow([p, c, len(cand_novels[p]), cand_lab.get(p, ""), cand_ex[p]])

    by_novel = defaultdict(Counter)
    for r in pool:
        by_novel[r["novel"]][r["split"]] += 1
    dict_lab = Counter(e["label"] for r in pool for e in r["entities"])
    cue_lab = Counter(l for r in pool for l in r["cues"])
    lines = [
        f"Câu đọc được: {n_raw} | bỏ do độ dài: {n_len} | trùng lặp: {n_dup} | giữ lại: {len(pool)}",
        f"Tập test: {split_info}",
        "",
        "Số câu theo bộ truyện (train / test):",
        *[f"  {n:<30} {c['train']:>7} / {c['test']:<7}" for n, c in sorted(by_novel.items())],
        "",
        "Thực thể tìm được bằng từ điển   |   số câu có gợi ý ngữ cảnh (chưa có trong từ điển):",
        *[f"  {lab:<12} {dict_lab.get(lab, 0):>7}   |   {cue_lab.get(lab, 0):>7}"
          for lab in sorted(set(dict_lab) | set(cue_lab))],
        "",
        f"Cụm viết hoa chưa có trong từ điển: {len(cand_count)} -> xem candidates.csv để bổ sung từ điển",
    ]
    if len(by_novel) < 3:
        lines.append("⚠️ Chỉ có %d bộ truyện. Nên dùng ≥ 5 bộ (khác tác giả) để mô hình không học thuộc tên."
                     % len(by_novel))
    if conflicts:
        lines.append(f"⚠️ {len(conflicts)} tên có nhiều nhãn trong từ điển (xem lại).")
    report = "\n".join(lines)
    write_text(os.path.join(a.out, "prepare_report.txt"), report)
    print(report)
    print(f"\n✅ Đã ghi: {os.path.join(a.out, 'pool.jsonl')}")


# ---------------------------------------------------------------------------
# Đọc dữ liệu đã gán nhãn (Label Studio JSON / JSON-MIN / jsonl dạng pool)
# ---------------------------------------------------------------------------
def _annotator(x):
    if isinstance(x, dict):
        return str(x.get("email") or x.get("id") or "?")
    return str(x if x is not None else "?")


def _spans_from_values(values):
    out = []
    for v in values or []:
        lab = v.get("label") if isinstance(v.get("label"), str) else None
        if not lab and v.get("labels"):
            lab = v["labels"][0]
        if lab is not None and "start" in v and "end" in v:
            out.append((int(v["start"]), int(v["end"]), str(lab).upper()))
    return out


def _mk(d, spans, annotator, updated="", order=0):
    text = d.get("text", "")
    return {
        "sid": d.get("sid") or text_key(text), "text": text,
        "novel": d.get("novel", "?"), "chapter": str(d.get("chapter", "?")),
        "split": d.get("split"), "spans": spans,
        "annotator": annotator, "updated": str(updated or ""), "order": order,
    }


def load_annotated(paths):
    out, order = [], 0
    for p in paths:
        base = os.path.basename(p)
        if p.lower().endswith(".jsonl"):
            for r in read_jsonl(p):
                order += 1
                out.append(_mk(r, _spans_from_values(r.get("entities")), base, order=order))
            continue
        with open(p, encoding="utf-8") as f:
            data = json.load(f)
        if isinstance(data, dict):
            data = [data]
        for t in data:
            if "annotations" in t:  # Label Studio "JSON" (đầy đủ)
                d = t.get("data", {})
                for ann in t.get("annotations", []):
                    if ann.get("was_cancelled"):
                        continue
                    order += 1
                    vals = [res.get("value", {}) for res in ann.get("result", []) if res.get("type") == "labels"]
                    out.append(_mk(d, _spans_from_values(vals), _annotator(ann.get("completed_by")),
                                   ann.get("updated_at") or ann.get("created_at"), order))
            elif "text" in t:  # Label Studio "JSON-MIN"
                order += 1
                vals = t.get("label") or []
                if isinstance(vals, dict):
                    vals = [vals]
                out.append(_mk(t, _spans_from_values(vals), _annotator(t.get("annotator", base)),
                               t.get("updated_at"), order))
    return out


def pick_final(anns):
    """Mỗi câu lấy bản gán nhãn cập nhật mới nhất (bản đã được review)."""
    final = {}
    for x in anns:
        cur = final.get(x["sid"])
        if cur is None or (x["updated"], x["order"]) >= (cur["updated"], cur["order"]):
            final[x["sid"]] = x
    return final


def to_bio(text, spans):
    toks = tokenize_with_offsets(text)
    tags = ["O"] * len(toks)
    st = Counter()
    for start, end, label in sorted(spans):
        while start < end and text[start] in _STRIP_CHARS:
            start += 1
        while end > start and text[end - 1] in _STRIP_CHARS:
            end -= 1
        idx = [i for i, (_, s, e) in enumerate(toks) if s < end and e > start]
        if not idx:
            st["span_rỗng"] += 1
            continue
        if toks[idx[0]][1] != start or toks[idx[-1]][2] != end:
            st["lệch_ranh_giới_từ"] += 1
        if any(tags[i] != "O" for i in idx):
            st["chồng_lấn"] += 1
            continue
        tags[idx[0]] = "B-" + label
        for i in idx[1:]:
            tags[i] = "I-" + label
    return [nfc(w) for w, _, _ in toks], tags, st


# ---------------------------------------------------------------------------
# 2) SELECT
# ---------------------------------------------------------------------------
def greedy_select(pool, budget, targets, have, a, rng):
    """Chọn câu: phần lớn theo 'độ thiếu' của từng nhãn, phần còn lại ngẫu nhiên + câu âm."""
    budget = min(budget, len(pool))
    if budget <= 0:
        return []
    counts = Counter({k: float(v) for k, v in have.items()})
    name_cnt, novel_cnt = Counter(), Counter()
    chosen, selected = set(), []
    n_novels = len({r["novel"] for r in pool})
    novel_cap = budget if n_novels <= 1 else max(math.ceil(budget * a.max_novel_share),
                                                 math.ceil(budget / n_novels))

    def take(r, how):
        selected.append((r, how))
        chosen.add(r["sid"])
        novel_cnt[r["novel"]] += 1
        for e in ents(r):
            counts[e["label"]] += 1
            name_cnt[e["name"].lower()] += 1
        for lab in r.get("cues", []):
            counts[lab] += 0.5  # gợi ý ngữ cảnh chỉ là phỏng đoán -> tính nửa

    def deficit(lab):
        t = targets.get(lab, 0)
        return max(0.0, (t - counts[lab]) / t) if t else 0.0

    def score(r):
        s = 0.0
        for e in ents(r):
            fresh = 1.0 if name_cnt[e["name"].lower()] < a.max_per_name else 0.05
            s += deficit(e["label"]) * fresh
        for lab in r.get("cues", []):
            s += 0.5 * deficit(lab)
        if a.uncertainty_weight and "uncertainty" in r:
            s += a.uncertainty_weight * r["uncertainty"] * (1.0 if s > 0 else 0.5)
        return s

    n_neg = int(budget * a.neg_frac)
    n_rand = int(budget * a.random_frac)
    n_greedy = budget - n_neg - n_rand

    # (a) chọn tham lam theo độ thiếu, cập nhật lại điểm sau mỗi 'step' câu
    while len([1 for _, h in selected if h == "chỉ_tiêu"]) < n_greedy:
        scored = []
        for r in pool:
            if r["sid"] in chosen or novel_cnt[r["novel"]] >= novel_cap:
                continue
            sc = score(r)
            if sc > 0:
                scored.append((sc, rng.random(), r))
        if not scored:
            break
        scored.sort(key=lambda x: (-x[0], x[1]))
        need = n_greedy - len([1 for _, h in selected if h == "chỉ_tiêu"])
        added = 0
        for _, _, r in scored:
            if added >= min(a.step, need):
                break
            if novel_cnt[r["novel"]] >= novel_cap or r["sid"] in chosen:
                continue
            take(r, "chỉ_tiêu")
            added += 1
        if added == 0:
            break

    # (b) câu âm: không có thực thể, không có cụm viết hoa lạ
    neg = [r for r in pool if r["sid"] not in chosen and not ents(r) and not r.get("candidates")]
    rng.shuffle(neg)
    for r in neg:
        if len([1 for _, h in selected if h == "câu_âm"]) >= n_neg:
            break
        if novel_cnt[r["novel"]] < novel_cap:
            take(r, "câu_âm")

    # (c) ngẫu nhiên: giữ phân bố tự nhiên, bắt các tên mà từ điển chưa biết
    rest = [r for r in pool if r["sid"] not in chosen]
    rng.shuffle(rest)
    for r in rest:
        if len(selected) >= budget:
            break
        if novel_cnt[r["novel"]] < novel_cap:
            take(r, "ngẫu_nhiên")
    for r in rest:  # nếu vẫn thiếu do giới hạn mỗi bộ truyện
        if len(selected) >= budget:
            break
        if r["sid"] not in chosen:
            take(r, "ngẫu_nhiên")
    return selected


def to_task(r, split):
    e_list = ents(r)
    return {
        "data": {"text": r["text"], "sid": r["sid"], "novel": r["novel"],
                 "chapter": r["chapter"], "split": split},
        "predictions": [{
            "model_version": "model" if r.get("model_entities") is not None else "dictionary",
            "result": [{
                "id": f"p{i}", "from_name": "label", "to_name": "text", "type": "labels",
                "value": {"start": e["start"], "end": e["end"],
                          "text": r["text"][e["start"]:e["end"]], "labels": [e["label"]]},
            } for i, e in enumerate(e_list)],
        }],
    }


def cmd_select(a):
    rng = random.Random(a.seed)
    pool = read_jsonl(a.pool)
    have = {"train": Counter(), "test": Counter()}
    n_done = Counter()
    done = set()
    if a.already:
        for x in pick_final(load_annotated(a.already)).values():
            done.add(x["sid"])
            sp = "test" if x["split"] == "test" else "train"
            n_done[sp] += 1
            _, tags, _ = to_bio(x["text"], x["spans"])
            for _, _, lab in bio_spans(tags):
                have[sp][lab] += 1
    pool = [r for r in pool if r["sid"] not in done]

    labels = sorted({e["label"] for r in pool for e in ents(r)} |
                    {l for r in pool for l in r.get("cues", [])} | set(have["train"]))
    targets = {l: a.target for l in labels}
    targets.update(parse_targets(a.targets))
    test_targets = {l: a.test_target for l in labels}

    train_pool = [r for r in pool if r.get("split") != "test"]
    test_pool = [r for r in pool if r.get("split") == "test"]
    test_budget = max(0, a.test_size - n_done["test"])

    sel_train = greedy_select(train_pool, a.budget, targets, have["train"], a, rng)
    # Tập test: một nửa ngẫu nhiên (phân bố thật), một nửa bù nhãn hiếm (đủ mẫu để đo F1 từng nhãn)
    a_test = argparse.Namespace(**vars(a))
    a_test.random_frac, a_test.neg_frac = 0.45, 0.05
    sel_test = greedy_select(test_pool, test_budget, test_targets, have["test"], a_test, rng)

    tasks = [to_task(r, "train") for r, _ in sel_train] + [to_task(r, "test") for r, _ in sel_test]
    rng.shuffle(tasks)
    os.makedirs(a.out, exist_ok=True)
    with open(os.path.join(a.out, "tasks_label_studio.json"), "w", encoding="utf-8") as f:
        json.dump(tasks, f, ensure_ascii=False, indent=1)
    with open(os.path.join(a.out, "selection.csv"), "w", encoding="utf-8-sig", newline="") as f:
        w = csv.writer(f)
        w.writerow(["split", "lý_do_chọn", "novel", "chapter", "text", "nhãn_dự_kiến"])
        for sp, sel in (("train", sel_train), ("test", sel_test)):
            for r, how in sel:
                w.writerow([sp, how, r["novel"], r["chapter"], r["text"],
                            "; ".join(f"{e['name']}={e['label']}" for e in ents(r))])

    def expected(sel):
        c = Counter()
        for r, _ in sel:
            for e in ents(r):
                c[e["label"]] += 1
        return c

    exp_tr, exp_te = expected(sel_train), expected(sel_test)
    cue_tr = Counter(l for r, _ in sel_train for l in r.get("cues", []))
    lines = [
        f"Đã gán nhãn trước đó: train {n_done['train']} câu, test {n_done['test']} câu",
        f"Chọn vòng này: train {len(sel_train)} câu, test {len(sel_test)} câu "
        f"(còn lại trong pool: train {len(train_pool) - len(sel_train)}, test {len(test_pool) - len(sel_test)})",
        "Lý do chọn (train): " + ", ".join(f"{k}={v}" for k, v in Counter(h for _, h in sel_train).items()),
        "",
        "Số thực thể TRAIN (ước tính từ từ điển/mô hình — thực tế sau khi gán nhãn thường cao hơn).",
        "Cột '+câu gợi ý' = số câu có cụm viết hoa lạ + ngữ cảnh của nhãn, chưa tính vào tổng:",
        f"  {'nhãn':<12} {'đã có':>7} {'+vòng này':>10} {'= tổng':>8} {'chỉ tiêu':>9} {'+câu gợi ý':>11}",
    ]
    for lab in labels:
        tot = have["train"][lab] + exp_tr[lab]
        mark = "✅" if tot >= targets[lab] else "❌ thiếu %d" % (targets[lab] - tot)
        lines.append(f"  {lab:<12} {have['train'][lab]:>7} {exp_tr[lab]:>10} {tot:>8} {targets[lab]:>9} "
                     f"{cue_tr[lab]:>11}  {mark}")
    lines.append("  Nếu nhãn nào '+vòng này' = 0 và '+câu gợi ý' thấp: bổ sung từ điển (candidates.csv) rồi chạy lại prepare.")
    lines += ["", "Số thực thể TEST (ước tính):",
              *[f"  {lab:<12} {have['test'][lab] + exp_te[lab]:>7} / {test_targets[lab]}" for lab in labels],
              "", "Số câu TRAIN chọn theo bộ truyện:",
              *[f"  {n:<30} {c}" for n, c in Counter(r["novel"] for r, _ in sel_train).most_common()]]
    names = Counter((e["name"], e["label"]) for r, _ in sel_train for e in ents(r))
    if names:
        lines += ["", "Tên xuất hiện nhiều nhất trong vòng này (giới hạn --max-per-name %d):" % a.max_per_name,
                  *[f"  {n:<28} {l:<10} {c}" for (n, l), c in names.most_common(10)]]
    report = "\n".join(lines)
    write_text(os.path.join(a.out, "select_report.txt"), report)
    print(report)
    print(f"\n✅ Import vào Label Studio: {os.path.join(a.out, 'tasks_label_studio.json')}")


# ---------------------------------------------------------------------------
# 3) AGREEMENT
# ---------------------------------------------------------------------------
def cmd_agreement(a):
    by_sid = defaultdict(dict)
    for x in load_annotated(a.input):
        by_sid[x["sid"]].setdefault(x["annotator"], x)
    pairs = [list(d.values())[:2] for d in by_sid.values() if len(d) >= 2]
    if not pairs:
        sys.exit("❌ Không có câu nào được ≥ 2 người gán nhãn. Trong Label Studio, đặt "
                 "'Minimum annotations per task' = 2 cho dự án thử nghiệm, hoặc truyền 2 file export.")

    tp, na, nb = Counter(), Counter(), Counter()
    kinds = Counter()
    rows = []
    for x, y in pairs:
        wx, tx, _ = to_bio(x["text"], x["spans"])
        _, ty, _ = to_bio(y["text"], y["spans"])
        sx, sy = set(bio_spans(tx)), set(bio_spans(ty))
        for s in sx:
            na[s[2]] += 1
        for s in sy:
            nb[s[2]] += 1
        for s in sx & sy:
            tp[s[2]] += 1
        if sx != sy:
            ox, oy = sx - sy, sy - sx
            for s in ox:
                same = [t for t in oy if (t[0], t[1]) == (s[0], s[1])]
                over = [t for t in oy if t[0] < s[1] and s[0] < t[1]]
                kinds["khác_nhãn" if same else "lệch_ranh_giới" if over else "chỉ_A_gán"] += 1
            kinds["chỉ_B_gán"] += sum(1 for t in oy if not any(t[0] < s[1] and s[0] < t[1] for s in ox))
            fmt = lambda ss: "; ".join(f"{' '.join(wx[s:e])}={l}" for s, e, l in sorted(ss))
            rows.append([x["novel"], x["text"], x["annotator"], fmt(ox), y["annotator"], fmt(oy)])

    labels = sorted(set(na) | set(nb))
    f1 = lambda l: (2 * tp[l] / (na[l] + nb[l])) if (na[l] + nb[l]) else 1.0
    T, A, B = sum(tp.values()), sum(na.values()), sum(nb.values())
    overall = 2 * T / (A + B) if (A + B) else 1.0
    verdict = ("✅ Tốt" if overall >= 0.9 else "🟡 Chấp nhận được, nên làm rõ quy tắc" if overall >= 0.8
               else "❌ Thấp — sửa quy tắc gán nhãn và gán thử lại trước khi làm số lượng lớn")
    lines = [f"Số câu được 2 người gán nhãn: {len(pairs)} | câu bất đồng: {len(rows)}",
             f"F1 đồng thuận tổng (khớp chính xác ranh giới + nhãn): {overall:.3f}  {verdict}", "",
             f"  {'nhãn':<12} {'F1':>6} {'A':>6} {'B':>6}",
             *[f"  {l:<12} {f1(l):>6.3f} {na[l]:>6} {nb[l]:>6}" for l in labels], "",
             "Loại bất đồng: " + ", ".join(f"{k}={v}" for k, v in kinds.most_common())]
    os.makedirs(a.out, exist_ok=True)
    with open(os.path.join(a.out, "bat_dong.csv"), "w", encoding="utf-8-sig", newline="") as f:
        w = csv.writer(f)
        w.writerow(["novel", "text", "người_A", "chỉ_A_gán", "người_B", "chỉ_B_gán"])
        w.writerows(rows)
    report = "\n".join(lines)
    write_text(os.path.join(a.out, "agreement_report.txt"), report)
    print(report)
    print(f"\n📄 Danh sách câu bất đồng: {os.path.join(a.out, 'bat_dong.csv')}")


# ---------------------------------------------------------------------------
# 4) SPLIT
# ---------------------------------------------------------------------------
def cmd_split(a):
    rng = random.Random(a.seed)
    final = pick_final(load_annotated(a.input))
    conv = Counter()
    recs = []
    for x in final.values():
        words, tags, st = to_bio(x["text"], x["spans"])
        conv.update(st)
        if words:
            recs.append({"tokens": words, "ner_tags": tags, "novel": x["novel"],
                         "chapter": x["chapter"], "sid": x["sid"], "split": x["split"]})
    if not recs:
        sys.exit("❌ Không có câu nào đã gán nhãn trong các file export.")

    test_novels = set(a.test_novels or [])
    for r in recs:
        if r["split"] not in ("train", "test"):
            r["split"] = "test" if r["novel"] in test_novels else "train"
    test = [r for r in recs if r["split"] == "test"]
    pool_tr = [r for r in recs if r["split"] == "train"]

    def by_chapter_holdout(rows, ratio):
        groups = defaultdict(list)
        for r in rows:
            groups[(r["novel"], r["chapter"])].append(r)
        keys = sorted(groups)
        rng.shuffle(keys)
        goal = ratio * len(rows)
        held, n = set(), 0
        if len(keys) >= 3:
            for k in keys:
                if n >= goal:
                    break
                if n + len(groups[k]) > 2 * goal and n > 0:
                    continue
                held.add(k)
                n += len(groups[k])
            return ([r for r in rows if (r["novel"], r["chapter"]) not in held],
                    [r for r in rows if (r["novel"], r["chapter"]) in held], "theo chương")
        rows = rows[:]
        rng.shuffle(rows)
        k = max(1, int(len(rows) * ratio))
        return rows[k:], rows[:k], "⚠️ theo câu (quá ít chương)"

    notes = []
    if not test:
        pool_tr, test, how = by_chapter_holdout(pool_tr, 0.1)
        notes.append(f"⚠️ Không có câu nào đánh dấu test -> tạm tách test {how}. "
                     "Nên giữ riêng ít nhất 1 bộ truyện làm test.")
    train, dev, dev_how = by_chapter_holdout(pool_tr, a.dev_ratio)

    os.makedirs(a.out, exist_ok=True)
    for name, rows in (("train", train), ("dev", dev), ("test", test)):
        write_jsonl(os.path.join(a.out, f"{name}.jsonl"),
                    [{k: r[k] for k in ("tokens", "ner_tags", "novel", "chapter", "sid")} for r in rows])

    def ent_list(rows):
        return [(" ".join(r["tokens"][s:e]).lower(), l) for r in rows for s, e, l in bio_spans(r["ner_tags"])]

    E = {n: ent_list(rows) for n, rows in (("train", train), ("dev", dev), ("test", test))}
    labels = sorted({l for v in E.values() for _, l in v})
    targets = {l: a.target for l in labels}
    targets.update(parse_targets(a.targets))
    C = {n: Counter(l for _, l in v) for n, v in E.items()}
    train_names = {n for n, _ in E["train"]}

    lines = [f"Số câu: train {len(train)} | dev {len(dev)} ({dev_how}) | test {len(test)}", *notes,
             "Bộ truyện — train: %s | test: %s" % (sorted({r['novel'] for r in train}),
                                                    sorted({r['novel'] for r in test})), "",
             f"  {'nhãn':<12} {'train':>7} {'dev':>6} {'test':>6} {'chỉ tiêu':>9} {'#tên khác nhau':>15} "
             f"{'tên phổ biến nhất':>18} {'test: tên mới':>14}"]
    warn = []
    for l in labels:
        names_l = Counter(n for n, x in E["train"] if x == l)
        top_share = names_l.most_common(1)[0][1] / C["train"][l] if C["train"][l] else 0
        test_l = [n for n, x in E["test"] if x == l]
        unseen = sum(1 for n in test_l if n not in train_names) / len(test_l) if test_l else float("nan")
        ok = "✅" if C["train"][l] >= targets[l] else f"❌-{targets[l] - C['train'][l]}"
        lines.append(f"  {l:<12} {C['train'][l]:>7} {C['dev'][l]:>6} {C['test'][l]:>6} {targets[l]:>6} {ok:<4}"
                     f"{len(names_l):>12} {top_share:>17.0%} {unseen:>14.0%}")
        if top_share > 0.3:
            warn.append(f"{l}: 1 tên chiếm {top_share:.0%} -> mô hình dễ học thuộc tên; thêm câu có tên khác.")
        if test_l and unseen < 0.3:
            warn.append(f"{l}: chỉ {unseen:.0%} tên trong test là tên mới -> test chưa đo được khả năng tổng quát.")
        if C["test"][l] < 30:
            warn.append(f"{l}: test chỉ có {C['test'][l]} thực thể -> F1 của nhãn này dao động mạnh.")
    neg = sum(1 for r in train if all(t == "O" for t in r["ner_tags"])) / max(1, len(train))
    lines += ["", f"Câu không có thực thể trong train: {neg:.0%} (khuyến nghị 10–30%)"]
    if conv:
        lines.append("Chuyển đổi nhãn: " + ", ".join(f"{k}={v}" for k, v in conv.items()))
    if warn:
        lines += ["", "Cảnh báo:", *[f"  ⚠️ {w}" for w in warn]]
    report = "\n".join(lines)
    write_text(os.path.join(a.out, "split_report.txt"), report)
    print(report)
    print(f"\n✅ Đã ghi train/dev/test.jsonl vào: {a.out}  (đặt USE_DEMO_DATA = False trong notebook)")


# ---------------------------------------------------------------------------
# 5) SCORE (tuỳ chọn, cần torch + transformers)
# ---------------------------------------------------------------------------
def cmd_score(a):
    try:
        import torch
        from transformers import AutoTokenizer, AutoModelForTokenClassification
    except ImportError:
        sys.exit("❌ Lệnh score cần: pip install torch transformers")
    device = "cuda" if torch.cuda.is_available() else "cpu"
    tok = AutoTokenizer.from_pretrained(a.model, use_fast=True)
    model = AutoModelForTokenClassification.from_pretrained(a.model).to(device).eval()
    id2label = {int(k): v for k, v in model.config.id2label.items()}
    pool = read_jsonl(a.pool)
    for i in range(0, len(pool), a.batch_size):
        batch = pool[i:i + a.batch_size]
        toks = [tokenize_with_offsets(r["text"]) for r in batch]
        words = [[w for w, _, _ in t] for t in toks]
        enc = tok(words, is_split_into_words=True, truncation=True, max_length=a.max_len,
                  padding=True, return_tensors="pt")
        with torch.no_grad():
            logits = model(**{k: v.to(device) for k, v in enc.items()}).logits
        conf, pred = torch.softmax(logits, dim=-1).max(-1)
        conf, pred = conf.cpu().tolist(), pred.cpu().tolist()
        for b, r in enumerate(batch):
            tags, wconf, seen = ["O"] * len(words[b]), [1.0] * len(words[b]), set()
            for t_idx, w in enumerate(enc.word_ids(batch_index=b)):
                if w is None or w in seen:
                    continue
                seen.add(w)
                tags[w], wconf[w] = id2label[pred[b][t_idx]], conf[b][t_idx]
            r["uncertainty"] = round(1.0 - min(wconf), 4) if wconf else 0.0
            r["model_entities"] = [{"start": toks[b][s][1], "end": toks[b][e - 1][2], "label": l,
                                    "name": " ".join(words[b][s:e])} for s, e, l in bio_spans(tags)]
        print(f"\r{min(i + a.batch_size, len(pool))}/{len(pool)}", end="", flush=True)
    write_jsonl(a.out, pool)
    print(f"\n✅ Đã ghi: {a.out}  -> dùng làm --pool cho lệnh select (thêm --uncertainty-weight 1.0)")


# ---------------------------------------------------------------------------
def main():
    # Tránh lỗi hiển thị tiếng Việt / emoji trên console Windows
    for _s in (sys.stdout, sys.stderr):
        try:
            _s.reconfigure(encoding="utf-8", errors="replace")
        except Exception:
            pass
    ap = argparse.ArgumentParser(description="Xây dựng bộ dữ liệu NER (truyện tiên hiệp)")
    sub = ap.add_subparsers(dest="cmd", required=True)

    p = sub.add_parser("prepare", help="Đọc truyện, tách câu, gán nhãn nháp, chọn tập test")
    p.add_argument("--input", nargs="+", required=True, help="Thư mục truyện (mỗi bộ 1 thư mục con) hoặc file .txt")
    p.add_argument("--dict", help="Từ điển .json/.csv (xem gan_nhan_nhap_tu_dien.py)")
    p.add_argument("--out", default="work")
    p.add_argument("--test-novels", nargs="*", help="Tên thư mục bộ truyện giữ riêng làm test")
    p.add_argument("--test-chapter-frac", type=float, default=0.15,
                   help="Khi có < 3 bộ: tỉ lệ chương cuối mỗi bộ dùng làm test")
    p.add_argument("--min-tokens", type=int, default=4)
    p.add_argument("--max-tokens", type=int, default=80)
    p.add_argument("--min-candidate-count", type=int, default=2)
    p.set_defaults(func=cmd_prepare)

    s = sub.add_parser("select", help="Chọn câu cần gán nhãn cho một vòng")
    s.add_argument("--pool", required=True)
    s.add_argument("--out", required=True)
    s.add_argument("--budget", type=int, default=500, help="Số câu TRAIN chọn trong vòng này")
    s.add_argument("--target", type=int, default=300, help="Chỉ tiêu số thực thể mỗi nhãn trong train")
    s.add_argument("--targets", default="", help="Chỉ tiêu riêng, vd. DI_HOA=300,VU_KHI=250")
    s.add_argument("--already", nargs="*", help="Các file export Label Studio của vòng trước")
    s.add_argument("--test-size", type=int, default=300, help="Tổng số câu test cần (tính cả vòng trước)")
    s.add_argument("--test-target", type=int, default=50, help="Chỉ tiêu thực thể mỗi nhãn trong test")
    s.add_argument("--max-per-name", type=int, default=15, help="Sau N lần, một tên gần như không còn được ưu tiên")
    s.add_argument("--max-novel-share", type=float, default=0.35, help="Tỉ lệ tối đa câu từ một bộ truyện")
    s.add_argument("--random-frac", type=float, default=0.15, help="Tỉ lệ câu chọn ngẫu nhiên")
    s.add_argument("--neg-frac", type=float, default=0.10, help="Tỉ lệ câu không có thực thể")
    s.add_argument("--uncertainty-weight", type=float, default=0.0, help="Ưu tiên câu mô hình không chắc (sau lệnh score)")
    s.add_argument("--step", type=int, default=25)
    s.add_argument("--seed", type=int, default=42)
    s.set_defaults(func=cmd_select)

    g = sub.add_parser("agreement", help="Đo độ đồng thuận giữa 2 người gán nhãn")
    g.add_argument("--input", nargs="+", required=True, help="1 file export có ≥2 annotation/câu, hoặc 2 file")
    g.add_argument("--out", default="dong_thuan")
    g.set_defaults(func=cmd_agreement)

    t = sub.add_parser("split", help="Export Label Studio -> train/dev/test.jsonl")
    t.add_argument("--input", nargs="+", required=True)
    t.add_argument("--out", default="data")
    t.add_argument("--dev-ratio", type=float, default=0.1)
    t.add_argument("--target", type=int, default=300)
    t.add_argument("--targets", default="")
    t.add_argument("--test-novels", nargs="*", help="Chỉ cần nếu task không có trường split")
    t.add_argument("--seed", type=int, default=42)
    t.set_defaults(func=cmd_split)

    c = sub.add_parser("score", help="(Tuỳ chọn) Mô hình đã train chấm điểm pool")
    c.add_argument("--model", required=True, help="Thư mục mô hình, vd. ner-final")
    c.add_argument("--pool", required=True)
    c.add_argument("--out", required=True)
    c.add_argument("--batch-size", type=int, default=32)
    c.add_argument("--max-len", type=int, default=256)
    c.set_defaults(func=cmd_score)

    args = ap.parse_args()
    args.func(args)


if __name__ == "__main__":
    main()
