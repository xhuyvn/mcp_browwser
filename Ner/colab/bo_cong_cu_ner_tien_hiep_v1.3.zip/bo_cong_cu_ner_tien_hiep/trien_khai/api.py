# -*- coding: utf-8 -*-
"""
API nội bộ cho mô hình NER truyện tiên hiệp (FastAPI).

Chạy
  MODEL_DIR=../ner-final uvicorn api:app --host 0.0.0.0 --port 8000 --workers 1
  # Tài liệu API tương tác: http://localhost:8000/docs

Biến môi trường
  MODEL_DIR          thư mục mô hình (mặc định: ner-final)
  DICT_PATH          từ điển tên .json/.csv (tuỳ chọn)
  DEVICE             cuda / cpu (mặc định: tự chọn)
  BATCH_SIZE         mặc định 32
  MAX_LEN            mặc định 256 (nên bằng MAX_LEN lúc huấn luyện)
  TORCH_THREADS      số luồng CPU (tuỳ chọn)
  API_KEY            nếu đặt: mọi request (trừ /health) phải có header  X-API-Key: <API_KEY>
  MAX_TEXT_CHARS     độ dài tối đa mỗi văn bản (mặc định 200000)
  MAX_BATCH_ITEMS    số văn bản tối đa mỗi request /extract/batch (mặc định 64)
"""
import hmac
import logging
import os
import threading
import time
from contextlib import asynccontextmanager
from typing import List, Optional

from fastapi import Depends, FastAPI, Header, HTTPException
from pydantic import BaseModel, Field

from ner_engine import NerEngine

logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(name)s: %(message)s")
log = logging.getLogger("ner_api")

MODEL_DIR = os.getenv("MODEL_DIR", "ner-final")
DICT_PATH = os.getenv("DICT_PATH") or None
DEVICE = os.getenv("DEVICE") or None
BATCH_SIZE = int(os.getenv("BATCH_SIZE", "32"))
MAX_LEN = int(os.getenv("MAX_LEN", "256"))
TORCH_THREADS = os.getenv("TORCH_THREADS") or None
API_KEY = os.getenv("API_KEY") or None
MAX_TEXT_CHARS = int(os.getenv("MAX_TEXT_CHARS", "200000"))
MAX_BATCH_ITEMS = int(os.getenv("MAX_BATCH_ITEMS", "64"))

STATE = {"engine": None, "started": None}
_lock = threading.Lock()  # 1 mô hình dùng chung -> xử lý tuần tự cho an toàn; mở rộng bằng nhiều container


@asynccontextmanager
async def lifespan(app):
    log.info("Nạp mô hình từ %s ...", MODEL_DIR)
    STATE["engine"] = NerEngine(MODEL_DIR, dict_path=DICT_PATH, device=DEVICE, batch_size=BATCH_SIZE,
                                max_len=MAX_LEN, num_threads=TORCH_THREADS)
    STATE["started"] = time.time()
    log.info("Sẵn sàng: %s", STATE["engine"].info())
    if not API_KEY:
        log.warning("API_KEY chưa đặt: API không yêu cầu xác thực. Chỉ dùng trong mạng nội bộ.")
    yield
    STATE["engine"] = None


app = FastAPI(title="NER truyện tiên hiệp", version="1.0", lifespan=lifespan,
              description="Nhận diện NHAN_VAT, DIA_DANH, VU_KHI, CONG_PHAP, DI_HOA, THE_LUC.")


def check_key(x_api_key: Optional[str] = Header(default=None)):
    if API_KEY and not (x_api_key and hmac.compare_digest(x_api_key, API_KEY)):
        raise HTTPException(status_code=401, detail="Sai hoặc thiếu X-API-Key")


class Entity(BaseModel):
    label: str
    text: str
    start: int
    end: int
    score: Optional[float] = Field(None, description="Điểm tin cậy 0-1; null nếu lấy từ từ điển")
    source: str = Field(..., description="model hoặc dict")
    context: Optional[str] = None


class ExtractRequest(BaseModel):
    text: str = Field(..., examples=["Tiêu Viêm thi triển Phật Nộ Hỏa Liên về phía đệ tử Vân Lam Tông."])
    min_score: float = Field(0.0, ge=0.0, le=1.0)
    use_dict: bool = True
    include_context: bool = False


class ExtractResponse(BaseModel):
    text: str = Field(..., description="Văn bản đã chuẩn hoá NFC; start/end tính trên văn bản này")
    entities: List[Entity]
    elapsed_ms: float


class BatchRequest(BaseModel):
    texts: List[str]
    min_score: float = Field(0.0, ge=0.0, le=1.0)
    use_dict: bool = True
    include_context: bool = False


class BatchResponse(BaseModel):
    results: List[ExtractResponse]
    elapsed_ms: float


def _engine():
    eng = STATE["engine"]
    if eng is None:
        raise HTTPException(status_code=503, detail="Mô hình chưa sẵn sàng")
    return eng


def _check_len(texts):
    for i, t in enumerate(texts):
        if len(t) > MAX_TEXT_CHARS:
            raise HTTPException(status_code=413, detail=f"Văn bản #{i} dài {len(t)} ký tự > {MAX_TEXT_CHARS}")


@app.get("/health")
def health():
    eng = STATE["engine"]
    if eng is None:
        raise HTTPException(status_code=503, detail="Mô hình chưa sẵn sàng")
    return {"status": "ok", "uptime_s": round(time.time() - STATE["started"], 1), **eng.info()}


@app.post("/extract", response_model=ExtractResponse, dependencies=[Depends(check_key)])
def extract(req: ExtractRequest):
    eng = _engine()
    _check_len([req.text])
    t0 = time.perf_counter()
    with _lock:
        r = eng.extract(req.text, min_score=req.min_score, use_dict=req.use_dict, with_context=req.include_context)
    ms = round((time.perf_counter() - t0) * 1000, 1)
    log.info("extract: %d ký tự, %d thực thể, %.1f ms", len(req.text), len(r["entities"]), ms)
    return {**r, "elapsed_ms": ms}


@app.post("/extract/batch", response_model=BatchResponse, dependencies=[Depends(check_key)])
def extract_batch(req: BatchRequest):
    eng = _engine()
    if len(req.texts) > MAX_BATCH_ITEMS:
        raise HTTPException(status_code=413, detail=f"Tối đa {MAX_BATCH_ITEMS} văn bản mỗi request")
    _check_len(req.texts)
    t0 = time.perf_counter()
    with _lock:
        rs = eng.extract_many(req.texts, min_score=req.min_score, use_dict=req.use_dict,
                              with_context=req.include_context)
    ms = round((time.perf_counter() - t0) * 1000, 1)
    log.info("batch: %d văn bản, %d thực thể, %.1f ms", len(req.texts), sum(len(r["entities"]) for r in rs), ms)
    return {"results": [{**r, "elapsed_ms": ms} for r in rs], "elapsed_ms": ms}
