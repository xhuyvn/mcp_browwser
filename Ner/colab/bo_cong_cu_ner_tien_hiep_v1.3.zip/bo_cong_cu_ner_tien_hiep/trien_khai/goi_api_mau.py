#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Ví dụ gọi API NER (chỉ dùng thư viện chuẩn, không cần cài requests).

  python goi_api_mau.py                                   # gọi http://localhost:8000
  python goi_api_mau.py --url http://may-chu:8000 --key bi-mat --text "Tiêu Viêm rút Huyền Trọng Thước."
"""
import argparse
import json
import sys
import urllib.error
import urllib.request


def call(url, path, payload=None, key=None):
    data = json.dumps(payload, ensure_ascii=False).encode("utf-8") if payload is not None else None
    req = urllib.request.Request(url.rstrip("/") + path, data=data, method="POST" if data else "GET",
                                 headers={"Content-Type": "application/json; charset=utf-8"})
    if key:
        req.add_header("X-API-Key", key)
    try:
        with urllib.request.urlopen(req, timeout=120) as r:
            return json.loads(r.read().decode("utf-8"))
    except urllib.error.HTTPError as e:
        sys.exit(f"❌ HTTP {e.code}: {e.read().decode('utf-8', 'replace')}")
    except urllib.error.URLError as e:
        sys.exit(f"❌ Không kết nối được {url}: {e.reason}")


def main():
    for s in (sys.stdout, sys.stderr):
        try:
            s.reconfigure(encoding="utf-8", errors="replace")
        except Exception:
            pass
    ap = argparse.ArgumentParser()
    ap.add_argument("--url", default="http://localhost:8000")
    ap.add_argument("--key", help="Giá trị API_KEY của máy chủ (nếu có)")
    ap.add_argument("--text", default="Tiêu Viêm thi triển Phật Nộ Hỏa Liên về phía đệ tử Vân Lam Tông, "
                                      "tay nắm chặt Huyền Trọng Thước.")
    a = ap.parse_args()

    h = call(a.url, "/health")
    print("Máy chủ:", h["status"], "| nhãn:", ", ".join(h["labels"]), "| thiết bị:", h["device"])

    r = call(a.url, "/extract", {"text": a.text, "min_score": 0.5}, a.key)
    print(f"\n{a.text}\n({r['elapsed_ms']} ms)")
    for e in r["entities"]:
        sc = f"{e['score']:.2f}" if e["score"] is not None else "từ điển"
        print(f"  [{e['label']:<10}] {e['text']:<28} vị trí {e['start']}-{e['end']}  ({sc})")

    rs = call(a.url, "/extract/batch", {"texts": ["Hắn luyện hóa Thanh Liên Địa Tâm Hỏa.", "Nạp Lan gia suy tàn."]}, a.key)
    print("\nBatch:", [[(e["label"], e["text"]) for e in x["entities"]] for x in rs["results"]])


if __name__ == "__main__":
    main()
