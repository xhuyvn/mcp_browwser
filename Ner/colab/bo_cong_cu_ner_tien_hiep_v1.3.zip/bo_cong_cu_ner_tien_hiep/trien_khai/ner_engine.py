# -*- coding: utf-8 -*-
"""
NerEngine — nạp mô hình NER đã fine-tune và trích xuất thực thể từ văn bản (kể cả văn bản rất dài).

Tính năng
  - Tách câu + tách từ GIỐNG HỆT lúc huấn luyện (simple_tokenize) -> kết quả khớp với notebook.
  - Câu quá dài so với giới hạn token -> chia cửa sổ trượt có chồng lấn; mỗi từ lấy dự đoán ở
    cửa sổ mà nó nằm "giữa" nhất (tránh cắt đôi thực thể ở ranh giới cửa sổ).
  - Gom nhiều câu thành batch (sắp theo độ dài) để chạy nhanh trên GPU/CPU.
  - Trả về vị trí ký tự (start, end), điểm tin cậy (score), nguồn (model / dict).
  - Tuỳ chọn: từ điển tên bổ sung các tên mô hình bỏ sót (KHÔNG ghi đè dự đoán của mô hình).

Ví dụ
    from ner_engine import NerEngine
    eng = NerEngine("ner-final", dict_path="tu_dien.json")
    kq = eng.extract("Tiêu Viêm thi triển Phật Nộ Hỏa Liên về phía đệ tử Vân Lam Tông.")
    for e in kq["entities"]:
        print(e["label"], e["text"], e["score"])

Lưu ý: vị trí (start, end) tính trên văn bản đã chuẩn hoá Unicode NFC (trường "text" trong kết quả).
Với văn bản gõ bằng bộ gõ thông thường (đã là NFC), vị trí trùng với văn bản gốc.
"""
import csv
import json
import logging
import os
import re
import unicodedata

log = logging.getLogger("ner_engine")

# PHẢI giống simple_tokenize trong notebook và gan_nhan_nhap_tu_dien.py
TOKEN_RE = re.compile(r"\w+(?:[.,/:\-]\w+)*|[^\w\s]", re.UNICODE)
SENT_SEP_RE = re.compile(r"(?<=[.!?…])\s+|(?<=[.!?…][\"”’)\]])\s+|\n+")

LABEL_ALIASES = {
    "nhân vật": "NHAN_VAT", "địa danh": "DIA_DANH", "vũ khí": "VU_KHI", "công pháp": "CONG_PHAP",
    "dị hỏa": "DI_HOA", "dị hoả": "DI_HOA", "thế lực": "THE_LUC", "tông môn": "THE_LUC",
}


def nfc(s):
    return unicodedata.normalize("NFC", s)


def simple_tokenize(text):
    return TOKEN_RE.findall(text)


def split_sentences_with_offsets(text):
    """Sinh (vị_trí_bắt_đầu, câu) — câu đã bỏ khoảng trắng hai đầu."""
    start = 0
    for m in SENT_SEP_RE.finditer(text):
        yield from _emit(text, start, m.start())
        start = m.end()
    yield from _emit(text, start, len(text))


def _emit(text, a, b):
    seg = text[a:b]
    stripped = seg.strip()
    if stripped:
        yield a + (len(seg) - len(seg.lstrip())), stripped


def bio_spans(tags):
    """BIO -> [(start_word, end_word_exclusive, label)]; chấp nhận I- đứng đầu (coi như B-)."""
    spans, cur = [], None
    for i, t in enumerate(list(tags) + ["O"]):
        new_ent = t.startswith("B-") or (t.startswith("I-") and (cur is None or cur[2] != t[2:]))
        if t == "O" or new_ent:
            if cur:
                spans.append((cur[0], i, cur[2]))
                cur = None
            if new_ent:
                cur = [i, None, t[2:]]
    return spans


def _make_windows(n, size):
    if n <= size:
        return [(0, n)]
    overlap = max(1, size // 4)
    step = size - overlap
    wins, a = [], 0
    while True:
        b = min(a + size, n)
        wins.append((a, b))
        if b >= n:
            return wins
        a += step


class NerEngine:
    def __init__(self, model_dir, dict_path=None, device=None, batch_size=32, max_len=256,
                 max_words=120, num_threads=None):
        self.model_dir = model_dir
        self.batch_size = int(batch_size)
        self.max_len = int(max_len)
        self.max_words = int(max_words)
        self.warnings = []
        self._load(model_dir, device, num_threads)
        self.labels = sorted({l[2:] for l in self.id2label.values() if l != "O"})
        self.gazetteer, self._max_gaz = ({}, 0)
        if dict_path:
            self.gazetteer = self._load_gazetteer(dict_path)
            self._max_gaz = max((len(k) for k in self.gazetteer), default=0)

    # ------------------------------------------------------------------ mô hình
    def _load(self, model_dir, device, num_threads):
        if not os.path.isdir(model_dir):
            raise FileNotFoundError(f"Không thấy thư mục mô hình: {model_dir}")
        if not os.path.exists(os.path.join(model_dir, "config.json")):
            raise FileNotFoundError(f"{model_dir} thiếu config.json — có đúng thư mục trainer.save_model() không?")
        import torch
        from transformers import AutoModelForTokenClassification, AutoTokenizer
        if num_threads:
            torch.set_num_threads(int(num_threads))
        self._torch = torch
        self.device = device or ("cuda" if torch.cuda.is_available() else "cpu")
        self.tokenizer = AutoTokenizer.from_pretrained(model_dir, use_fast=True)
        if not self.tokenizer.is_fast:
            raise RuntimeError("Cần fast tokenizer (tokenizer.json) để căn nhãn theo từ.")
        self.model = AutoModelForTokenClassification.from_pretrained(model_dir).to(self.device).eval()
        self.id2label = {int(k): v for k, v in self.model.config.id2label.items()}

    def _n_subwords(self, words):
        return len(self.tokenizer(words, is_split_into_words=True)["input_ids"])

    def _predict_windows(self, batch):
        """batch: list các list từ -> list (tags, confidences) theo từng từ."""
        torch = self._torch
        enc = self.tokenizer(batch, is_split_into_words=True, truncation=True, max_length=self.max_len,
                             padding=True, return_tensors="pt")
        inputs = {k: v.to(self.device) for k, v in enc.items()}
        with torch.inference_mode():
            logits = self.model(**inputs).logits
        conf, pred = logits.float().softmax(-1).max(-1)
        conf, pred = conf.cpu().tolist(), pred.cpu().tolist()
        out = []
        for b, words in enumerate(batch):
            tags, cf, seen = ["O"] * len(words), [0.0] * len(words), set()
            for t, w in enumerate(enc.word_ids(batch_index=b)):
                if w is None or w in seen:
                    continue
                seen.add(w)
                tags[w], cf[w] = self.id2label[pred[b][t]], conf[b][t]
            out.append((tags, cf))
        return out

    def _windows(self, words):
        n = len(words)
        if n == 0:
            return []
        if n <= self.max_words and self._n_subwords(words) <= self.max_len:
            return [(0, n)]
        size = min(self.max_words, n)
        while True:
            wins = _make_windows(n, size)
            if size <= 4 or all(self._n_subwords(words[a:b]) <= self.max_len for a, b in wins):
                return wins
            size = max(4, size * 3 // 4)

    # ------------------------------------------------------------------ từ điển
    def _load_gazetteer(self, path):
        if not os.path.exists(path):
            raise FileNotFoundError(f"Không thấy từ điển: {path}")
        pairs = []
        if path.lower().endswith(".csv"):
            with open(path, encoding="utf-8-sig", newline="") as f:
                pairs = [(r["name"], r["label"]) for r in csv.DictReader(f) if r.get("name") and r.get("label")]
        else:
            with open(path, encoding="utf-8-sig") as f:
                pairs = [(n, lab) for lab, names in json.load(f).items() for n in names]
        gaz, skipped = {}, set()
        for name, label in pairs:
            lab = LABEL_ALIASES.get(nfc(label).strip().lower(), label).strip().upper().replace(" ", "_")
            if lab not in self.labels:
                skipped.add(label)
                continue
            key = tuple(simple_tokenize(nfc(name)))
            if key:
                gaz[key] = lab
        if skipped:
            msg = f"Bỏ qua nhãn trong từ điển mà mô hình không có: {sorted(skipped)}"
            self.warnings.append(msg)
            log.warning(msg)
        return gaz

    def _apply_dict(self, words, tags, src):
        n, i = len(words), 0
        while i < n:
            hit = None
            for L in range(min(self._max_gaz, n - i), 0, -1):
                lab = self.gazetteer.get(tuple(words[i:i + L]))
                if lab and all(t == "O" for t in tags[i:i + L]):
                    hit = (L, lab)
                    break
            if hit:
                L, lab = hit
                for j in range(i, i + L):
                    tags[j] = ("B-" if j == i else "I-") + lab
                    src[j] = "dict"
                i += L
            else:
                i += 1

    # ------------------------------------------------------------------ API chính
    def info(self):
        return {"model_dir": self.model_dir, "device": getattr(self, "device", "?"), "labels": self.labels,
                "dict_names": len(self.gazetteer), "max_len": self.max_len, "warnings": self.warnings}

    def extract(self, text, min_score=0.0, use_dict=True, with_context=False):
        return self.extract_many([text], min_score, use_dict, with_context)[0]

    def extract_many(self, texts, min_score=0.0, use_dict=True, with_context=False):
        docs = [nfc(t or "") for t in texts]
        units = []  # (doc_idx, [(word, start, end)], sent_start, sent_end)
        for di, d in enumerate(docs):
            for s_off, sent in split_sentences_with_offsets(d):
                toks = [(m.group(), s_off + m.start(), s_off + m.end()) for m in TOKEN_RE.finditer(sent)]
                if toks:
                    units.append((di, toks, s_off, s_off + len(sent)))

        items = []  # (unit_idx, a, b)
        for ui, (_, toks, _, _) in enumerate(units):
            words = [t[0] for t in toks]
            items += [(ui, a, b) for a, b in self._windows(words)]

        preds = [None] * len(items)
        order = sorted(range(len(items)), key=lambda k: items[k][2] - items[k][1])
        for i in range(0, len(order), self.batch_size):
            idx = order[i:i + self.batch_size]
            batch = [[w for w, _, _ in units[items[k][0]][1][items[k][1]:items[k][2]]] for k in idx]
            for k, res in zip(idx, self._predict_windows(batch)):
                preds[k] = res

        merged = [None] * len(units)
        for (ui, a, b), (tags_w, conf_w) in zip(items, preds):
            n = len(units[ui][1])
            if merged[ui] is None:
                merged[ui] = (["O"] * n, [0.0] * n, [-1] * n)
            tags, conf, best = merged[ui]
            for k in range(b - a):
                margin = min(k, b - a - 1 - k)
                if margin > best[a + k]:
                    best[a + k], tags[a + k], conf[a + k] = margin, tags_w[k], conf_w[k]

        results = [{"text": d, "entities": []} for d in docs]
        for ui, (di, toks, s_start, s_end) in enumerate(units):
            tags, conf, _ = merged[ui]
            words = [t[0] for t in toks]
            src = ["model"] * len(words)
            if use_dict and self.gazetteer:
                self._apply_dict(words, tags, src)
            for s, e, lab in bio_spans(tags):
                is_dict = all(src[k] == "dict" for k in range(s, e))
                score = None if is_dict else round(min(conf[k] for k in range(s, e) if src[k] == "model"), 4)
                if score is not None and score < min_score:
                    continue
                start, end = toks[s][1], toks[e - 1][2]
                ent = {"label": lab, "text": docs[di][start:end], "start": start, "end": end,
                       "score": score, "source": "dict" if is_dict else "model"}
                if with_context:
                    ent["context"] = docs[di][s_start:s_end]
                results[di]["entities"].append(ent)
        return results
