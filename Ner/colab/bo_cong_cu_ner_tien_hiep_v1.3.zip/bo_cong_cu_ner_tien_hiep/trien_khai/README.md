# Triển khai mô hình NER truyện tiên hiệp

Thư mục này dùng để **đưa mô hình đã huấn luyện (`ner-final/`) vào sử dụng**. Có 3 cách:

| Cách | Khi nào dùng | File |
|---|---|---|
| **A. Xử lý hàng loạt file truyện** | Trích danh sách nhân vật, địa danh… của cả bộ truyện; xuất Excel/HTML | `xu_ly_file.py` |
| **B. API nội bộ** | Hệ thống khác cần gọi mô hình qua HTTP | `api.py`, `Dockerfile` |
| **C. Gọi trực tiếp trong Python** | Tích hợp vào code của bạn | `ner_engine.py` |
| **D. Gộp tên đồng nhất** | Gom các cách gọi của cùng một nhân vật/địa danh… thành một thực thể | `gop_ten.py` |

Cả 3 cách A, B, C dùng chung `ner_engine.py`. Cách D chạy trên kết quả của cách A. Engine này:
- Tách câu và tách từ **giống hệt lúc huấn luyện**.
- Tự chia câu quá dài thành **các cửa sổ chồng lấn**, nên không cắt đôi thực thể.
- Gom nhiều câu thành batch để chạy nhanh.
- Trả về **vị trí ký tự**, **điểm tin cậy** và **nguồn** (mô hình hay từ điển) của từng thực thể.

```
trien_khai/
├── README.md                ← tài liệu này
├── ner_engine.py            ← lõi suy luận (dùng chung)
├── xu_ly_file.py            ← cách A: xử lý hàng loạt file .txt
├── api.py                   ← cách B: API FastAPI
├── goi_api_mau.py           ← ví dụ gọi API (thư viện chuẩn, không cần cài gì)
├── gop_ten.py               ← cách D: gộp tên đồng nhất (thư viện chuẩn)
├── bi_danh_mau.json         ← mẫu file bí danh cho gop_ten.py
├── Dockerfile, .dockerignore
└── requirements-deploy.txt
```

---

## 0. Chuẩn bị

### 0.1 Kiểm tra thư mục mô hình

Sau khi chạy notebook, thư mục `ner-final/` phải có ít nhất các file sau:

```
ner-final/
├── config.json                          ← có id2label gồm 6 nhãn (B-/I-)
├── model.safetensors  (hoặc pytorch_model.bin)
├── tokenizer.json, tokenizer_config.json, special_tokens_map.json
└── labels.json
```

Kích thước khoảng 0,7 GB, do bộ từ vựng 128K làm lớp embedding khá nặng. Nên **ghi lại phiên bản mô hình** (ví dụ đổi tên thành `ner-final-v1-2026-11-12/`) cùng với F1 trên tập test, để sau này biết đang chạy bản nào.

### 0.2 Cài đặt

```bash
# Cài PyTorch theo https://pytorch.org (bản CPU hoặc CUDA phù hợp với máy), rồi:
pip install -r requirements-deploy.txt
```

### 0.3 Thử nhanh

```bash
cd trien_khai
python xu_ly_file.py --model ../ner-final --text "Tiêu Viêm thi triển Phật Nộ Hỏa Liên về phía đệ tử Vân Lam Tông."
```

Kết quả có dạng như sau (điểm thực tế tuỳ mô hình của bạn):

```
Nhãn: CONG_PHAP, DIA_DANH, DI_HOA, NHAN_VAT, THE_LUC, VU_KHI | thiết bị: cuda
  [NHAN_VAT  ] Tiêu Viêm                        (0-9, 0.998)
  [CONG_PHAP ] Phật Nộ Hỏa Liên                 (20-36, 0.991)
  [THE_LUC   ] Vân Lam Tông                     (51-63, 0.995)
```

---

## A. Xử lý hàng loạt file truyện

Thư mục đầu vào tổ chức giống lúc chuẩn bị dữ liệu: mỗi bộ truyện một thư mục con, mỗi chương một file `.txt` UTF-8.

```bash
python xu_ly_file.py --model ../ner-final --input ../truyen/ --out ket_qua/ --html
# Thêm từ điển tên để bổ sung tên mô hình bỏ sót:
python xu_ly_file.py --model ../ner-final --input ../truyen/ --out ket_qua/ --dict ../tu_dien.json --html
```

**Kết quả trong `ket_qua/`:**

| File | Nội dung | Dùng để |
|---|---|---|
| `entities.csv` | Mỗi dòng là **một lần xuất hiện**: file, bộ truyện, chương, vị trí, nhãn, tên, điểm tin cậy, nguồn, câu chứa tên | Mở bằng Excel, lọc, tra cứu |
| `entities.jsonl` | Như trên, dạng JSON | Nạp vào hệ thống khác |
| `tong_hop.csv` | **Danh sách tên duy nhất** theo nhãn: số lần xuất hiện, số chương, số bộ, điểm tin cậy trung bình, file xuất hiện đầu tiên | Lập danh sách nhân vật, địa danh…; bổ sung từ điển |
| `html/*.html` | Văn bản từng chương, **tô màu thực thể**. Rê chuột lên tên để xem nhãn và điểm | Đọc kiểm tra bằng mắt |
| `report.txt` | Số thực thể theo nhãn, top 10 tên mỗi nhãn, tốc độ xử lý | Xem nhanh |

**Tham số hay dùng:**

| Tham số | Mặc định | Ý nghĩa |
|---|---|---|
| `--min-score` | `0` | Bỏ thực thể có điểm tin cậy thấp hơn ngưỡng. Thường dùng `0.5`–`0.7` khi cần độ chính xác cao. Tên lấy từ từ điển không bị lọc |
| `--dict` | — | Từ điển tên, chỉ **bổ sung** vào chỗ mô hình bỏ trống, **không ghi đè** dự đoán |
| `--batch-size` | `32` | GPU 16 GB: 32–64. CPU: 8–16 |
| `--device` | tự chọn | `cuda` hoặc `cpu` |
| `--threads` | mặc định của PyTorch | Số luồng CPU khi chạy trên CPU |
| `--max-len` | `256` | **Nên bằng `MAX_LEN` lúc huấn luyện** |

> 💡 **Dùng kết quả để cải thiện dữ liệu.** Lọc trong `tong_hop.csv` các tên có `avg_score` thấp (ví dụ dưới 0,7): đó thường là các ca mô hình còn phân vân. Kiểm tra các tên này, bổ sung vào từ điển hoặc đưa thêm câu chứa chúng vào vòng gán nhãn tiếp theo.

---

## B. API nội bộ

### B.1 Chạy trực tiếp

```bash
cd trien_khai
export MODEL_DIR=../ner-final          # Windows PowerShell: $env:MODEL_DIR="..\ner-final"
export API_KEY=doi-mat-khau-nay        # nên đặt; bỏ trống = không cần xác thực
uvicorn api:app --host 0.0.0.0 --port 8000 --workers 1
```

Mở **http://localhost:8000/docs** để thử API ngay trên trình duyệt (Swagger).

### B.2 Các endpoint

| Endpoint | Mô tả |
|---|---|
| `GET /health` | Trạng thái, danh sách nhãn, thiết bị, số tên trong từ điển. Không cần API key |
| `POST /extract` | Một văn bản |
| `POST /extract/batch` | Nhiều văn bản (mặc định tối đa 64), nhanh hơn gọi lẻ từng cái |

**Request `/extract`:**

```json
{
  "text": "Tiêu Viêm thi triển Phật Nộ Hỏa Liên về phía đệ tử Vân Lam Tông.",
  "min_score": 0.5,
  "use_dict": true,
  "include_context": false
}
```

**Response** (điểm minh hoạ):

```json
{
  "text": "Tiêu Viêm thi triển Phật Nộ Hỏa Liên về phía đệ tử Vân Lam Tông.",
  "entities": [
    {"label": "NHAN_VAT",  "text": "Tiêu Viêm",        "start": 0,  "end": 9,  "score": 0.998, "source": "model", "context": null},
    {"label": "CONG_PHAP", "text": "Phật Nộ Hỏa Liên", "start": 20, "end": 36, "score": 0.991, "source": "model", "context": null},
    {"label": "THE_LUC",   "text": "Vân Lam Tông",     "start": 51, "end": 63, "score": 0.995, "source": "model", "context": null}
  ],
  "elapsed_ms": 18.4
}
```

- `start`/`end` là vị trí ký tự trên trường `text` của response. Đó là văn bản đã chuẩn hoá Unicode NFC; với văn bản gõ thông thường thì trùng với văn bản gốc.
- `score` là **điểm tin cậy thấp nhất** trong các từ của thực thể (0–1). Bằng `null` nếu tên lấy từ từ điển.
- `source` là `model` hoặc `dict`.

**Gọi thử:**

```bash
curl -X POST http://localhost:8000/extract \
     -H "Content-Type: application/json" -H "X-API-Key: doi-mat-khau-nay" \
     -d '{"text": "Hắn luyện hóa Thanh Liên Địa Tâm Hỏa."}'

python goi_api_mau.py --url http://localhost:8000 --key doi-mat-khau-nay
```

> Trên Windows, `curl` trong cmd dễ lỗi dấu tiếng Việt và dấu nháy. Dùng `goi_api_mau.py` hoặc trang `/docs` thay thế.

### B.3 Biến môi trường

| Biến | Mặc định | Ý nghĩa |
|---|---|---|
| `MODEL_DIR` | `ner-final` | Thư mục mô hình |
| `DICT_PATH` | — | Từ điển tên (tuỳ chọn) |
| `DEVICE` | tự chọn | `cuda` / `cpu` |
| `BATCH_SIZE` | `32` | Kích thước batch |
| `MAX_LEN` | `256` | Bằng `MAX_LEN` lúc huấn luyện |
| `TORCH_THREADS` | — | Số luồng CPU |
| `API_KEY` | — | Nếu đặt thì mọi request (trừ `/health`) phải có header `X-API-Key` |
| `MAX_TEXT_CHARS` | `200000` | Độ dài tối đa mỗi văn bản (vượt quá thì trả lỗi 413) |
| `MAX_BATCH_ITEMS` | `64` | Số văn bản tối đa mỗi request batch |

### B.4 Chạy bằng Docker

```bash
cd trien_khai
docker build -t ner-tien-hiep:1.0 .

docker run -d --name ner-api -p 8000:8000 \
  -v /duong/dan/den/ner-final:/models/ner-final:ro \
  -e API_KEY=doi-mat-khau-nay \
  --restart unless-stopped \
  ner-tien-hiep:1.0

docker logs -f ner-api          # xem log
curl http://localhost:8000/health
```

- Image dùng **PyTorch bản CPU**. Mô hình được **gắn từ ngoài vào** (`-v … :ro`) thay vì đóng gói vào image, nên khi có mô hình mới chỉ cần trỏ sang thư mục mới rồi khởi động lại container.
- Container đã có health check, chạy bằng user thường (không phải root) và ở chế độ offline (không tải gì từ Hugging Face).
- **Muốn dùng GPU:** đổi image gốc sang một image có CUDA và cài PyTorch bản CUDA thay cho dòng `--index-url …/cpu`. Máy chủ cần NVIDIA Container Toolkit, chạy với `docker run --gpus all …`.

### B.5 Mở rộng và hiệu năng

- Mỗi tiến trình nạp **một bản mô hình** (khoảng 1–2 GB RAM) và xử lý **tuần tự** để an toàn. Vì vậy hãy giữ `--workers 1`. Khi cần chịu tải lớn hơn, chạy **nhiều container** phía sau một load balancer.
- Gửi nhiều văn bản trong một request `/extract/batch` sẽ nhanh hơn nhiều so với gọi `/extract` từng cái.
- Trên CPU, đặt `TORCH_THREADS` bằng số nhân CPU dành cho container.
- Văn bản rất dài (cả chương): nên dùng **cách A** (`xu_ly_file.py`) thay vì API.

---

## C. Gọi trực tiếp trong Python

```python
import sys; sys.path.insert(0, "trien_khai")
from ner_engine import NerEngine

eng = NerEngine("ner-final", dict_path="tu_dien.json", batch_size=32)   # nạp 1 lần, dùng nhiều lần
print(eng.info())

kq = eng.extract("Tiêu Viêm rút Huyền Trọng Thước.", min_score=0.5)
for e in kq["entities"]:
    print(e["label"], e["text"], e["start"], e["end"], e["score"], e["source"])

ds = eng.extract_many(["Câu 1 ...", "Câu 2 ..."], with_context=True)    # nhiều văn bản: nhanh hơn
```

---

## D. Gộp tên đồng nhất (entity linking)

Mô hình NER chỉ trả về **từng lần xuất hiện**, nên "Nạp Lan Yên Nhiên" và "Yên Nhiên" bị tính là 2 tên khác nhau. `gop_ten.py` gom **mọi cách gọi của cùng một thực thể** về **một mã thực thể** (ví dụ `dau_pha:NV0003`), kèm một **tên chuẩn**.

### D.1 Script xử lý được gì

| Trường hợp | Ví dụ | Cách xử lý |
|---|---|---|
| Khác hoa/thường | Dược Lão = Dược lão | Tự động |
| Khác vị trí dấu thanh | Hỏa = Hoả, Thủy = Thuỷ | Tự động |
| Mô hình lỡ lấy cả xưng hô | Tiêu Viêm ca ca, Viêm nhi | Tự động bỏ phần xưng hô viết thường |
| Gia / tộc | Tiêu gia = Tiêu tộc | Tự động |
| **Tên gọi tắt** = phần cuối họ tên | Yên Nhiên → Nạp Lan Yên Nhiên | Tự động, nếu **chỉ khớp 1** nhân vật |
| Bỏ chữ chỉ loại ở cuối | Ô Thản → Ô Thản Thành | Tự động, nếu **chỉ khớp 1** địa danh/thế lực |
| **Tên ngắn mơ hồ** | "Viêm" khi có cả Tiêu Viêm và Âu Dương Viêm | Từng lần xuất hiện được gán cho thực thể **được nhắc gần nhất trong cùng chương** (mặc định trong phạm vi 3.000 ký tự). Kết quả **nên được duyệt** |
| Có thể sai dấu / lỗi chính tả | Tieu Viem ~ Tiêu Viêm; Địa ~ Đại | **Chỉ gợi ý**, người duyệt quyết định |
| Tên thật, biệt danh, tên khác họ | Dược Lão = Dược Trần; Tiêu Huân Nhi = Cổ Huân Nhi | **Không tự đoán được.** Khai báo trong file bí danh |
| Cùng một tên nhưng bị gán 2 nhãn | "Vẫn Lạc Tâm Viêm": DI_HOA ×8, NHAN_VAT ×7 | Không gộp. Liệt kê trong `xung_dot_nhan.csv` |

Mặc định script **chỉ gộp trong cùng một bộ truyện** (`--scope novel`), vì hai bộ truyện khác nhau có thể có hai nhân vật trùng tên. Nếu các thư mục là các phần của **cùng một bộ truyện**, dùng `--scope global`, hoặc khai báo bí danh dưới khoá `"*"`.

**Không xử lý:** đại từ ("hắn", "nàng", "lão") và danh hiệu không được gán nhãn ("Viêm Đế"). Đó là bài toán *đồng tham chiếu* (coreference), cần mô hình và dữ liệu gán nhãn riêng.

### D.2 Quy trình (lặp 1–3 vòng)

```bash
# 1. Trích thực thể (cách A) -> ket_qua/entities.jsonl
python xu_ly_file.py --model ../ner-final --input ../truyen/ --out ket_qua/

# 2. Gộp tên
python gop_ten.py gop --input ket_qua/entities.jsonl --out lien_ket/

# 3. Mở lien_ket/can_duyet.csv bằng Excel, điền cột quyet_dinh (xem D.4), lưu lại dạng "CSV UTF-8"

# 4. Ghi quyết định vào file bí danh (tạo mới nếu chưa có; bản cũ được giữ ở bi_danh.json.bak)
python gop_ten.py ap-dung --review lien_ket/can_duyet.csv --alias bi_danh.json

# 5. Gộp lại với file bí danh
python gop_ten.py gop --input ket_qua/entities.jsonl --alias bi_danh.json --out lien_ket/
```

Lần sau xử lý chương mới của cùng bộ truyện, chỉ cần chạy bước 1, 2 và 5 với **cùng file `bi_danh.json`**. Các quyết định cũ vẫn được áp dụng, nên số dòng cần duyệt giảm dần.

### D.3 Kết quả trong `lien_ket/`

| File | Nội dung |
|---|---|
| `thuc_the.csv` | **Mỗi dòng là 1 thực thể:** mã, nhãn, tên chuẩn, số lần xuất hiện, các cách gọi kèm số lần ("Tiêu Viêm ×24 \| Viêm ×14"), số chương, chương đầu/cuối |
| `lan_xuat_hien.csv` / `.jsonl` | Như `entities.csv` của cách A, thêm 3 cột `entity_id`, `ten_chuan`, `cach_lien_ket` (vì sao lần xuất hiện này được gán cho thực thể đó) |
| `can_duyet.csv` | **Danh sách cần người duyệt**, xếp theo mức ưu tiên (xem D.4) |
| `xung_dot_nhan.csv` | Tên bị gán nhiều nhãn khác nhau, kèm tỉ lệ và ví dụ |
| `tu_dien_mo_rong.json` | Tất cả tên và cách gọi đã gộp (từ 2 âm tiết, xuất hiện ≥ 3 lần), cùng định dạng từ điển của bộ công cụ |
| `report.txt` | Thống kê: số cách viết → số thực thể, cách liên kết, top thực thể |

Giá trị cột `cach_lien_ket`: `ten_chuan` (đúng tên chuẩn), `bien_the` (khác hoa/thường, vị trí dấu, gia/tộc), `hau_to` (tên gọi tắt), `bo_chu_chi_loai`, `bi_danh` (theo file bí danh), `ngu_canh` (tên mơ hồ, xác định theo ngữ cảnh), `chua_xac_dinh` (tên mơ hồ, không đủ ngữ cảnh: `entity_id` để trống).

### D.4 Cách điền `can_duyet.csv`

Mỗi dòng hỏi: **"`ten_a` có phải là `ten_b` không?"** Cột `vi_du` là một câu chứa `ten_a`. Chỉ điền cột `quyet_dinh` ở những dòng cần thay đổi:
- `y` = gộp (luôn luôn coi `ten_a` là `ten_b`).
- `n` = không gộp.
- **Để trống** = giữ nguyên như script đang làm.

| `loai` | Ưu tiên | Script đang làm gì | Bạn nên làm |
|---|---|---|---|
| `mo_ho` | 1 | Tên ngắn khớp nhiều thực thể (mỗi ứng viên một dòng). Đang xác định **theo ngữ cảnh từng lần** | Nếu tên ngắn **luôn** chỉ một người: `y` ở **đúng 1 dòng** đó. Nếu tuỳ đoạn mà chỉ người khác nhau: để trống. Nếu chắc chắn không bao giờ chỉ người ở dòng nào: `n` ở dòng đó |
| `hau_to` (1 âm tiết) | 1 | **Đã gộp tự động**, nhưng tên 1 âm tiết dễ nhầm | Sai thì `n` |
| `sai_dau`, `chinh_ta` | 2 | **Chưa gộp**, chỉ gợi ý | Cùng một thực thể: `y`. Khác nhau: `n` (lần sau không gợi ý lại) |
| `bo_chu_chi_loai` | 2 | Đã gộp tự động | Sai thì `n` |
| `hau_to` (≥ 2 âm tiết) | 3 | Đã gộp tự động, thường đúng | Xem lướt, sai thì `n` |

> ⚠️ Với `mo_ho`, **không chọn `y` ở nhiều dòng của cùng một tên ngắn**: làm vậy sẽ gộp các thực thể đó làm một. Lệnh `ap-dung` sẽ cảnh báo và chỉ lấy dòng đầu tiên. Nếu các ứng viên **thực ra là cùng một người** (ví dụ "Tiêu Huân Nhi" và "Cổ Huân Nhi"), hãy khai báo bí danh cho chúng trong `bi_danh.json` (xem D.5).

### D.5 File bí danh `bi_danh.json`

Thường được **tạo và cập nhật tự động** bằng lệnh `ap-dung`. Chỉ cần sửa tay khi muốn khai báo những cách gọi mà script không tự đoán được (tên thật, biệt danh). Xem mẫu `bi_danh_mau.json`:

```json
{
  "bi_danh": {
    "dau_pha_thuong_khung": {
      "NHAN_VAT": {
        "Dược Lão":    ["Dược Trần"],
        "Cổ Huân Nhi": ["Tiêu Huân Nhi", "Huân Nhi"]
      }
    },
    "*": { "THE_LUC": {} }
  },
  "khong_gop": [
    {"novel": "dau_pha_thuong_khung", "label": "NHAN_VAT", "a": "Tiêu Yên Nhiên", "b": "Liễu Yên Nhiên"}
  ]
}
```

- **Khoá cấp 1:** tên thư mục bộ truyện (giống cột `novel`), hoặc `"*"` để áp dụng cho mọi bộ truyện.
- **Tên đứng trước dấu `:`** là **tên chuẩn** sẽ hiển thị. Danh sách phía sau là các cách gọi khác của cùng thực thể đó.
- Bí danh **luôn được ưu tiên** hơn quy tắc tự động và hơn danh sách `khong_gop`.
- File mẫu chỉ để minh hoạ. Hãy kiểm tra tên theo bản dịch bạn dùng.

### D.6 Dùng kết quả để cải thiện bộ dữ liệu và mô hình

- **`xung_dot_nhan.csv`:** cùng một tên mà mô hình gán 2 nhãn là dấu hiệu mô hình còn lẫn lộn (ví dụ dị hỏa có chữ "Viêm" bị nhận là nhân vật). Đưa các câu này vào vòng gán nhãn tiếp theo (`xay_dung_du_lieu.py select`).
- **`tu_dien_mo_rong.json`:** gộp vào từ điển tên của dự án để:
  - Tạo nhãn nháp tốt hơn khi chạy `gan_nhan_nhap_tu_dien.py` / `xay_dung_du_lieu.py prepare`.
  - Bổ sung tên mô hình bỏ sót khi chạy `xu_ly_file.py --dict`.

  Hãy xem lướt trước khi gộp: file chỉ chứa tên từ 2 âm tiết trở lên, nhưng vẫn có thể lẫn tên do mô hình nhận sai.
- **`thuc_the.csv`:** dùng trực tiếp làm **danh sách nhân vật, địa danh, công pháp…** của từng bộ truyện.

### D.7 Gọi trong Python

```python
from gop_ten import link, load_alias
from ner_engine import NerEngine

eng = NerEngine("ner-final")
kq = eng.extract(van_ban_chuong)
ms = [dict(e, novel="dau_pha_thuong_khung", file="chuong_001") for e in kq["entities"]]
res = link(ms, alias=load_alias("bi_danh.json"))       # bỏ alias=... nếu chưa có file
for e in res["entities"]:
    print(e["entity_id"], e["label"], e["ten_chuan"], e["cac_bien_the"])
```

### D.8 Kết quả thử nghiệm và giới hạn

Thử trên **dữ liệu giả lập có đáp án**: 3 bộ truyện, 1.476 lần xuất hiện, khoảng 200 thực thể. Dữ liệu có cố ý nhiều nhân vật trùng tên ngắn, xuất hiện cùng cảnh với nhau. Điểm đo bằng B-cubed: P là mỗi cụm có lẫn thực thể khác không, R là mỗi thực thể có bị tách ra nhiều cụm không.

| | Chỉ khớp chuỗi y hệt | Gộp tên (chưa duyệt) | Sau 1 vòng duyệt + bí danh |
|---|---|---|---|
| Nhân vật (P / R / F) | 0,93 / 0,64 / 0,76 | 0,96 / 0,94 / 0,95 | 0,96 / 0,97 / 0,97 |
| Tất cả nhãn (F) | 0,85 | 0,97 | 0,97 |

Độ chính xác theo từng cách liên kết:
- Các quy tắc chắc chắn (`bien_the`, `hau_to`, `bo_chu_chi_loai`, `bi_danh`) đúng 100% trên dữ liệu thử.
- **`ngu_canh` đúng khoảng 84%.** Lỗi gần như luôn rơi vào cảnh có **2 người trùng tên ngắn cùng xuất hiện**.

Tốc độ: khoảng 60.000 lần xuất hiện mất khoảng 1 giây.

> Đây là số liệu trên dữ liệu **giả lập**: văn bản ngắn, mẫu câu đơn giản. Trên truyện thật, kết quả phụ thuộc vào cách tác giả và người dịch gọi tên nhân vật. Hãy xem `report.txt` và duyệt các dòng ưu tiên 1 trong `can_duyet.csv` trước khi dùng kết quả.

---

## Kiểm tra trước khi đưa vào sử dụng

- [ ] F1 trên **tập test (bộ truyện giữ riêng)** đạt yêu cầu ở **từng nhãn**, không chỉ ở con số tổng.
- [ ] Chạy cách A trên **1–2 chương truyện thật chưa dùng để train**, mở file HTML và đọc kiểm tra bằng mắt.
- [ ] Chọn ngưỡng `min_score` phù hợp: thử vài giá trị trên tập test, chọn mức cân bằng giữa bắt đủ tên và ít nhận nhầm.
- [ ] Đặt `API_KEY`; **không mở API ra Internet**. Nếu cần HTTPS, đặt API sau reverse proxy (nginx…) hoặc API gateway của tổ chức.
- [ ] Ghi lại phiên bản mô hình đang chạy (xem `GET /health`, trường `model_dir`).
- [ ] Giám sát log: số request, thời gian xử lý (`elapsed_ms`), lỗi 4xx/5xx.

**Cập nhật mô hình mới:** huấn luyện lại, kiểm tra F1 trên **cùng tập test cũ** để so sánh công bằng. Nếu tốt hơn thì đổi `MODEL_DIR` (hoặc thư mục gắn vào Docker) rồi khởi động lại. Giữ lại thư mục mô hình cũ để có thể quay về khi cần.

**Nếu tổ chức dùng AWS:** image Docker này chạy được trên các dịch vụ container (ví dụ Amazon ECS, hoặc EC2 có Docker). Ngoài ra có thể dùng Amazon SageMaker để host mô hình Hugging Face. Hãy trao đổi với nhóm hạ tầng để chọn phương án phù hợp với quy định nội bộ.

---

## Xử lý sự cố

| Vấn đề | Cách xử lý |
|---|---|
| `thiếu config.json` | `--model` phải trỏ tới thư mục do `trainer.save_model()` tạo ra (`ner-final/`), không phải thư mục checkpoint `ner-out/` |
| Lỗi khi nạp `pytorch_model.bin` | Nâng PyTorch lên ≥ 2.6 |
| `Cần fast tokenizer` | Thư mục mô hình thiếu `tokenizer.json`: chạy lại ô "Lưu mô hình" trong notebook |
| Kết quả khác lúc chạy trong notebook | Kiểm tra `--max-len` / `MAX_LEN` có bằng lúc huấn luyện không |
| Chạy chậm trên CPU | Tăng `--threads` / `TORCH_THREADS`, giảm `--batch-size`, hoặc dùng GPU |
| `CUDA out of memory` | Giảm `--batch-size` / `BATCH_SIZE` |
| API trả 401 | Thiếu header `X-API-Key`, hoặc sai giá trị |
| API trả 413 | Văn bản quá dài hoặc quá nhiều văn bản: chia nhỏ, tăng `MAX_TEXT_CHARS` / `MAX_BATCH_ITEMS`, hoặc dùng cách A |
| Từ điển báo "Bỏ qua nhãn …" | Tên nhãn trong từ điển không có trong mô hình: sửa lại cho khớp 6 mã nhãn |
| `gop_ten.py`: hai nhân vật khác nhau bị gộp | Điền `n` ở dòng tương ứng trong `can_duyet.csv` → `ap-dung` → chạy lại `gop` |
| `gop_ten.py`: quá nhiều dòng `mo_ho` | Bình thường khi nhiều nhân vật có tên ngắn giống nhau. Duyệt các tên có `so_lan_a` lớn trước |
| `ap-dung`: "File không có cột quyet_dinh" | Khi lưu bằng Excel chọn kiểu **CSV UTF-8 (Comma delimited)** và giữ nguyên dòng tiêu đề |

---

**Tình trạng kiểm thử (phiên bản 1.2):**
- ✅ Đã chạy thử với một **mô hình giả lập** (nên không đo được độ chính xác thật):
  - Logic tách câu, cửa sổ trượt cho câu dài 85–121 từ, ghép batch, vị trí ký tự, từ điển bổ sung, ngưỡng `min_score`.
  - Xử lý hàng loạt 16 file mẫu: CSV, tổng hợp, HTML, vị trí khớp 100% với văn bản gốc.
  - Toàn bộ endpoint API: xác thực, giới hạn kích thước, kiểm tra dữ liệu đầu vào, trang `/docs`.
- ✅ `gop_ten.py`: thử trên dữ liệu giả lập có đáp án (xem D.8):
  - Đầu vào CSV cho kết quả giống hệt JSONL; chạy được cả `--scope global`.
  - Vòng duyệt `ap-dung`: thêm bí danh, chặn gộp, cảnh báo khi chọn `y` cho nhiều ứng viên.
  - Khoảng 60.000 lần xuất hiện xử lý trong khoảng 1 giây.
- ⚠️ **Chưa chạy thử:** với mô hình ViDeBERTa thật và truyện thật, `docker build` / `docker run`, và `goi_api_mau.py` với máy chủ thật.
