#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Xử lý hàng loạt file truyện bằng mô hình NER đã huấn luyện.

Cách chạy
  # Thử nhanh một câu
  python xu_ly_file.py --model ../ner-final --text "Tiêu Viêm thi triển Phật Nộ Hỏa Liên."

  # Cả thư mục truyện (mỗi bộ truyện 1 thư mục con, mỗi chương 1 file .txt)
  python xu_ly_file.py --model ../ner-final --input truyen/ --out ket_qua/ --dict tu_dien.json --html

Đầu ra (trong --out)
  entities.csv    : mỗi dòng 1 lần xuất hiện thực thể (mở bằng Excel được)
  entities.jsonl  : như trên, dạng JSON
  tong_hop.csv    : danh sách tên riêng duy nhất: số lần xuất hiện, số chương, điểm tin cậy trung bình
  html/           : (nếu --html) văn bản tô màu thực thể để đọc kiểm tra
  report.txt      : thống kê, tốc độ xử lý
"""
import argparse
import csv
import html as htmlmod
import json
import os
import re
import sys
import time
from collections import Counter, defaultdict

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from ner_engine import NerEngine  # noqa: E402

COLORS = {"NHAN_VAT": "#FADBD8", "DIA_DANH": "#D5F5E3", "VU_KHI": "#E8DAEF",
          "CONG_PHAP": "#D6EAF8", "DI_HOA": "#FDEBD0", "THE_LUC": "#D1F2EB"}


def natkey(s):
    return [int(t) if t.isdigit() else t for t in re.split(r"(\d+)", s)]


def collect_files(inputs):
    for root in inputs:
        if os.path.isfile(root):
            stem = os.path.splitext(os.path.basename(root))[0]
            yield root, os.path.basename(root), stem, stem
        elif os.path.isdir(root):
            for dirpath, dirnames, names in os.walk(root):
                dirnames.sort()
                for n in sorted(names, key=natkey):
                    if n.lower().endswith(".txt"):
                        p = os.path.join(dirpath, n)
                        rel = os.path.relpath(p, root)
                        parts = rel.split(os.sep)
                        novel = parts[0] if len(parts) > 1 else os.path.splitext(parts[0])[0]
                        chapter = os.path.splitext("/".join(parts[1:]) if len(parts) > 1 else parts[0])[0]
                        yield p, rel, novel, chapter
        else:
            print(f"⚠️ Bỏ qua, không tìm thấy: {root}")


def chunk_text(text, max_chars):
    """Chia văn bản dài thành các khúc ~max_chars ký tự, cắt tại xuống dòng. Trả về [(offset, khúc)]."""
    if len(text) <= max_chars:
        return [(0, text)]
    chunks, start = [], 0
    while start < len(text):
        end = min(start + max_chars, len(text))
        if end < len(text):
            nl = text.rfind("\n", start, end)
            if nl > start:
                end = nl + 1
        chunks.append((start, text[start:end]))
        start = end
    return chunks


def to_html(title, text, ents):
    out, pos = [], 0
    for e in sorted(ents, key=lambda x: x["start"]):
        out.append(htmlmod.escape(text[pos:e["start"]]))
        tip = f'{e["label"]} | {e["source"]}' + (f' | {e["score"]:.2f}' if e["score"] is not None else "")
        style = f'background:{COLORS.get(e["label"], "#EEE")};' + ("border-bottom:2px dashed #888;" if e["source"] == "dict" else "")
        out.append(f'<mark style="{style}" title="{htmlmod.escape(tip)}">{htmlmod.escape(text[e["start"]:e["end"]])}'
                   f'<sup>{e["label"]}</sup></mark>')
        pos = e["end"]
    out.append(htmlmod.escape(text[pos:]))
    legend = " ".join(f'<mark style="background:{c}">{l}</mark>' for l, c in COLORS.items())
    body = "".join(out).replace("\n", "<br>\n")
    return ("<!DOCTYPE html><html lang='vi'><head><meta charset='utf-8'>"
            f"<title>{htmlmod.escape(title)}</title><style>body{{font-family:Arial,sans-serif;max-width:900px;"
            "margin:24px auto;line-height:1.8;padding:0 16px}mark{padding:1px 3px;border-radius:3px}"
            "sup{font-size:9px;color:#555;margin-left:2px}</style></head><body>"
            f"<h2>{htmlmod.escape(title)}</h2><p>{legend} &nbsp; <i>(gạch chân đứt = lấy từ từ điển)</i></p>"
            f"<div>{body}</div></body></html>")


def process(engine, inputs, out_dir, min_score=0.0, use_dict=True, html=False, chunk_chars=20000):
    os.makedirs(out_dir, exist_ok=True)
    if html:
        os.makedirs(os.path.join(out_dir, "html"), exist_ok=True)
    files = list(collect_files(inputs))
    if not files:
        sys.exit("❌ Không có file .txt nào trong --input")

    fields = ["file", "novel", "chapter", "start", "end", "label", "text", "score", "source", "context"]
    f_csv = open(os.path.join(out_dir, "entities.csv"), "w", encoding="utf-8-sig", newline="")
    f_jsonl = open(os.path.join(out_dir, "entities.jsonl"), "w", encoding="utf-8")
    writer = csv.DictWriter(f_csv, fieldnames=fields)
    writer.writeheader()

    summary = defaultdict(lambda: {"count": 0, "chapters": set(), "novels": set(), "scores": [], "first": None})
    lab_count, n_chars, t0 = Counter(), 0, time.time()
    try:
        for i, (path, rel, novel, chapter) in enumerate(files, 1):
            with open(path, encoding="utf-8-sig", errors="replace") as f:
                raw = f.read()
            chunks = chunk_text(raw, chunk_chars)
            res = engine.extract_many([c for _, c in chunks], min_score=min_score, use_dict=use_dict,
                                      with_context=True)
            text = "".join(r["text"] for r in res)   # văn bản đã chuẩn hoá NFC, cùng hệ toạ độ với start/end
            ents, base = [], 0
            for r in res:
                for e in r["entities"]:
                    e = dict(e, start=e["start"] + base, end=e["end"] + base)
                    ents.append(e)
                base += len(r["text"])
            n_chars += len(text)
            for e in ents:
                row = {"file": rel, "novel": novel, "chapter": chapter, **e}
                writer.writerow({k: row.get(k) for k in fields})
                f_jsonl.write(json.dumps(row, ensure_ascii=False) + "\n")
                key = (e["label"], e["text"])
                s = summary[key]
                s["count"] += 1
                s["chapters"].add((novel, chapter))
                s["novels"].add(novel)
                if e["score"] is not None:
                    s["scores"].append(e["score"])
                if s["first"] is None:
                    s["first"] = rel
                lab_count[e["label"]] += 1
            if html:
                hp = os.path.join(out_dir, "html", re.sub(r"[\\/]", "__", os.path.splitext(rel)[0]) + ".html")
                with open(hp, "w", encoding="utf-8") as f:
                    f.write(to_html(rel, text, ents))
            el = time.time() - t0
            print(f"\r[{i}/{len(files)}] {rel[:50]:<50} | {len(ents):>5} thực thể | {n_chars / max(el, 1e-9):,.0f} ký tự/giây",
                  end="", flush=True)
    finally:
        f_csv.close()
        f_jsonl.close()
    print()

    with open(os.path.join(out_dir, "tong_hop.csv"), "w", encoding="utf-8-sig", newline="") as f:
        w = csv.writer(f)
        w.writerow(["label", "name", "count", "n_chapters", "n_novels", "avg_score", "first_file"])
        for (lab, name), s in sorted(summary.items(), key=lambda kv: (kv[0][0], -kv[1]["count"])):
            avg = round(sum(s["scores"]) / len(s["scores"]), 4) if s["scores"] else ""
            w.writerow([lab, name, s["count"], len(s["chapters"]), len(s["novels"]), avg, s["first"]])

    el = time.time() - t0
    by_label = defaultdict(list)
    for (lab, name), s in summary.items():
        by_label[lab].append((s["count"], name))
    lines = [f"Mô hình: {engine.model_dir} | thiết bị: {getattr(engine, 'device', '?')} | "
             f"từ điển: {len(engine.gazetteer)} tên",
             f"Số file: {len(files)} | số ký tự: {n_chars:,} | thời gian: {el:,.1f} giây "
             f"({n_chars / max(el, 1e-9):,.0f} ký tự/giây)",
             f"Ngưỡng điểm tin cậy: {min_score}", "",
             "Số lần xuất hiện / số tên khác nhau theo nhãn:",
             *[f"  {lab:<12} {c:>8} / {len(by_label[lab])}" for lab, c in lab_count.most_common()]]
    for lab in sorted(by_label):
        top = sorted(by_label[lab], reverse=True)[:10]
        lines += ["", f"Top {lab}:", *[f"  {n:<32} {c}" for c, n in top]]
    if engine.warnings:
        lines += ["", "Cảnh báo:", *[f"  ⚠️ {w}" for w in engine.warnings]]
    report = "\n".join(lines)
    with open(os.path.join(out_dir, "report.txt"), "w", encoding="utf-8") as f:
        f.write(report + "\n")
    print(report)
    print(f"\n✅ Kết quả: {out_dir}")


def main():
    for s in (sys.stdout, sys.stderr):
        try:
            s.reconfigure(encoding="utf-8", errors="replace")
        except Exception:
            pass
    ap = argparse.ArgumentParser(description="Trích xuất thực thể từ file truyện bằng mô hình NER")
    ap.add_argument("--model", required=True, help="Thư mục mô hình (vd. ner-final)")
    g = ap.add_mutually_exclusive_group(required=True)
    g.add_argument("--input", nargs="+", help="File .txt hoặc thư mục")
    g.add_argument("--text", help="Thử nhanh với một đoạn văn bản")
    ap.add_argument("--out", default="ket_qua")
    ap.add_argument("--dict", help="Từ điển tên .json/.csv (bổ sung tên mô hình bỏ sót)")
    ap.add_argument("--min-score", type=float, default=0.0, help="Bỏ thực thể có điểm tin cậy thấp hơn (0-1)")
    ap.add_argument("--html", action="store_true", help="Xuất thêm HTML tô màu thực thể")
    ap.add_argument("--device", help="cuda / cpu (mặc định: tự chọn)")
    ap.add_argument("--batch-size", type=int, default=32)
    ap.add_argument("--max-len", type=int, default=256, help="Nên bằng MAX_LEN lúc huấn luyện")
    ap.add_argument("--threads", type=int, help="Số luồng CPU cho PyTorch")
    a = ap.parse_args()

    print("Đang nạp mô hình...", flush=True)
    eng = NerEngine(a.model, dict_path=a.dict, device=a.device, batch_size=a.batch_size,
                    max_len=a.max_len, num_threads=a.threads)
    print("Nhãn:", ", ".join(eng.labels), "| thiết bị:", eng.device)
    if a.text:
        r = eng.extract(a.text, min_score=a.min_score)
        for e in r["entities"]:
            sc = f'{e["score"]:.3f}' if e["score"] is not None else "dict"
            print(f'  [{e["label"]:<10}] {e["text"]:<32} ({e["start"]}-{e["end"]}, {sc})')
        if not r["entities"]:
            print("  (không tìm thấy thực thể)")
    else:
        process(eng, a.input, a.out, a.min_score, True, a.html)


if __name__ == "__main__":
    main()
