#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Gộp tên đồng nhất (entity linking) cho kết quả NER truyện tiên hiệp.

Mục tiêu: các cách gọi khác nhau của CÙNG MỘT thực thể -> cùng một mã thực thể.

  "Nạp Lan Yên Nhiên", "Yên Nhiên"          cách gọi tắt = phần cuối của họ tên      (tự động)
  "Dược Lão", "Dược lão"                     khác hoa / thường                         (tự động)
  "Thanh Liên Địa Tâm Hỏa", "... Hoả"        khác kiểu đặt dấu thanh (hỏa / hoả)       (tự động)
  "Ô Thản Thành", "Ô Thản"                   có / không có chữ chỉ loại ở cuối         (tự động)
  "Tiêu gia", "Tiêu tộc"                     gia / tộc                                 (tự động)
  "Viêm" khi có cả "Tiêu Viêm" và            tên ngắn mơ hồ -> xác định theo NGỮ CẢNH  (tự động,
     "Âu Dương Viêm"                         (thực thể được nhắc gần nhất trong chương)  nên duyệt)
  "Dược Lão" = "Dược Trần"                   KHÔNG tự đoán được -> khai báo trong file bí danh
  "Tiêu Viêm" vs "Tieu Viem", "Địa" vs "Đại" chỉ GỢI Ý (có thể sai dấu / lỗi chính tả) -> người duyệt

Không xử lý: đại từ (hắn, nàng, lão…) và danh hiệu không được gán nhãn (Viêm Đế…) — đó là bài toán
đồng tham chiếu (coreference), cần mô hình và dữ liệu riêng.

Lệnh
  gop      : gộp tên trong entities.jsonl / entities.csv (đầu ra của xu_ly_file.py)
  ap-dung  : đọc can_duyet.csv đã điền cột quyet_dinh (y = gộp, n = không gộp) -> cập nhật file bí danh

Quy trình
  python gop_ten.py gop     --input ket_qua/entities.jsonl --out lien_ket/
  #  mở lien_ket/can_duyet.csv bằng Excel, điền cột quyet_dinh ở những dòng cần sửa, lưu lại (CSV UTF-8)
  python gop_ten.py ap-dung --review lien_ket/can_duyet.csv --alias bi_danh.json
  python gop_ten.py gop     --input ket_qua/entities.jsonl --alias bi_danh.json --out lien_ket/

Chỉ dùng thư viện chuẩn của Python (3.8+).
"""
import argparse
import bisect
import csv
import json
import os
import re
import shutil
import sys
import unicodedata
from collections import Counter, defaultdict

TOKEN_RE = re.compile(r"\w+(?:[.,/:\-]\w+)*|[^\w\s]", re.UNICODE)
TONE_MARKS = frozenset("\u0300\u0301\u0303\u0309\u0323")  # huyền, sắc, ngã, hỏi, nặng

LABEL_ALIASES = {
    "nhân vật": "NHAN_VAT", "địa danh": "DIA_DANH", "vũ khí": "VU_KHI", "công pháp": "CONG_PHAP",
    "dị hỏa": "DI_HOA", "dị hoả": "DI_HOA", "thế lực": "THE_LUC", "tông môn": "THE_LUC",
}
ID_PREFIX = {"NHAN_VAT": "NV", "DIA_DANH": "DD", "VU_KHI": "VK", "CONG_PHAP": "CP", "DI_HOA": "DH", "THE_LUC": "TL"}
YES = {"y", "yes", "c", "co", "có", "x", "1", "ok", "gop", "gộp", "dong y", "đồng ý"}
NO = {"n", "no", "k", "khong", "không", "0", "khong gop", "không gộp"}


# ============================================================================ chuẩn hoá
def nfc(s):
    return unicodedata.normalize("NFC", s or "")


def syl_key(w):
    """Khoá 1 âm tiết: không phân biệt hoa/thường và VỊ TRÍ dấu thanh (hỏa = hoả, thủy = thuỷ)."""
    d = unicodedata.normalize("NFD", w.lower())
    tones = [c for c in d if c in TONE_MARKS]
    base = unicodedata.normalize("NFC", "".join(c for c in d if c not in TONE_MARKS))
    return base + ("|" + tones[0] if tones else "")


def ascii_of(k):
    """Khoá âm tiết -> chữ không dấu (dùng để GỢI Ý sai dấu / lỗi chính tả)."""
    base = k.split("|")[0]
    d = unicodedata.normalize("NFD", base)
    return "".join(c for c in d if not unicodedata.combining(c)).replace("đ", "d")


def _keys(*phrases):
    return sorted({tuple(syl_key(w) for w in p.split()) for p in phrases}, key=len, reverse=True)


# Xưng hô / chức danh VIẾT THƯỜNG đi kèm tên người (quy tắc R2 của tài liệu gán nhãn)
HON_SUFFIX = _keys("ca ca", "muội muội", "tỷ tỷ", "tỉ tỉ", "đệ đệ", "tiền bối", "đại nhân", "lão sư", "sư phụ",
                   "sư tôn", "tiểu thư", "thiếu gia", "công tử", "cô nương", "đại ca", "huynh", "tỷ", "muội",
                   "đệ", "nhi")
TITLE_PREFIX = _keys("tông chủ", "trưởng lão", "gia chủ", "thành chủ", "sư huynh", "sư tỷ", "sư đệ", "sư muội",
                     "sư phụ", "lão", "tiểu")
LEAD_TYPE = {k[0] for k in _keys("thành", "núi", "đỉnh", "trấn", "làng", "thôn", "hồ", "sông", "biển", "rừng",
                                 "đảo", "tông", "môn", "phái")}
# Chữ chỉ loại ở CUỐI tên (là một phần của tên, nhưng có thể bị lược bỏ khi nhắc lại)
HEADS = {
    "DIA_DANH": _keys("sơn mạch", "đế quốc", "vương quốc", "đại lục", "sa mạc", "sơn", "thành", "cốc", "trấn",
                      "hồ", "đảo", "hải", "giang", "châu", "vực", "quận", "thôn", "lĩnh", "uyên"),
    "THE_LUC": _keys("gia tộc", "học viện", "thương hội", "liên minh", "tông", "môn", "điện", "các", "cung",
                     "tháp", "bang", "hội", "phái", "giáo", "viện", "lâu", "gia", "tộc"),
}
HEAD_CLASS = {k: "gia" for k in _keys("gia", "tộc", "gia tộc")}  # Tiêu gia = Tiêu tộc = Tiêu gia tộc


def norm_label(label):
    lab = nfc(label).strip()
    lab = LABEL_ALIASES.get(lab.lower(), lab)
    return lab.upper().replace(" ", "_")


def _strip_affixes(keys, low):
    changed = True
    while changed and len(keys) > 1:
        changed = False
        for a in HON_SUFFIX:
            n = len(a)
            if len(keys) > n and tuple(keys[-n:]) == a and all(low[-n:]):
                keys, low, changed = keys[:-n], low[:-n], True
                break
        if changed:
            continue
        for a in TITLE_PREFIX:
            n = len(a)
            if len(keys) > n and tuple(keys[:n]) == a and all(low[:n]):
                keys, low, changed = keys[n:], low[n:], True
                break
    return keys, low


def analyze(surface, label):
    """Tên -> {'key': khoá so sánh, 'core': phần tên chính, 'head': loại chữ chỉ loại, 'full': khoá đầy đủ}."""
    toks = [t for t in TOKEN_RE.findall(nfc(surface)) if t[:1].isalnum()]
    if not toks:
        return None
    keys = [syl_key(t) for t in toks]
    low = [t[:1].islower() for t in toks]
    full = tuple(keys)
    if label == "NHAN_VAT":
        keys, low = _strip_affixes(keys, low)
        return {"key": tuple(keys), "core": None, "head": None, "full": full}
    if label in HEADS:
        while len(keys) > 1 and low[0] and keys[0] in LEAD_TYPE:
            keys, low = keys[1:], low[1:]
        head = next((h for h in HEADS[label] if len(keys) > len(h) and tuple(keys[-len(h):]) == h), None)
        if head:
            core = tuple(keys[:-len(head)])
            hc = HEAD_CLASS.get(head, "_".join(head))
            return {"key": core + ("#" + hc,), "core": core, "head": hc, "full": full}
        return {"key": tuple(keys), "core": tuple(keys), "head": None, "full": full}
    return {"key": tuple(keys), "core": None, "head": None, "full": full}


def _nsyl(k):
    return sum(1 for t in k if not t.startswith("#"))


def _clean_surface(s, lab):
    """Cách viết chuẩn (mọi âm tiết viết hoa, trừ 'gia/tộc' của thế lực) được ưu tiên làm tên chuẩn,
    để tên chuẩn không bao giờ là 'Tiêu Viêm ca ca' hay 'Dược lão'."""
    ok = {"gia", "tộc"} if lab == "THE_LUC" else set()
    toks = [t for t in TOKEN_RE.findall(nfc(s)) if t[:1].isalnum()]
    return all(not t[:1].islower() or t.lower() in ok for t in toks)


def _lev1(a, b):
    if a == b:
        return True
    if abs(len(a) - len(b)) > 1:
        return False
    if len(a) == len(b):
        return sum(x != y for x, y in zip(a, b)) <= 1
    if len(a) > len(b):
        a, b = b, a
    return any(a == b[:i] + b[i + 1:] for i in range(len(b)))


def _similar_syl(a, b):
    x, y = ascii_of(a), ascii_of(b)
    return x == y or sorted(x) == sorted(y) or _lev1(x, y)


def _natkey(s):
    return [int(t) if t.isdigit() else t for t in re.split(r"(\d+)", str(s))]


class _DSU:
    def __init__(self):
        self.p = {}

    def find(self, x):
        self.p.setdefault(x, x)
        root = x
        while self.p[root] != root:
            root = self.p[root]
        while self.p[x] != root:
            self.p[x], x = root, self.p[x]
        return root

    def union(self, keep, other):
        ra, rb = self.find(keep), self.find(other)
        if ra != rb:
            self.p[rb] = ra
        return ra


# ============================================================================ bí danh
def empty_alias():
    return {"aliases": defaultdict(list), "blocked": defaultdict(list)}


def load_alias(path):
    with open(path, encoding="utf-8-sig") as f:
        raw = json.load(f)
    out = empty_alias()
    for nv, labs in (raw.get("bi_danh") or {}).items():
        if nv.startswith("_") or not isinstance(labs, dict):
            continue
        for lab, mp in labs.items():
            if lab.startswith("_") or not isinstance(mp, dict):
                continue
            L = norm_label(lab)
            for canon, lst in mp.items():
                if canon.startswith("_"):
                    continue
                out["aliases"][(nv, L)].append((canon, canon))
                for x in lst or []:
                    out["aliases"][(nv, L)].append((canon, x))
    for x in raw.get("khong_gop") or []:
        if isinstance(x, dict) and x.get("a") and x.get("b"):
            out["blocked"][(x.get("novel", "*"), norm_label(x.get("label", "")))].append((x["a"], x["b"]))
    return out


def _scoped(table, nv, lab, scope):
    if scope == "global":
        return [p for (n, l), lst in table.items() if l == lab for p in lst]
    return table.get((nv, lab), []) + (table.get(("*", lab), []) if nv != "*" else [])


# ============================================================================ gộp 1 nhóm
def _file(m):
    return m.get("file") or m.get("novel") or "?"


def _ctx(m, n=180):
    s = (m.get("context") or m.get("text") or "").replace("\n", " ").strip()
    return s if len(s) <= n else s[:n] + "…"


def _nearest(by_root, roots, st, window):
    best, bd = None, None
    for r in roots:
        lst = by_root.get(r)
        if lst:
            j = bisect.bisect_right(lst, st) - 1
            if j >= 0 and st - lst[j] <= window and (bd is None or st - lst[j] < bd):
                best, bd = r, st - lst[j]
    if best is not None:
        return best
    for r in roots:
        lst = by_root.get(r)
        if lst:
            j = bisect.bisect_left(lst, st)
            if j < len(lst) and lst[j] - st <= window and (bd is None or lst[j] - st < bd):
                best, bd = r, lst[j] - st
    return best


def _link_group(nv, lab, idxs, mentions, infos, alias, scope, window):
    forms = {}
    for i in idxs:
        k = infos[i]["key"]
        f = forms.setdefault(k, {"core": infos[i]["core"], "head": infos[i]["head"], "surf": Counter(), "idx": []})
        f["surf"][mentions[i]["text"]] += 1
        f["idx"].append(i)

    dsu = _DSU()
    for k in forms:
        dsu.find(k)
    method, pref, fixed, events = {}, {}, set(), []

    # A. File bí danh (người khai báo) — luôn được ưu tiên
    for canon, al in _scoped(alias["aliases"], nv, lab, scope):
        ca, aa = analyze(canon, lab), analyze(al, lab)
        if not ca or not aa:
            continue
        pref[ca["key"]] = nfc(canon).strip()
        fixed.add(ca["key"])
        if aa["key"] != ca["key"]:
            dsu.union(ca["key"], aa["key"])
            method[aa["key"]] = "bi_danh"
            fixed.add(aa["key"])

    blocked = defaultdict(set)
    for a_, b_ in _scoped(alias["blocked"], nv, lab, scope):
        x, y = analyze(a_, lab), analyze(b_, lab)
        if x and y:
            blocked[x["key"]].add(y["key"])
            blocked[y["key"]].add(x["key"])

    def allowed(k, root):
        return not any(dsu.find(b) == root for b in blocked.get(k, ()))

    ambiguous = {}

    # B. Địa danh / thế lực: "Ô Thản" = "Ô Thản Thành" (bỏ chữ chỉ loại ở cuối)
    if lab in HEADS:
        headed = defaultdict(list)
        for k, f in forms.items():
            if f["head"]:
                headed[f["core"]].append(k)
        for k, f in forms.items():
            if f["head"] or k in fixed or not headed.get(f["core"]):
                continue
            roots = {dsu.find(c) for c in headed[f["core"]]}
            roots = {r for r in roots if allowed(k, r)}
            if not roots or dsu.find(k) in roots:
                continue
            if len(roots) == 1:
                dsu.union(next(iter(roots)), k)
                method[k] = "bo_chu_chi_loai"
                events.append(("bo_chu_chi_loai", k))
            else:
                ambiguous[k] = headed[f["core"]]

    # C. Nhân vật: tên gọi tắt = phần cuối của họ tên ("Yên Nhiên" ⊂ "Nạp Lan Yên Nhiên")
    if lab == "NHAN_VAT":
        suf = defaultdict(set)
        for k in forms:
            for j in range(1, len(k)):
                suf[k[-j:]].add(k)
        for k in sorted(forms, key=lambda x: (-len(x), x)):
            if k in fixed or not suf.get(k):
                continue
            roots = {dsu.find(c) for c in suf[k]}
            roots = {r for r in roots if allowed(k, r)}
            if not roots or dsu.find(k) in roots:
                continue
            if len(roots) == 1:
                dsu.union(next(iter(roots)), k)
                method[k] = "hau_to"
                events.append(("hau_to", k))
            else:
                ambiguous[k] = list(suf[k])

    # Kiểm tra lại các tên mơ hồ sau khi đã gộp xong
    # (ứng viên cũng là tên mơ hồ thì không tính: "Nhiên" không thể trỏ vào "Yên Nhiên" đang mơ hồ)
    amb = dict(ambiguous)
    changed = True
    while changed:
        changed = False
        for k in list(amb):
            roots = {dsu.find(c) for c in amb[k] if c not in amb}
            roots = {r for r in roots if allowed(k, r)}
            if dsu.find(k) in roots or not roots:
                del amb[k]          # đã thuộc một cụm, hoặc không còn ứng viên -> là thực thể riêng
                changed = True
            elif len(roots) == 1:
                dsu.union(next(iter(roots)), k)
                method[k] = "hau_to" if lab == "NHAN_VAT" else "bo_chu_chi_loai"
                events.append((method[k], k))
                del amb[k]
                changed = True
    amb = {k: {r for r in {dsu.find(c) for c in cands if c not in amb} if allowed(k, r)}
           for k, cands in amb.items()}

    # D. Gợi ý (KHÔNG tự gộp): giống nhau khi bỏ dấu / khác đúng 1 âm tiết gần giống
    sugg = {}
    buck = defaultdict(list)
    for k in forms:
        if _nsyl(k) >= 2 and k not in amb:
            buck[tuple(ascii_of(t) for t in k)].append(k)
    for ks in buck.values():
        if len(ks) < 2:
            continue
        ks.sort(key=lambda x: -len(forms[x]["idx"]))
        for a_ in ks[1:]:
            if dsu.find(a_) != dsu.find(ks[0]) and allowed(a_, dsu.find(ks[0])):
                sugg[(a_, ks[0])] = "sai_dau"
    mb = defaultdict(list)
    for k in forms:
        if _nsyl(k) >= 3 and k not in amb:
            for p in range(len(k)):
                # nhân vật: bỏ qua âm tiết đầu (họ) — khác họ thường là 2 người khác nhau thật
                if not k[p].startswith("#") and not (lab == "NHAN_VAT" and p == 0):
                    mb[(len(k), p, k[:p] + k[p + 1:])].append(k)
    for (_, p, _), ks in mb.items():
        if not 2 <= len(ks) <= 30:
            continue
        for x in range(len(ks)):
            for y in range(x + 1, len(ks)):
                a_, b_ = ks[x], ks[y]
                if dsu.find(a_) == dsu.find(b_) or not _similar_syl(a_[p], b_[p]):
                    continue
                small, big = sorted((a_, b_), key=lambda z: (len(forms[z]["idx"]), z))
                if (small, big) not in sugg and allowed(small, dsu.find(big)):
                    sugg[(small, big)] = "chinh_ta"

    # E. Tên chuẩn của mỗi cụm
    clusters = defaultdict(list)
    for k in forms:
        if k not in amb:
            clusters[dsu.find(k)].append(k)
    canon = {}
    for r, ks in clusters.items():
        pin = [(k2, s) for k2, s in pref.items() if dsu.find(k2) == r]
        if pin:
            canon[r] = max(pin, key=lambda x: len(forms[x[0]]["idx"]) if x[0] in forms else 0)[1]
        else:
            best = max(ks, key=lambda k: (len(k), len(forms[k]["idx"]), k))
            canon[r] = max(forms[best]["surf"].items(), key=lambda kv: (_clean_surface(kv[0], lab), kv[1]))[0]

    # F. Gán từng lần xuất hiện; tên mơ hồ -> thực thể được nhắc gần nhất trong cùng file
    pos = defaultdict(lambda: defaultdict(list))
    for k, f in forms.items():
        if k not in amb:
            r = dsu.find(k)
            for i in f["idx"]:
                pos[_file(mentions[i])][r].append(int(mentions[i].get("start") or 0))
    for d in pos.values():
        for lst in d.values():
            lst.sort()
    assign, ctx_stats = {}, defaultdict(Counter)
    for k, f in forms.items():
        if k in amb:
            for i in f["idx"]:
                m = mentions[i]
                r = _nearest(pos.get(_file(m), {}), amb[k], int(m.get("start") or 0), window)
                assign[i] = (r, "ngu_canh" if r is not None else "chua_xac_dinh")
                ctx_stats[k][r] += 1
        else:
            r = dsu.find(k)
            for i in f["idx"]:
                s = nfc(mentions[i]["text"]).strip()
                assign[i] = (r, method.get(k) or ("ten_chuan" if s == canon[r] else "bien_the"))

    # G. Mã thực thể
    per_root = defaultdict(list)
    for i, (r, _) in assign.items():
        if r is not None:
            per_root[r].append(i)
    order = sorted(per_root, key=lambda r: (-len(per_root[r]), canon[r]))
    gid = "ALL" if nv == "*" else nv
    eid = {r: f"{gid}:{ID_PREFIX.get(lab, lab[:2])}{n:04d}" for n, r in enumerate(order, 1)}
    entities = []
    for r in order:
        ii = per_root[r]
        surf = Counter(nfc(mentions[i]["text"]).strip() for i in ii)
        files = sorted({_file(mentions[i]) for i in ii}, key=_natkey)
        entities.append({
            "entity_id": eid[r], "novel": nv, "label": lab, "ten_chuan": canon[r], "so_lan": len(ii),
            "so_bien_the": len(surf), "cac_bien_the": " | ".join(f"{s} ×{c}" for s, c in surf.most_common()),
            "so_file": len(files), "file_dau": files[0], "file_cuoi": files[-1],
        })
    out = {i: ((eid[r], canon[r]) if r is not None else ("", ""), mth) for i, (r, mth) in assign.items()}

    # H. Danh sách cần duyệt
    def top(k):
        return forms[k]["surf"].most_common(1)[0][0]

    def row(prio, loai, trang_thai, k, r, ly_do, vi_du):
        return {"uu_tien": prio, "loai": loai, "trang_thai": trang_thai, "novel": nv, "label": lab,
                "ten_a": top(k), "so_lan_a": len(forms[k]["idx"]), "ten_b": canon[r],
                "so_lan_b": len(per_root.get(r, [])), "ly_do": ly_do, "vi_du": vi_du, "quyet_dinh": ""}

    review = []
    for loai, k in events:
        r = dsu.find(k)
        if loai == "hau_to":
            one = _nsyl(k) == 1
            review.append(row(1 if one else 3, "hau_to", "đã gộp tự động", k, r,
                              f"“{top(k)}” là phần cuối của “{canon[r]}” (cách gọi tắt"
                              + (", chỉ 1 âm tiết: dễ nhầm)" if one else ")"), _ctx(mentions[forms[k]["idx"][0]])))
        else:
            review.append(row(2, "bo_chu_chi_loai", "đã gộp tự động", k, r,
                              f"“{top(k)}” = “{canon[r]}” bỏ chữ chỉ loại ở cuối", _ctx(mentions[forms[k]["idx"][0]])))
    for k, roots in amb.items():
        st = ctx_stats[k]
        for r in sorted(roots, key=lambda x: -st[x]):
            ex = next((mentions[i] for i in forms[k]["idx"] if assign[i][0] == r), mentions[forms[k]["idx"][0]])
            review.append(row(1, "mo_ho", "chưa gộp: xác định theo ngữ cảnh từng lần", k, r,
                              f"Tên ngắn khớp {len(roots)} thực thể. Theo ngữ cảnh: {st[r]} lần → thực thể này; "
                              f"chưa xác định: {st[None]} lần. Chọn y nếu tên này LUÔN chỉ thực thể này",
                              _ctx(ex)))
    for (a_, b_), loai in sugg.items():
        r = dsu.find(b_)
        why = ("Giống nhau khi bỏ dấu: có thể gõ thiếu / sai dấu" if loai == "sai_dau"
               else "Khác đúng 1 âm tiết gần giống nhau: có thể lỗi chính tả / cách dịch khác")
        review.append(row(2, loai, "chưa gộp: gợi ý", a_, r, why, _ctx(mentions[forms[a_]["idx"][0]])))

    dict_forms = [(top(k), len(forms[k]["idx"])) for k in forms if k not in amb and _nsyl(k) >= 2]
    return out, entities, review, dict_forms


# ============================================================================ API chính
def link(mentions, alias=None, scope="novel", window=3000):
    """
    mentions: list dict có ít nhất 'text', 'label'; nên có 'novel', 'file', 'start' (để xét ngữ cảnh), 'context'.
    Trả về dict: mentions (kèm entity_id, ten_chuan, cach_lien_ket), entities, review, conflicts, dict_forms.
    """
    alias = alias or empty_alias()
    infos, groups = [], defaultdict(list)
    conf = defaultdict(lambda: defaultdict(list))
    for i, m in enumerate(mentions):
        m["text"] = nfc(m.get("text")).strip()
        m["label"] = norm_label(m.get("label", ""))
        nv = "*" if scope == "global" else (m.get("novel") or "khong_ro")
        an = analyze(m["text"], m["label"]) if m["text"] and m["label"] else None
        infos.append(an)
        if an:
            groups[(nv, m["label"])].append(i)
            conf[(nv, an["full"])][m["label"]].append(i)

    out_m = [dict(m, entity_id="", ten_chuan="", cach_lien_ket="bo_qua") for m in mentions]
    entities, review, dict_forms = [], [], defaultdict(Counter)
    for (nv, lab), idxs in sorted(groups.items()):
        res, ents, rev, dforms = _link_group(nv, lab, idxs, mentions, infos, alias, scope, window)
        for i, ((e, c), mth) in res.items():
            out_m[i].update(entity_id=e, ten_chuan=c, cach_lien_ket=mth)
        entities += ents
        review += rev
        for s, c in dforms:
            dict_forms[lab][s] += c
    order = {"mo_ho": 0, "hau_to": 1, "sai_dau": 2, "chinh_ta": 3, "bo_chu_chi_loai": 4}
    review.sort(key=lambda r: (r["uu_tien"], order.get(r["loai"], 9), -r["so_lan_a"], r["novel"], r["ten_a"]))
    for n, r in enumerate(review, 1):
        r["stt"] = n

    conflicts = []
    for (nv, _), by_lab in conf.items():
        if len(by_lab) < 2:
            continue
        cnt = {l: len(v) for l, v in by_lab.items()}
        major = max(cnt, key=lambda l: (cnt[l], l))
        total = sum(cnt.values())
        minor_i = next(i for l, v in by_lab.items() if l != major for i in v)
        names = Counter(mentions[i]["text"] for v in by_lab.values() for i in v)
        conflicts.append({"novel": nv, "ten": names.most_common(1)[0][0], "tong": total,
                          "theo_nhan": "; ".join(f"{l}: {c}" for l, c in sorted(cnt.items(), key=lambda x: -x[1])),
                          "nhan_chiem_da_so": major, "ti_le": round(cnt[major] / total, 3),
                          "vi_du_nhan_khac": f"[{mentions[minor_i]['label']}] {_ctx(mentions[minor_i])}"})
    conflicts.sort(key=lambda r: (r["ti_le"], -r["tong"]))
    return {"mentions": out_m, "entities": entities, "review": review, "conflicts": conflicts,
            "dict_forms": dict_forms}


# ============================================================================ đọc / ghi
def _csv_rows(path):
    """Đọc CSV, tự nhận dấu phân cách , ; hoặc tab
    (Excel với cài đặt vùng Việt Nam thường lưu CSV bằng dấu ;)."""
    with open(path, encoding="utf-8-sig", newline="") as f:
        head = f.readline()
        f.seek(0)
        delim = max([",", ";", "\t"], key=head.count)
        return list(csv.DictReader(f, delimiter=delim))


def read_mentions(paths):
    out = []
    for p in paths:
        if p.lower().endswith(".csv"):
            rows = _csv_rows(p)
        else:
            with open(p, encoding="utf-8-sig") as f:
                rows = [json.loads(l) for l in f if l.strip()]
        for r in rows:
            if not r.get("text") or not r.get("label"):
                continue
            for k in ("start", "end"):
                try:
                    r[k] = int(r[k]) if r.get(k) not in (None, "") else None
                except (TypeError, ValueError):
                    r[k] = None
            out.append(r)
    return out


def _write_csv(path, rows, fields):
    with open(path, "w", encoding="utf-8-sig", newline="") as f:
        w = csv.DictWriter(f, fieldnames=fields, extrasaction="ignore")
        w.writeheader()
        w.writerows(rows)


def cmd_gop(a):
    mentions = read_mentions(a.input)
    if not mentions:
        sys.exit("❌ Không đọc được lần xuất hiện nào. --input phải là entities.jsonl / entities.csv của xu_ly_file.py")
    alias = load_alias(a.alias) if a.alias and os.path.exists(a.alias) else empty_alias()
    if a.alias and not os.path.exists(a.alias):
        print(f"⚠️ Chưa có file bí danh {a.alias} — chạy không dùng bí danh.")
    res = link(mentions, alias, a.scope, a.window)
    os.makedirs(a.out, exist_ok=True)

    ms = res["mentions"]
    mfields = ["file", "novel", "chapter", "start", "end", "label", "text", "entity_id", "ten_chuan",
               "cach_lien_ket", "score", "source", "context"]
    _write_csv(os.path.join(a.out, "lan_xuat_hien.csv"), ms, mfields)
    with open(os.path.join(a.out, "lan_xuat_hien.jsonl"), "w", encoding="utf-8") as f:
        for m in ms:
            f.write(json.dumps(m, ensure_ascii=False) + "\n")
    _write_csv(os.path.join(a.out, "thuc_the.csv"), res["entities"],
               ["entity_id", "novel", "label", "ten_chuan", "so_lan", "so_bien_the", "cac_bien_the",
                "so_file", "file_dau", "file_cuoi"])
    _write_csv(os.path.join(a.out, "can_duyet.csv"), res["review"],
               ["stt", "uu_tien", "loai", "trang_thai", "novel", "label", "ten_a", "so_lan_a", "ten_b",
                "so_lan_b", "ly_do", "vi_du", "quyet_dinh"])
    _write_csv(os.path.join(a.out, "xung_dot_nhan.csv"), res["conflicts"],
               ["novel", "ten", "tong", "theo_nhan", "nhan_chiem_da_so", "ti_le", "vi_du_nhan_khac"])
    tu_dien = {lab: sorted(s for s, c in cnt.items() if c >= a.min_dict_count)
               for lab, cnt in sorted(res["dict_forms"].items())}
    with open(os.path.join(a.out, "tu_dien_mo_rong.json"), "w", encoding="utf-8") as f:
        json.dump({k: v for k, v in tu_dien.items() if v}, f, ensure_ascii=False, indent=2)

    meth = Counter(m["cach_lien_ket"] for m in ms)
    surf = defaultdict(set)
    ent = Counter()
    for m in ms:
        if m["cach_lien_ket"] != "bo_qua":
            surf[(m.get("novel") if a.scope == "novel" else "*", m["label"])].add(nfc(m["text"]).lower())
    for e in res["entities"]:
        ent[e["label"]] += 1
    n_surf = Counter()
    for (_, lab), s in surf.items():
        n_surf[lab] += len(s)
    lab_m = Counter(m["label"] for m in ms if m["cach_lien_ket"] != "bo_qua")
    pr = Counter(r["uu_tien"] for r in res["review"])
    lo = Counter(r["loai"] for r in res["review"])
    tot_s, tot_e = sum(n_surf.values()), sum(ent.values())
    lines = [
        f"Số lần xuất hiện: {len(ms):,} | số cách viết khác nhau: {tot_s:,} | số thực thể sau khi gộp: {tot_e:,}"
        + (f" (giảm {1 - tot_e / tot_s:.0%})" if tot_s else ""),
        f"Phạm vi gộp: {'từng bộ truyện' if a.scope == 'novel' else 'toàn bộ dữ liệu'} | cửa sổ ngữ cảnh: "
        f"{a.window:,} ký tự | file bí danh: {a.alias or '(không dùng)'}",
        "",
        "Cách liên kết từng lần xuất hiện:",
        *[f"  {k:<16} {v:>8,}  {DESC.get(k, '')}" for k, v in meth.most_common()],
        "",
        f"  {'nhãn':<12} {'lần xuất hiện':>14} {'cách viết':>10} {'thực thể':>9}",
        *[f"  {l:<12} {lab_m[l]:>14,} {n_surf[l]:>10,} {ent[l]:>9,}" for l in sorted(lab_m)],
        "",
        f"Cần duyệt (can_duyet.csv): {len(res['review'])} dòng — ưu tiên 1: {pr[1]}, 2: {pr[2]}, 3: {pr[3]}",
        "  " + ", ".join(f"{k}: {v}" for k, v in lo.most_common()),
        f"Xung đột nhãn (xung_dot_nhan.csv): {len(res['conflicts'])} tên được gán nhiều nhãn khác nhau",
        f"Từ điển mở rộng (tu_dien_mo_rong.json): "
        + ", ".join(f"{k} {len(v)}" for k, v in tu_dien.items() if v),
    ]
    by_lab = defaultdict(list)
    for e in res["entities"]:
        by_lab[e["label"]].append(e)
    for lab in sorted(by_lab):
        lines += ["", f"Top {lab}:"]
        for e in sorted(by_lab[lab], key=lambda x: -x["so_lan"])[:8]:
            v = e["cac_bien_the"] if e["so_bien_the"] > 1 else ""
            lines.append(f"  {e['ten_chuan']:<28} ×{e['so_lan']:<6} {('[' + v[:90] + ']') if v else ''}")
    report = "\n".join(lines)
    with open(os.path.join(a.out, "report.txt"), "w", encoding="utf-8") as f:
        f.write(report + "\n")
    print(report)
    print(f"\n✅ Kết quả: {a.out}\n👉 Bước tiếp: mở can_duyet.csv, điền cột quyet_dinh (y/n) rồi chạy lệnh ap-dung")


DESC = {
    "ten_chuan": "đúng tên chuẩn",
    "bien_the": "khác hoa/thường, vị trí dấu, gia/tộc",
    "hau_to": "tên gọi tắt (phần cuối họ tên)",
    "bo_chu_chi_loai": "bỏ chữ chỉ loại (Ô Thản = Ô Thản Thành)",
    "bi_danh": "theo file bí danh",
    "ngu_canh": "tên mơ hồ, xác định theo ngữ cảnh",
    "chua_xac_dinh": "tên mơ hồ, không đủ ngữ cảnh",
    "bo_qua": "dòng thiếu tên / nhãn",
}


def _same_pair(x, nv, lab, a, b):
    return x.get("novel") == nv and norm_label(x.get("label", "")) == lab and {nfc(x.get("a")), nfc(x.get("b"))} == {a, b}


def cmd_ap_dung(a):
    raw = {"bi_danh": {}, "khong_gop": []}
    if os.path.exists(a.alias):
        with open(a.alias, encoding="utf-8-sig") as f:
            raw = json.load(f)
        raw.setdefault("bi_danh", {})
        raw.setdefault("khong_gop", [])
    added = blocked = removed = 0
    warns, unknown = [], Counter()
    rows = _csv_rows(a.review)
    if rows and "quyet_dinh" not in rows[0]:
        sys.exit("❌ File không có cột quyet_dinh — có đúng can_duyet.csv không? (khi lưu bằng Excel chọn CSV UTF-8)")
    for r in rows:
        q = nfc(r.get("quyet_dinh")).strip().lower()
        if not q:
            continue
        nv, lab = r.get("novel", "*"), norm_label(r.get("label", ""))
        ta, tb = nfc(r.get("ten_a")).strip(), nfc(r.get("ten_b")).strip()
        if not ta or not tb or ta == tb:
            continue
        labs = raw["bi_danh"].setdefault(nv, {}).setdefault(lab, {})
        if q in YES:
            other = [c for c, lst in labs.items() if c != tb and ta in (lst or [])]
            if other:
                warns.append(f"“{ta}” đã là bí danh của “{other[0]}” ({nv}, {lab}) — bỏ qua “{tb}”. "
                             f"Chọn y cho nhiều thực thể sẽ gộp các thực thể đó làm một.")
                continue
            lst = labs.setdefault(tb, [])
            if ta not in lst:
                lst.append(ta)
                added += 1
            raw["khong_gop"] = [x for x in raw["khong_gop"] if not _same_pair(x, nv, lab, ta, tb)]
        elif q in NO:
            if not any(_same_pair(x, nv, lab, ta, tb) for x in raw["khong_gop"]):
                raw["khong_gop"].append({"novel": nv, "label": lab, "a": ta, "b": tb})
                blocked += 1
            if ta in (labs.get(tb) or []):
                labs[tb].remove(ta)
                removed += 1
        else:
            unknown[q] += 1
    for nv in list(raw["bi_danh"]):
        for lab in list(raw["bi_danh"][nv]):
            if not raw["bi_danh"][nv][lab]:
                del raw["bi_danh"][nv][lab]
        if not raw["bi_danh"][nv]:
            del raw["bi_danh"][nv]
    if os.path.exists(a.alias):
        shutil.copy(a.alias, a.alias + ".bak")
    os.makedirs(os.path.dirname(os.path.abspath(a.alias)), exist_ok=True)
    with open(a.alias, "w", encoding="utf-8") as f:
        json.dump(raw, f, ensure_ascii=False, indent=2)
    print(f"✅ Đã cập nhật {a.alias}: +{added} bí danh, +{blocked} cặp không gộp, gỡ {removed} bí danh cũ"
          + (" (bản cũ: " + a.alias + ".bak)" if os.path.exists(a.alias + ".bak") else ""))
    for w in warns:
        print("⚠️", w)
    if unknown:
        print("⚠️ Giá trị quyet_dinh không hiểu (bị bỏ qua):", dict(unknown), "— dùng y hoặc n")
    print("👉 Chạy lại: python gop_ten.py gop --input ... --alias", a.alias, "--out ...")


def main():
    for s in (sys.stdout, sys.stderr):
        try:
            s.reconfigure(encoding="utf-8", errors="replace")
        except Exception:
            pass
    ap = argparse.ArgumentParser(description="Gộp tên đồng nhất cho kết quả NER truyện tiên hiệp")
    sub = ap.add_subparsers(dest="cmd", required=True)
    g = sub.add_parser("gop", help="Gộp tên trong entities.jsonl / entities.csv")
    g.add_argument("--input", nargs="+", required=True, help="entities.jsonl hoặc entities.csv của xu_ly_file.py")
    g.add_argument("--out", default="lien_ket")
    g.add_argument("--alias", help="File bí danh .json (tạo/cập nhật bằng lệnh ap-dung)")
    g.add_argument("--scope", choices=["novel", "global"], default="novel",
                   help="novel: chỉ gộp trong cùng bộ truyện (mặc định); global: gộp toàn bộ")
    g.add_argument("--window", type=int, default=3000,
                   help="Tên mơ hồ: tìm thực thể được nhắc trong phạm vi N ký tự (mặc định 3000)")
    g.add_argument("--min-dict-count", type=int, default=3, help="Ngưỡng số lần để đưa vào tu_dien_mo_rong.json")
    g.set_defaults(func=cmd_gop)
    p = sub.add_parser("ap-dung", help="Áp dụng quyết định trong can_duyet.csv vào file bí danh")
    p.add_argument("--review", required=True, help="can_duyet.csv đã điền cột quyet_dinh")
    p.add_argument("--alias", required=True, help="File bí danh .json (tạo mới nếu chưa có)")
    p.set_defaults(func=cmd_ap_dung)
    a = ap.parse_args()
    a.func(a)


if __name__ == "__main__":
    main()
