# Triển khai mô hình NER truyện tiên hiệp

Thư mục này dùng để **đưa mô hình đã huấn luyện (`ner-final/`) vào sử dụng**. Có 3 cách:

| Cách | Khi nào dùng | File |
|---|---|---|
| **A. Xử lý hàng loạt file truyện** | Trích danh sách nhân vật, địa danh… của cả bộ truyện; xuất Excel/HTML | `xu_ly_file.py` |
| **B. API nội bộ** | Hệ thống khác cần gọi mô hình qua HTTP | `api.py`, `Dockerfile` |
| **C. Gọi trực tiếp trong Python** | Tích hợp vào code của bạn | `ner_engine.py` |

Cả 3 cách dùng chung `ner_engine.py`. Engine này:
- Tách câu và tách từ **giống hệt lúc huấn luyện**.
- Tự chia câu quá dài thành **các cửa sổ chồng lấn**, nên không cắt đôi thực thể.
- Gom nhiều câu thành batch để chạy nhanh.
- Trả về **vị trí ký tự**, **điểm tin cậy** và **nguồn** (mô hình hay từ điển) của từng thực thể.

```
trien_khai/
├── README.md                ← tài liệu này
├── ner_engine.py            ← lõi suy luận (dùng chung)
├── xu_ly_file.py            ← cách A: xử lý hàng loạt file .txt
├── api.py                   ← cách B: API FastAPI
├── goi_api_mau.py           ← ví dụ gọi API (thư viện chuẩn, không cần cài gì)
├── Dockerfile, .dockerignore
└── requirements-deploy.txt
```

---

## 0. Chuẩn bị

### 0.1 Kiểm tra thư mục mô hình

Sau khi chạy notebook, thư mục `ner-final/` phải có ít nhất các file sau:

```
ner-final/
├── config.json                          ← có id2label gồm 6 nhãn (B-/I-)
├── model.safetensors  (hoặc pytorch_model.bin)
├── tokenizer.json, tokenizer_config.json, special_tokens_map.json
└── labels.json
```

Kích thước khoảng 0,7 GB, do bộ từ vựng 128K làm lớp embedding khá nặng. Nên **ghi lại phiên bản mô hình** (ví dụ đổi tên thành `ner-final-v1-2026-11-12/`) cùng với F1 trên tập test, để sau này biết đang chạy bản nào.

### 0.2 Cài đặt

```bash
# Cài PyTorch theo https://pytorch.org (bản CPU hoặc CUDA phù hợp với máy), rồi:
pip install -r requirements-deploy.txt
```

### 0.3 Thử nhanh

```bash
cd trien_khai
python xu_ly_file.py --model ../ner-final --text "Tiêu Viêm thi triển Phật Nộ Hỏa Liên về phía đệ tử Vân Lam Tông."
```

Kết quả có dạng như sau (điểm thực tế tuỳ mô hình của bạn):

```
Nhãn: CONG_PHAP, DIA_DANH, DI_HOA, NHAN_VAT, THE_LUC, VU_KHI | thiết bị: cuda
  [NHAN_VAT  ] Tiêu Viêm                        (0-9, 0.998)
  [CONG_PHAP ] Phật Nộ Hỏa Liên                 (20-36, 0.991)
  [THE_LUC   ] Vân Lam Tông                     (51-63, 0.995)
```

---

## A. Xử lý hàng loạt file truyện

Thư mục đầu vào tổ chức giống lúc chuẩn bị dữ liệu: mỗi bộ truyện một thư mục con, mỗi chương một file `.txt` UTF-8.

```bash
python xu_ly_file.py --model ../ner-final --input ../truyen/ --out ket_qua/ --html
# Thêm từ điển tên để bổ sung tên mô hình bỏ sót:
python xu_ly_file.py --model ../ner-final --input ../truyen/ --out ket_qua/ --dict ../tu_dien.json --html
```

**Kết quả trong `ket_qua/`:**

| File | Nội dung | Dùng để |
|---|---|---|
| `entities.csv` | Mỗi dòng là **một lần xuất hiện**: file, bộ truyện, chương, vị trí, nhãn, tên, điểm tin cậy, nguồn, câu chứa tên | Mở bằng Excel, lọc, tra cứu |
| `entities.jsonl` | Như trên, dạng JSON | Nạp vào hệ thống khác |
| `tong_hop.csv` | **Danh sách tên duy nhất** theo nhãn: số lần xuất hiện, số chương, số bộ, điểm tin cậy trung bình, file xuất hiện đầu tiên | Lập danh sách nhân vật, địa danh…; bổ sung từ điển |
| `html/*.html` | Văn bản từng chương, **tô màu thực thể**. Rê chuột lên tên để xem nhãn và điểm | Đọc kiểm tra bằng mắt |
| `report.txt` | Số thực thể theo nhãn, top 10 tên mỗi nhãn, tốc độ xử lý | Xem nhanh |

**Tham số hay dùng:**

| Tham số | Mặc định | Ý nghĩa |
|---|---|---|
| `--min-score` | `0` | Bỏ thực thể có điểm tin cậy thấp hơn ngưỡng. Thường dùng `0.5`–`0.7` khi cần độ chính xác cao. Tên lấy từ từ điển không bị lọc |
| `--dict` | — | Từ điển tên, chỉ **bổ sung** vào chỗ mô hình bỏ trống, **không ghi đè** dự đoán |
| `--batch-size` | `32` | GPU 16 GB: 32–64. CPU: 8–16 |
| `--device` | tự chọn | `cuda` hoặc `cpu` |
| `--threads` | mặc định của PyTorch | Số luồng CPU khi chạy trên CPU |
| `--max-len` | `256` | **Nên bằng `MAX_LEN` lúc huấn luyện** |

> 💡 **Dùng kết quả để cải thiện dữ liệu.** Lọc trong `tong_hop.csv` các tên có `avg_score` thấp (ví dụ dưới 0,7): đó thường là các ca mô hình còn phân vân. Kiểm tra các tên này, bổ sung vào từ điển hoặc đưa thêm câu chứa chúng vào vòng gán nhãn tiếp theo.

---

## B. API nội bộ

### B.1 Chạy trực tiếp

```bash
cd trien_khai
export MODEL_DIR=../ner-final          # Windows PowerShell: $env:MODEL_DIR="..\ner-final"
export API_KEY=doi-mat-khau-nay        # nên đặt; bỏ trống = không cần xác thực
uvicorn api:app --host 0.0.0.0 --port 8000 --workers 1
```

Mở **http://localhost:8000/docs** để thử API ngay trên trình duyệt (Swagger).

### B.2 Các endpoint

| Endpoint | Mô tả |
|---|---|
| `GET /health` | Trạng thái, danh sách nhãn, thiết bị, số tên trong từ điển. Không cần API key |
| `POST /extract` | Một văn bản |
| `POST /extract/batch` | Nhiều văn bản (mặc định tối đa 64), nhanh hơn gọi lẻ từng cái |

**Request `/extract`:**

```json
{
  "text": "Tiêu Viêm thi triển Phật Nộ Hỏa Liên về phía đệ tử Vân Lam Tông.",
  "min_score": 0.5,
  "use_dict": true,
  "include_context": false
}
```

**Response** (điểm minh hoạ):

```json
{
  "text": "Tiêu Viêm thi triển Phật Nộ Hỏa Liên về phía đệ tử Vân Lam Tông.",
  "entities": [
    {"label": "NHAN_VAT",  "text": "Tiêu Viêm",        "start": 0,  "end": 9,  "score": 0.998, "source": "model", "context": null},
    {"label": "CONG_PHAP", "text": "Phật Nộ Hỏa Liên", "start": 20, "end": 36, "score": 0.991, "source": "model", "context": null},
    {"label": "THE_LUC",   "text": "Vân Lam Tông",     "start": 51, "end": 63, "score": 0.995, "source": "model", "context": null}
  ],
  "elapsed_ms": 18.4
}
```

- `start`/`end` là vị trí ký tự trên trường `text` của response. Đó là văn bản đã chuẩn hoá Unicode NFC; với văn bản gõ thông thường thì trùng với văn bản gốc.
- `score` là **điểm tin cậy thấp nhất** trong các từ của thực thể (0–1). Bằng `null` nếu tên lấy từ từ điển.
- `source` là `model` hoặc `dict`.

**Gọi thử:**

```bash
curl -X POST http://localhost:8000/extract \
     -H "Content-Type: application/json" -H "X-API-Key: doi-mat-khau-nay" \
     -d '{"text": "Hắn luyện hóa Thanh Liên Địa Tâm Hỏa."}'

python goi_api_mau.py --url http://localhost:8000 --key doi-mat-khau-nay
```

> Trên Windows, `curl` trong cmd dễ lỗi dấu tiếng Việt và dấu nháy. Dùng `goi_api_mau.py` hoặc trang `/docs` thay thế.

### B.3 Biến môi trường

| Biến | Mặc định | Ý nghĩa |
|---|---|---|
| `MODEL_DIR` | `ner-final` | Thư mục mô hình |
| `DICT_PATH` | — | Từ điển tên (tuỳ chọn) |
| `DEVICE` | tự chọn | `cuda` / `cpu` |
| `BATCH_SIZE` | `32` | Kích thước batch |
| `MAX_LEN` | `256` | Bằng `MAX_LEN` lúc huấn luyện |
| `TORCH_THREADS` | — | Số luồng CPU |
| `API_KEY` | — | Nếu đặt thì mọi request (trừ `/health`) phải có header `X-API-Key` |
| `MAX_TEXT_CHARS` | `200000` | Độ dài tối đa mỗi văn bản (vượt quá thì trả lỗi 413) |
| `MAX_BATCH_ITEMS` | `64` | Số văn bản tối đa mỗi request batch |

### B.4 Chạy bằng Docker

```bash
cd trien_khai
docker build -t ner-tien-hiep:1.0 .

docker run -d --name ner-api -p 8000:8000 \
  -v /duong/dan/den/ner-final:/models/ner-final:ro \
  -e API_KEY=doi-mat-khau-nay \
  --restart unless-stopped \
  ner-tien-hiep:1.0

docker logs -f ner-api          # xem log
curl http://localhost:8000/health
```

- Image dùng **PyTorch bản CPU**. Mô hình được **gắn từ ngoài vào** (`-v … :ro`) thay vì đóng gói vào image, nên khi có mô hình mới chỉ cần trỏ sang thư mục mới rồi khởi động lại container.
- Container đã có health check, chạy bằng user thường (không phải root) và ở chế độ offline (không tải gì từ Hugging Face).
- **Muốn dùng GPU:** đổi image gốc sang một image có CUDA và cài PyTorch bản CUDA thay cho dòng `--index-url …/cpu`. Máy chủ cần NVIDIA Container Toolkit, chạy với `docker run --gpus all …`.

### B.5 Mở rộng và hiệu năng

- Mỗi tiến trình nạp **một bản mô hình** (khoảng 1–2 GB RAM) và xử lý **tuần tự** để an toàn. Vì vậy hãy giữ `--workers 1`. Khi cần chịu tải lớn hơn, chạy **nhiều container** phía sau một load balancer.
- Gửi nhiều văn bản trong một request `/extract/batch` sẽ nhanh hơn nhiều so với gọi `/extract` từng cái.
- Trên CPU, đặt `TORCH_THREADS` bằng số nhân CPU dành cho container.
- Văn bản rất dài (cả chương): nên dùng **cách A** (`xu_ly_file.py`) thay vì API.

---

## C. Gọi trực tiếp trong Python

```python
import sys; sys.path.insert(0, "trien_khai")
from ner_engine import NerEngine

eng = NerEngine("ner-final", dict_path="tu_dien.json", batch_size=32)   # nạp 1 lần, dùng nhiều lần
print(eng.info())

kq = eng.extract("Tiêu Viêm rút Huyền Trọng Thước.", min_score=0.5)
for e in kq["entities"]:
    print(e["label"], e["text"], e["start"], e["end"], e["score"], e["source"])

ds = eng.extract_many(["Câu 1 ...", "Câu 2 ..."], with_context=True)    # nhiều văn bản: nhanh hơn
```

---

## Kiểm tra trước khi đưa vào sử dụng

- [ ] F1 trên **tập test (bộ truyện giữ riêng)** đạt yêu cầu ở **từng nhãn**, không chỉ ở con số tổng.
- [ ] Chạy cách A trên **1–2 chương truyện thật chưa dùng để train**, mở file HTML và đọc kiểm tra bằng mắt.
- [ ] Chọn ngưỡng `min_score` phù hợp: thử vài giá trị trên tập test, chọn mức cân bằng giữa bắt đủ tên và ít nhận nhầm.
- [ ] Đặt `API_KEY`; **không mở API ra Internet**. Nếu cần HTTPS, đặt API sau reverse proxy (nginx…) hoặc API gateway của tổ chức.
- [ ] Ghi lại phiên bản mô hình đang chạy (xem `GET /health`, trường `model_dir`).
- [ ] Giám sát log: số request, thời gian xử lý (`elapsed_ms`), lỗi 4xx/5xx.

**Cập nhật mô hình mới:** huấn luyện lại, kiểm tra F1 trên **cùng tập test cũ** để so sánh công bằng. Nếu tốt hơn thì đổi `MODEL_DIR` (hoặc thư mục gắn vào Docker) rồi khởi động lại. Giữ lại thư mục mô hình cũ để có thể quay về khi cần.

**Nếu tổ chức dùng AWS:** image Docker này chạy được trên các dịch vụ container (ví dụ Amazon ECS, hoặc EC2 có Docker). Ngoài ra có thể dùng Amazon SageMaker để host mô hình Hugging Face. Hãy trao đổi với nhóm hạ tầng để chọn phương án phù hợp với quy định nội bộ.

---

## Xử lý sự cố

| Vấn đề | Cách xử lý |
|---|---|
| `thiếu config.json` | `--model` phải trỏ tới thư mục do `trainer.save_model()` tạo ra (`ner-final/`), không phải thư mục checkpoint `ner-out/` |
| Lỗi khi nạp `pytorch_model.bin` | Nâng PyTorch lên ≥ 2.6 |
| `Cần fast tokenizer` | Thư mục mô hình thiếu `tokenizer.json`: chạy lại ô "Lưu mô hình" trong notebook |
| Kết quả khác lúc chạy trong notebook | Kiểm tra `--max-len` / `MAX_LEN` có bằng lúc huấn luyện không |
| Chạy chậm trên CPU | Tăng `--threads` / `TORCH_THREADS`, giảm `--batch-size`, hoặc dùng GPU |
| `CUDA out of memory` | Giảm `--batch-size` / `BATCH_SIZE` |
| API trả 401 | Thiếu header `X-API-Key`, hoặc sai giá trị |
| API trả 413 | Văn bản quá dài hoặc quá nhiều văn bản: chia nhỏ, tăng `MAX_TEXT_CHARS` / `MAX_BATCH_ITEMS`, hoặc dùng cách A |
| Từ điển báo "Bỏ qua nhãn …" | Tên nhãn trong từ điển không có trong mô hình: sửa lại cho khớp 6 mã nhãn |

---

**Tình trạng kiểm thử (phiên bản 1.0):**
- ✅ Đã chạy thử với một **mô hình giả lập** (nên không đo được độ chính xác thật):
  - Logic tách câu, cửa sổ trượt cho câu dài 85–121 từ, ghép batch, vị trí ký tự, từ điển bổ sung, ngưỡng `min_score`.
  - Xử lý hàng loạt 16 file mẫu: CSV, tổng hợp, HTML, vị trí khớp 100% với văn bản gốc.
  - Toàn bộ endpoint API: xác thực, giới hạn kích thước, kiểm tra dữ liệu đầu vào, trang `/docs`.
- ⚠️ **Chưa chạy thử:** với mô hình ViDeBERTa thật, `docker build` / `docker run`, và `goi_api_mau.py` với máy chủ thật.
