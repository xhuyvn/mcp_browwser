# Agent Template — tạo agent mới trong 5 bước

## 1. Copy template
```bash
cp -r agents/_template agents/sales-analyst
```

## 2. Sửa `agents/sales-analyst/agent.yaml`
- `name`: `sales-analyst` (cũng là tên hàng đợi `agenthub:tasks:sales-analyst`)
- `description`: Orchestrator đọc mô tả này để quyết định giao việc → viết rõ chuyên môn.
- `model`: để trống = dùng `LLM_*` chung; hoặc đặt provider/model riêng.
- `system_prompt`: vai trò, quy trình, định dạng đầu ra.
- `engine`: bỏ trống = `native`. Cần JSON đúng schema → `pydantic_ai`; cần người duyệt tool / checkpoint → `langgraph` (xem [ENGINES.md](ENGINES.md)).
- `skills`, `tools`, `mcp_servers`, `limits`.

| Provider | base_url | api_key | Ghi chú |
|---|---|---|---|
| `ollama` | `http://ollama:11434/v1` hoặc `http://host.docker.internal:11434/v1` | bất kỳ | Model hỗ trợ tools: qwen3, llama3.1+, mistral-nemo… |
| `openrouter` | `https://openrouter.ai/api/v1` | `sk-or-...` | Lọc model hỗ trợ `tools`; dùng `fallback_models` với model `:free` |
| `openai_compat` | URL bất kỳ (vLLM, LiteLLM, LM Studio, llama.cpp) | tuỳ | |

## 3. Thêm skill
```
agents/sales-analyst/skills/kpi-report/
  SKILL.md            # frontmatter: name, description (KHI NÀO dùng) + quy trình chi tiết
  templates/kpi.md    # tài nguyên đọc bằng read_skill_file
```

## 4. Thêm custom tool (tuỳ chọn)
```python
# agents/sales-analyst/tools/kpi.py
from agent_runtime.tools import tool

@tool(description="Tính tăng trưởng % giữa 2 kỳ")
def growth(prev: float, curr: float) -> float:
    return round((curr - prev) / prev * 100, 2)
```
Khai báo: `tools: [custom.growth]` hoặc `custom.*`.

## 5. Khai báo container
```yaml
# docker-compose.yml
  agent-sales-analyst:
    <<: *agent
    environment:
      <<: *agent-env
      AGENT_PUBLIC_URL: http://agent-sales-analyst:8000
    volumes: ["./agents/sales-analyst:/agent:ro"]
```
`docker compose up -d agent-sales-analyst` → agent tự đăng ký, xuất hiện trên UI và trong `list_agents` của MCP.

### Thêm MCP server miễn phí
Server stdio (npm/pip) → service dùng image `mcp-bridge`:
```yaml
  mcp-sqlite:
    <<: *mcp
    command: ["mcp-proxy", "--host", "0.0.0.0", "--port", "8080", "--", "<lệnh chạy server stdio>"]
```
(cài thêm package vào `mcp-servers/bridge/Dockerfile`). Rồi thêm vào `mcp_servers` của agent:
```yaml
  - name: sqlite
    url: http://mcp-sqlite:8080/mcp
    allowed_tools: [read_query, list_tables]
```

### Production: bake image
```bash
docker build -t registry.local/agents/sales-analyst:0.1.0 \
  --build-arg RUNTIME_IMAGE=agenthub/agent-runtime:1.0.0 agents/sales-analyst -f agents/_template/Dockerfile
```

### Checklist chất lượng agent
- [ ] `description` nêu rõ chuyên môn và giới hạn
- [ ] `allowed_tools` chỉ gồm tool cần thiết (least privilege)
- [ ] `max_steps`, `task_timeout_s` phù hợp
- [ ] Skill có mục "Định dạng đầu ra"
- [ ] Test bằng Chat trước, rồi bằng Task, rồi qua Orchestrator
