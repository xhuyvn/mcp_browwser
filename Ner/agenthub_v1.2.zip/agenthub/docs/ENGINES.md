# Agent Engines — chọn "bộ não" cho agent

Mỗi agent trong AgentHub chạy một **engine**: phần mã điều khiển vòng lặp *gọi LLM → gọi tool → gọi lại LLM*.
Bạn chọn engine bằng **1 dòng** trong `agent.yaml`. Backend, worker, UI và MCP agent-manager **không cần biết**
agent dùng engine nào.

```yaml
engine:
  type: native          # native | pydantic_ai | langgraph | "module:Class"
```

---

## 1. Chọn engine nào?

| Engine | Dùng khi | Thư viện thêm | Điểm nổi bật |
|---|---|---|---|
| `native` (mặc định) | Phần lớn agent: chat, nghiên cứu, gọi MCP | Không | Ít tầng trừu tượng, dễ debug, chạy với mọi API OpenAI-compatible |
| `pydantic_ai` | Cần **kết quả có cấu trúc** (JSON đúng schema) để hệ thống khác đọc | `requirements-pydantic-ai.txt` | Kiểm tra kết quả theo schema, tự yêu cầu model sửa khi sai; FallbackModel |
| `langgraph` | Tool **nhạy cảm cần người duyệt**; task dài cần **chạy tiếp sau khi container restart** | `requirements-langgraph.txt` | Checkpoint (memory/Postgres), human-in-the-loop (interrupt/resume) |
| `"pkg.mod:Class"` | Muốn tự viết engine (CrewAI, Agents SDK, engine nội bộ…) | Tuỳ | Kế thừa `BaseEngine`, chỉ cần viết `_run()` |

> Mẹo: bắt đầu bằng `native`. Chỉ đổi engine khi bạn **thực sự cần** tính năng ở cột "Điểm nổi bật".

## 2. Engine nào cũng có (do lớp chung `BaseEngine` cung cấp)

- Cùng **system prompt**: `system_prompt` + danh mục skill + `runtime_context` (tên agent, giờ, id task).
- Cùng **lớp tool**: local tools, skill (`load_skill`, `read_skill_file`), MCP (`<server>__<tool>`, `allowed_tools`).
- Cùng **sự kiện timeline**: `run_started` (kèm tên engine), `step`, `token`, `tool_call`, `tool_result`, `warning`,
  `error`, `run_finished` — UI hiển thị giống hệt nhau.
- Cùng **giới hạn**: `max_steps`, `task_timeout_s`, `max_tool_output_chars`, huỷ task.

```
agent_runtime/
  engine_base.py        BaseEngine: prompt, gom tool, exec_tool, huỷ, timeout, phát sự kiện
  engine.py             NativeEngine (mặc định)
  engines/__init__.py   registry: create_engine() đọc engine.type
  engines/pydantic_ai_engine.py
  engines/langgraph_engine.py
```

---

## 3. Engine `pydantic_ai` — kết quả có cấu trúc

### Cấu hình
```yaml
engine:
  type: pydantic_ai
  output_schema:                 # tuỳ chọn; bỏ trống = trả lời dạng văn bản
    title: CompetitorBrief
    type: object
    properties:
      company: {type: string}
      strengths: {type: array, items: {type: string}}
      risk_level: {type: string, enum: [low, medium, high]}
    required: [company, strengths, risk_level]
  options:
    tool_retries: 1              # số lần cho model sửa khi gọi tool sai tham số
    sdk_max_retries: 0           # retry ở tầng OpenAI SDK (mặc định 0 để không nhân retry)
    profile:                     # nới lỏng cho server không phải OpenAI (Ollama, vLLM, OpenRouter…)
      openai_supports_strict_tool_definition: false
```
Kết quả task là **chuỗi JSON** đúng schema → orchestrator hoặc hệ thống khác parse được ngay.

### Lưu ý với Ollama / OpenRouter / vLLM
- Engine dùng `OpenAIChatModel` (**Chat Completions**). Prefix `openai:` mặc định của Pydantic AI đi qua
  *Responses API* — đa số server OpenAI-compatible không có API này.
- Pydantic AI tự đoán "profile" của model theo tên; với model không phải họ OpenAI, engine tắt sẵn
  *strict tool definition*. Nếu tool không bao giờ được gọi, thêm cờ trong `options.profile`.
- Model nhỏ có thể không trả đúng schema → dùng model ≥ 7–8B có hỗ trợ tools, hoặc thêm `fallback_models`.

---

## 4. Engine `langgraph` — checkpoint & con người phê duyệt

### Cấu hình (agent `writer` trong demo)
```yaml
engine:
  type: langgraph
  checkpointer: postgres                       # memory | postgres | none
  checkpoint_url: ${CHECKPOINT_DB_URL:-}       # postgresql://user:pass@postgres:5432/agenthub
  approval_required_tools: [fs__write_file, fs__edit_file]   # hỗ trợ wildcard: "fs__*"
```

### Đồ thị
```
START → agent ──(có tool_calls)──► tools ──► agent …
           └──(không / hết bước)──► END
```
Node `tools` kiểm tra: nếu có tool nằm trong `approval_required_tools` → gọi `interrupt()` **trước khi chạy
bất kỳ tool nào** (nên khi chạy tiếp không có tool nào bị chạy 2 lần).

### Luồng phê duyệt (từ góc nhìn người dùng)
1. Giao task cho `writer` → agent soạn báo cáo và muốn gọi `fs__write_file`.
2. Task chuyển sang trạng thái **`waiting_input` (Chờ duyệt)**; UI hiện khung **"Agent đang chờ bạn phê duyệt"**
   với tên tool và tham số (đường dẫn, nội dung file).
3. Bạn tick các tool cho phép, thêm ghi chú (không bắt buộc) → **Cho phép** hoặc **Từ chối tất cả**.
4. Backend giao lại task kèm quyết định → engine **chạy tiếp từ checkpoint** (`Command(resume=...)`):
   - tool được duyệt: chạy bình thường;
   - tool bị từ chối: agent nhận thông báo "Người dùng TỪ CHỐI… Lý do: …" và tiếp tục bằng cách khác.

Duyệt bằng API / MCP:
```bash
curl -X POST http://localhost:8000/api/tasks/<task_id>/approval \
  -H "Authorization: Bearer $API_TOKEN" -H "Content-Type: application/json" \
  -d '{"approved": true, "comment": "", "calls": {"<call_id>": true}}'
```
MCP agent-manager có tool `approve_task(task_id, approved, comment, calls)`. **Orchestrator không được cấp tool
này** (`allowed_tools`) — quyết định phê duyệt thuộc về con người.

**Từ v1.2** ai được duyệt do `config/policy.yaml` quyết định: cần quyền `tasks:approve`, vai trò khớp luật của tool,
và **không phải người tạo task** (maker-checker). Service account luôn bị chặn. Xem `docs/SECURITY.md` §4.

### Checkpointer
| Giá trị | Bền vững | Khi nào dùng |
|---|---|---|
| `memory` | Mất khi container restart; không chia sẻ giữa replica | Dev, thử nghiệm |
| `postgres` | Có — dùng chung PostgreSQL của AgentHub (bảng `checkpoints*` tự tạo) | **Production**, nhiều replica |
| `none` | Không | Không cần duyệt / không cần chạy tiếp |

`thread_id` của LangGraph = **task id**, nên:
- worker chết giữa chừng → task được giao lại → engine **chạy tiếp từ checkpoint cuối** (durable execution);
- task đang chờ duyệt bị giao lại mà chưa có quyết định → vẫn ở trạng thái chờ, không chạy tool;
- chat không có checkpoint chờ → tool cần duyệt **tự động bị từ chối** (hãy giao việc đó dưới dạng task).

> ⚠ Với `checkpointer: memory` + nhiều replica: task đã chờ duyệt có thể được replica khác nhận lại sau khi
> duyệt → không tìm thấy checkpoint → task failed. Production luôn dùng `postgres`.

---

## 5. Tự viết engine

```python
# agents/my-agent/tools/../  hoặc 1 package riêng cài vào image
from agent_runtime.engine_base import BaseEngine, RunContext, RunResult
from agent_runtime.events import STEP, Event

class MyEngine(BaseEngine):
    engine_name = "my_engine"

    def check_available(self) -> None:
        import my_framework  # noqa: F401 — báo lỗi rõ ràng lúc khởi động nếu thiếu thư viện

    async def _run(self, messages, ctx: RunContext, emit) -> RunResult:
        async with self.mcp.connect(emit) as toolbox:
            specs = self.collect_tools(toolbox)          # local + skill + MCP
            await emit(Event(STEP, {"step": 1, "max_steps": self.m.limits.max_steps}))
            # ... gọi framework của bạn; khi framework gọi tool, dùng:
            out, is_error = await self.exec_tool(name, args, call_id, specs, emit, step=1)
            # ...
            return RunResult("succeeded", "kết quả", steps=1, usage={})
```
Khai báo: `engine: {type: "my_pkg.my_engine:MyEngine"}`. `BaseEngine.run()` đã lo timeout, huỷ,
sự kiện `run_started` / `run_finished` và chuyển lỗi thành `RunResult(failed)`.

**Checklist engine mới**
- [ ] Mọi lần gọi tool đi qua `self.exec_tool(...)` (để có allowlist, cắt output, sự kiện timeline)
- [ ] Gọi `await self.check_cancel(ctx)` ở mỗi bước
- [ ] Tôn trọng `self.m.limits.max_steps`
- [ ] Phát `STEP` mỗi lần gọi LLM; phát `TOKEN` nếu `ctx.stream_tokens`
- [ ] Viết test giống `tests/test_engines.py`

---

## 6. Cài đặt & kiểm thử

Image `agent-runtime` mặc định cài cả hai thư viện (build arg `ENGINES="pydantic-ai langgraph"`).
Image nhỏ nhất (chỉ native): đặt `AGENT_ENGINES=` (rỗng) trong `.env`.

```bash
cd agent-runtime
pip install -r requirements.txt -r requirements-pydantic-ai.txt -r requirements-langgraph.txt pytest
python -m pytest -q tests        # test Pydantic AI / LangGraph tự bỏ qua nếu chưa cài thư viện
```

## 7. Sự cố thường gặp

| Hiện tượng | Nguyên nhân / cách xử lý |
|---|---|
| Agent không khởi động, log `EngineUnavailable` | Image thiếu thư viện engine → build lại với `ENGINES` đúng |
| `pydantic_ai`: lỗi 404 / tool không được gọi | Server không hỗ trợ một tính năng OpenAI → thêm cờ trong `options.profile` |
| `pydantic_ai`: kết quả không đúng schema | Model quá nhỏ → đổi model, hoặc tăng `tool_retries` |
| Task `failed`: "Không tìm thấy checkpoint đang chờ" | `checkpointer: memory` và container đã restart → dùng `postgres` |
| Task kẹt ở "Chờ duyệt" | Chưa ai duyệt: mở trang chi tiết task trên UI, hoặc dùng API/MCP `approve_task`; hoặc Huỷ task |
