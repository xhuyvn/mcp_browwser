# AgentHub — Blueprint & Architecture (v1.2)

> Nền tảng FE/BE quản lý AI agent: đăng ký & giám sát agent, chat với agent, giao task, theo dõi realtime,
> nhận kết quả. Agent dựng từ **một template** chạy trên mọi API **OpenAI-compatible** (Ollama, OpenRouter,
> vLLM, LiteLLM…), tích hợp **Skills + Tools + MCP**; mỗi agent và mỗi MCP server chạy trong **container riêng**.

---

## 0. Tóm tắt quyết định

| Hạng mục | Quyết định | Lý do chính |
|---|---|---|
| Kiểu kiến trúc | Control plane (BE) + Agent runtime phân tán (container) + Tool plane (MCP servers) | Tách trách nhiệm, scale độc lập từng agent, thay model/tool không ảnh hưởng control plane |
| Giao thức tool | **MCP** (Streamable HTTP; stdio server bọc bằng `mcp-proxy`) | Chuẩn mở (Linux Foundation / Agentic AI Foundation), hệ sinh thái server miễn phí lớn |
| Giao thức quản lý agent | REST + SSE cho UI; **MCP agent-manager** cho agent/IDE; Agent Card kiểu A2A để discovery | Agent khác (Orchestrator), Claude Desktop, Cursor… đều điều khiển nền tảng được qua MCP |
| Agent engine | **Native loop** (OpenAI SDK + MCP Python SDK chính thức) sau 1 *Engine port* | Không lock-in; kiểm soát hành vi với provider OpenAI-compatible vốn khác nhau về tool calling; có adapter Pydantic AI / LangGraph khi cần |
| Backend | FastAPI + SQLAlchemy 2 async + PostgreSQL | Async I/O cho SSE/LLM, hệ sinh thái Python AI |
| Queue / realtime | Redis Streams (consumer group) + Pub/Sub | At-least-once, scale ngang bằng replicas, độ trễ thấp |
| Frontend | React + Vite + TypeScript | Nhẹ, nhanh; chuyển Next.js khi cần SSR/SSO |
| Định nghĩa agent | `agent.yaml` + `skills/*/SKILL.md` + `tools/*.py` (config-as-code) | Thêm agent mới không cần viết code runtime |
| Triển khai | Docker Compose (dev/PoC) → Kubernetes + KEDA (prod) | Cùng image, chỉ đổi orchestration |

---

## 1. Mục tiêu & phạm vi

**Mục tiêu**
1. Quản lý vòng đời agent: đăng ký tự động, heartbeat, online/offline, bật/tắt, xem model/skills/tools/MCP.
2. Chat với agent (streaming token + hiển thị tool call).
3. Giao task (UI, REST, MCP), hàng đợi bền vững, huỷ task, theo dõi timeline realtime, nhận kết quả.
4. Agent template: OpenAI-compatible (Ollama/OpenRouter), skills, local tools, MCP; chạy trong container.
5. Đa agent: Orchestrator giao việc cho agent chuyên trách **qua MCP**, có cây task cha/con.
6. Demo ≥2 agent dùng MCP server miễn phí.

**Ngoài phạm vi v1.0** (có trong roadmap): SSO/RBAC chi tiết, UI tạo agent & deploy tự động,
workflow durable nhiều ngày, vector memory, đa tenant, billing.

---

## 2. Nguyên tắc kiến trúc

1. **Protocol-first**: tool qua MCP, agent mô tả bằng Agent Card, sự kiện chuẩn hoá (`run_started`, `step`, `tool_call`, `tool_result`, `run_finished`…).
2. **Framework-agnostic**: engine là một *port*; control plane, worker, UI không phụ thuộc framework agent.
3. **One image, many agents**: mọi agent dùng image `agent-runtime`, khác nhau ở thư mục `/agent`.
4. **Isolation**: mỗi agent & mỗi MCP server là 1 container; tool allowlist theo agent; filesystem MCP chỉ thấy `/workspace`.
5. **Event-sourced timeline**: mọi bước của task được lưu (`task_events`) → audit, replay SSE, debug.
6. **Fail-soft**: MCP server lỗi (không `required`) chỉ sinh cảnh báo; model lỗi → fallback model; task treo → reaper.

---

## 3. Lựa chọn framework

### 3.1 So sánh (tóm tắt khảo sát 2026)

| Framework | Điểm mạnh | Điểm yếu với bài toán này |
|---|---|---|
| LangGraph | Durable state, checkpoint, human-in-the-loop, hệ sinh thái lớn | MCP qua adapter; API churn; nặng cho agent đơn giản |
| OpenAI Agents SDK | Nhiều chế độ kết nối MCP, guardrail, approval | Tính năng hosted MCP gắn với OpenAI; provider khác phải tự quản transport |
| Pydantic AI | Type-safe, API nhỏ, hỗ trợ Ollama/OpenRouter/OpenAI-compatible + MCP | Ít pattern multi-agent dựng sẵn |
| CrewAI | Role-based team nhanh | Khó kiểm soát vòng lặp & sự kiện chi tiết |
| Microsoft Agent Framework / Google ADK / Strands | Vendor-backed, MCP + A2A | Gắn hệ sinh thái cloud tương ứng |

### 3.2 Quyết định
- **Mặc định: native engine** (`agent_runtime/engine.py`, ~200 dòng) dùng `openai` SDK (chat.completions + tools, streaming)
  và **MCP Python SDK chính thức** → chạy với *bất kỳ* endpoint OpenAI-compatible, không phụ thuộc vendor.
- **Engine port** (`BaseEngine`, `engines/`) — **đã triển khai ở v1.1**, chọn bằng `engine.type` trong `agent.yaml`:
  - `native` — mặc định.
  - `pydantic_ai` — kết quả JSON kiểm tra theo `output_schema`, FallbackModel; dùng `OpenAIChatModel` (Chat Completions)
    vì đa số server OpenAI-compatible không có Responses API.
  - `langgraph` — StateGraph + checkpoint (memory/Postgres) + **con người phê duyệt tool** (interrupt/resume),
    chạy tiếp từ checkpoint khi task được giao lại.
  - `"module:Class"` — engine tự viết (Agents SDK, CrewAI…).
  - Mọi engine dùng chung lớp tool/skill/MCP và bộ sự kiện → backend, worker, UI không đổi. Chi tiết: `docs/ENGINES.md`.
- **Model gateway (tuỳ chọn, Phase 3)**: LiteLLM proxy đứng trước Ollama/OpenRouter để quản lý key, budget, cache, fallback tập trung — agent chỉ đổi `base_url`.

---

## 4. Kiến trúc tổng thể

```mermaid
flowchart LR
  subgraph EXP[Experience layer]
    UI[Web UI<br/>React + Vite]
    EXT[MCP clients<br/>Claude Desktop / Cursor / script]
  end
  subgraph CP[Control plane]
    BE[Backend API<br/>FastAPI]
    AM[MCP agent-manager<br/>FastMCP]
    PG[(PostgreSQL<br/>agents, tasks, events, chats)]
    RD[(Redis<br/>Streams + Pub/Sub)]
  end
  subgraph AR[Agent runtime - 1 container / agent]
    OR[orchestrator]
    RS[researcher]
    WR[writer]
  end
  subgraph TP[Tool plane - 1 container / MCP server]
    M1[mcp-ddg<br/>search]
    M2[mcp-fetch]
    M3[mcp-filesystem<br/>/workspace]
    M4[mcp-memory<br/>knowledge graph]
    M5[mcp-time]
  end
  subgraph MP[Model plane - OpenAI-compatible]
    OL[Ollama<br/>local]
    ORT[OpenRouter<br/>cloud]
  end
  UI -- REST + SSE --> BE
  EXT -- MCP --> AM
  AM -- REST --> BE
  BE --- PG
  BE -- XADD task / SUBSCRIBE events --> RD
  RD -- XREADGROUP --> OR & RS & WR
  OR & RS & WR -- register / heartbeat / events / complete --> BE
  BE -- /v1/chat SSE proxy --> OR & RS & WR
  OR -- MCP --> AM
  OR -- MCP --> M5
  RS -- MCP --> M1 & M2
  WR -- MCP --> M3 & M4
  OR & RS & WR -- chat.completions --> OL & ORT
```

### 4.1 Danh mục container

| Service | Image | Cổng | Vai trò |
|---|---|---|---|
| frontend | nginx + build Vite | 3000 | UI: Agents, Chat, Tasks, Task detail |
| backend | python:3.12 FastAPI | 8000 | Registry, task API, SSE, chat proxy, internal API |
| postgres / redis | official | – | Lưu trữ / hàng đợi + realtime |
| mcp-agent-manager | FastMCP | 8090 | MCP: list_agents, assign_task, wait_for_task… |
| mcp-ddg, mcp-fetch, mcp-time, mcp-filesystem, mcp-memory | mcp-bridge (mcp-proxy) | nội bộ | MCP server miễn phí, Streamable HTTP `/mcp` |
| agent-orchestrator / researcher / writer | agent-runtime | nội bộ | Agent; mount `./agents/<name>` → `/agent` |
| ollama (profile) | ollama/ollama | 11434 | LLM local (tuỳ chọn) |

---

## 5. Thành phần chi tiết

### 5.1 Control plane (backend)

**Module**: `api/public.py` (REST/SSE cho người dùng & MCP), `api/internal.py` (agent), `services.py`
(nghiệp vụ task), `bus.py` (Redis), `models.py`, `security.py`.

**Mô hình dữ liệu**

```mermaid
erDiagram
  AGENTS ||--o{ TASKS : "agent"
  TASKS ||--o{ TASKS : "parent_id"
  TASKS ||--o{ TASK_EVENTS : "timeline"
  AGENTS ||--o{ CONVERSATIONS : "chat"
  CONVERSATIONS ||--o{ MESSAGES : ""
  AGENTS { string name PK  string endpoint  json model  json skills  json tools  json mcp_servers  bool enabled  ts last_heartbeat }
  TASKS { string id PK  string agent  text input  string status  text result  text error  string parent_id  string root_id  int depth  string source  json usage  int steps  int duration_ms }
  TASK_EVENTS { bigint id PK  string task_id  string type  json data  ts ts }
  CONVERSATIONS { string id PK  string agent  string title }
  MESSAGES { bigint id PK  string conversation_id  string role  text content  json metadata }
```

**Vòng đời task**

```mermaid
stateDiagram-v2
  [*] --> queued: POST /api/tasks (UI/REST/MCP)
  queued --> running: worker /internal/tasks/:id/start
  queued --> cancelled: cancel
  running --> succeeded: complete
  running --> failed: complete(error) / reaper timeout
  running --> cancelled: cờ huỷ, kiểm tra mỗi bước
  running --> waiting_input: tool cần duyệt (engine langgraph)
  waiting_input --> queued: người dùng duyệt / từ chối (POST /approval)
  waiting_input --> cancelled: huỷ
  running --> running: redelivery (worker chết, XAUTOCLAIM)
```

**Ràng buộc ủy quyền**: độ sâu tối đa `MAX_TASK_DEPTH=3`; không giao cho agent đã có trong chuỗi tổ tiên
(chống vòng lặp/deadlock Orchestrator chờ chính nó).

**API chính**

| Method | Path | Mô tả |
|---|---|---|
| GET | `/api/agents` · `/api/agents/{name}` · `/api/agents/{name}/tools` | Registry, trạng thái, queue depth, tool thực tế |
| PATCH | `/api/agents/{name}` | Bật/tắt agent |
| POST | `/api/agents/{name}/chat` | Chat (SSE proxy, lưu hội thoại) |
| GET | `/api/conversations` · `/api/conversations/{id}/messages` | Lịch sử chat |
| POST | `/api/tasks` | Giao task `{agent, input, parent_id?, source}` |
| GET | `/api/tasks` · `/api/tasks/{id}` · `/api/tasks/{id}/events` | Danh sách / chi tiết + task con / timeline |
| GET | `/api/tasks/{id}/stream` | SSE: replay + realtime đến khi kết thúc |
| POST | `/api/tasks/{id}/cancel` | Huỷ (kể cả task đang chờ duyệt) |
| POST | `/api/tasks/{id}/approval` | Duyệt / từ chối tool đang chờ `{approved, comment, calls}` → task chạy tiếp |
| GET | `/api/stats` · `/healthz` | Thống kê, health |
| POST | `/internal/agents/register` · `/internal/agents/{name}/heartbeat` | Agent tự đăng ký (15s/lần) |
| POST | `/internal/tasks/{id}/start` · `/events` · `/complete` | Worker báo cáo |

### 5.2 Message bus & ngữ nghĩa phân phối
- `agenthub:tasks:<agent>` — Redis Stream, group `workers`; mỗi replica là 1 consumer → **scale ngang**.
- ACK sau khi `complete` → **at-least-once**; message treo > 1,5 × timeout được `XAUTOCLAIM` sang worker khác.
- `/start` là chốt idempotent: task đã kết thúc → 409 → worker bỏ qua.
- `agenthub:events:<task_id>` — Pub/Sub cho SSE; event đồng thời lưu DB để replay.
- `agenthub:cancel:<task_id>` — cờ huỷ (TTL 24h), engine kiểm tra trước mỗi bước.

### 5.3 Agent runtime (template)

```
agent-runtime/agent_runtime/
  config.py        agent.yaml + ${ENV:-default}; preset provider (ollama/openrouter/openai/openai_compat)
  llm.py           OpenAI-compatible client, streaming + gộp tool_call delta, fallback models
  engine.py        vòng lặp ReAct native tool-calling, giới hạn bước/timeout, cắt output tool, huỷ
  tools.py         @tool decorator (schema từ type hints), builtin tools, nạp tools/*.py
  skills.py        Agent Skills (SKILL.md), progressive disclosure: load_skill / read_skill_file
  mcp_manager.py   kết nối MCP theo lượt chạy, namespacing <server>__<tool>, allowlist, fail-soft
  worker.py        Redis Streams consumer group, semaphore concurrency, XAUTOCLAIM
  control_plane.py register / heartbeat / start / events / complete
  server.py        /health, /.well-known/agent-card.json, /v1/tools, /v1/chat (SSE)
  main.py          lắp ráp + lifecycle
```

**Vòng lặp engine**: system prompt = `system_prompt` + danh mục skill + `runtime_context` (agent, giờ, task id)
→ LLM (tools = local + skill + MCP) → nếu có tool_calls: chạy song song, trả kết quả `role=tool` → lặp;
hết `max_steps` → yêu cầu trả lời cuối không dùng tool.

**Engine port** (mở rộng): `async run(messages, ctx, emit) -> RunResult` — adapter khác chỉ cần phát cùng bộ Event.

### 5.4 Skills
Chuẩn thư mục `skills/<name>/SKILL.md` (YAML frontmatter `name`, `description`, `allowed-tools`) + tài nguyên.
Chỉ `name + description` vào system prompt; nội dung đầy đủ nạp khi model gọi `load_skill` → tiết kiệm context,
cho phép mỗi agent có nhiều skill.

### 5.5 Local tools
`@tool` biến hàm Python (sync/async) thành tool; JSON schema sinh từ type hints/Pydantic `Field`.
Builtin: `calculator` (AST an toàn), `current_time`, `json_format`. Chọn bằng pattern: `builtin.*`, `custom.slugify`.

### 5.6 Tích hợp MCP
- Transport: **Streamable HTTP** (mặc định) hoặc SSE (legacy). Server stdio bọc bằng `mcp-proxy`.
- Mở session **theo lượt chạy** trong cùng task asyncio → không giữ kết nối dài, chịu restart; MCP server chạy
  `stateless_http` → sẵn sàng cho đặc tả MCP stateless 2026-07-28 (nâng SDK là chính).
- `allowed_tools` (allowlist), `required`, `headers` (token), `timeout_s`, `read_timeout_s` (tool chạy lâu).

### 5.7 MCP agent-manager

| Tool | Chức năng |
|---|---|
| `list_agents(only_online)` | Agent, trạng thái, skills, MCP, model, queue depth |
| `assign_task(agent, instruction, parent_task_id, wait_seconds)` | Giao 1 task (tuỳ chọn chờ kết quả) |
| `assign_tasks_parallel(assignments, parent_task_id, wait_seconds)` | Fan-out / fan-in |
| `wait_for_task(task_id, timeout_seconds)` | Chờ & nhận kết quả (có progress notification) |
| `get_task(task_id, include_events)` · `list_tasks(...)` · `cancel_task(task_id)` | Theo dõi / huỷ |
| `approve_task(task_id, approved, comment, calls)` | Duyệt / từ chối tool đang chờ (chỉ cho con người — không cấp cho orchestrator) |

Forward token của người gọi (`Authorization`) xuống backend → phân quyền đúng chủ thể.

### 5.8 Frontend
- **Agents**: thẻ agent (online, model, skills, tools, MCP đã kết nối, queue, heartbeat), bật/tắt.
- **Chat**: chọn agent, streaming token, chip tool call (args/output), hội thoại lưu server.
- **Tasks**: form giao task + ví dụ, lọc, bảng realtime (poll 3s).
- **Task detail**: timeline SSE realtime, kết quả Markdown, task con, huỷ.

---

## 6. Luồng nghiệp vụ

### 6.1 Chat
```mermaid
sequenceDiagram
  participant U as UI
  participant B as Backend
  participant A as Agent
  participant L as LLM (Ollama/OpenRouter)
  participant M as MCP server
  U->>B: POST /api/agents/researcher/chat {message}
  B->>A: POST /v1/chat (history + message, stream)
  A->>M: initialize + tools/list (per run)
  loop tối đa max_steps
    A->>L: chat.completions(tools, stream)
    L-->>A: tokens / tool_calls
    A->>M: tools/call
    A-->>B: SSE tool_call / tool_result / token
    B-->>U: SSE (proxy)
  end
  A-->>B: run_finished(output)
  B->>B: lưu messages
```

### 6.2 Orchestrator giao việc qua MCP
```mermaid
sequenceDiagram
  participant C as Client (UI/MCP)
  participant B as Backend
  participant Q as Redis Streams
  participant O as Orchestrator
  participant AM as MCP agent-manager
  participant R as Researcher
  participant W as Writer
  C->>B: POST /api/tasks {agent: orchestrator}
  B->>Q: XADD tasks:orchestrator
  Q-->>O: XREADGROUP
  O->>AM: list_agents()
  O->>AM: assign_task(researcher, ..., parent=T0)
  AM->>B: POST /api/tasks (depth 1)
  B->>Q: XADD tasks:researcher
  Q-->>R: chạy (MCP search + fetch)
  R->>B: complete(result)
  O->>AM: wait_for_task(T1) → result
  O->>AM: assign_task(writer, notes, parent=T0, wait)
  Q-->>W: chạy (MCP filesystem + memory) → /workspace/reports/x.md
  O->>B: complete(T0, tổng hợp)
  B-->>C: SSE task_status succeeded
```

---

## 7. Bảo mật

| Lớp | Biện pháp v1.0 | Nâng cấp (roadmap) |
|---|---|---|
| Xác thực | **v1.2**: OIDC (JWKS, iss/aud/exp) + API key (hash SHA-256) + token tĩnh cho dev; token riêng từng agent | mTLS nội bộ; OAuth cho MCP remote |
| Phân quyền | **v1.2**: RBAC viewer/operator/approver/admin/delegator, `agent_access`, quyền theo task, uỷ quyền không leo thang | ABAC theo dữ liệu / phòng ban |
| Mạng | Network `agentnet` nội bộ; chỉ mở 3000/8000/8090 | NetworkPolicy K8s, egress allowlist cho mcp-fetch |
| Tool | `allowed_tools` theo agent, filesystem chỉ `/workspace`, container non-root | Human approval cho tool nhạy cảm, OPA policy |
| Prompt injection | Skill hướng dẫn coi nội dung web là dữ liệu; giới hạn bước, cắt output | Lọc/đánh dấu nội dung không tin cậy, guardrail model |
| Audit | `task_events` lưu toàn bộ tool call | Xuất SIEM, ký log |
| Secrets | `.env` | Vault/SOPS/K8s Secrets |

---

## 8. Mở rộng & vận hành
- **Scale ngang**: `docker compose up --scale agent-researcher=3` (cùng consumer group). K8s: KEDA scaler theo
  lag của Redis Stream.
- **Thêm agent**: copy `agents/_template` → sửa `agent.yaml` → thêm service compose (hoặc bake image).
- **Thêm MCP server**: 1 service mới dùng `mcp-bridge` (stdio) hoặc image riêng (HTTP) → khai báo trong `mcp_servers`.
- **Đổi model**: đổi `LLM_*` hoặc override từng agent (`ORCHESTRATOR_MODEL`…); `fallback_models` cho model free hay hết quota.
- **Observability**: log có cấu trúc, timeline task, usage token/bước/thời gian; roadmap OpenTelemetry (GenAI semantic
  conventions) + Prometheus/Grafana.
- **HA**: backend stateless (nhiều replica), Postgres HA, Redis Sentinel/AOF.

---

## 9. Demo

| Agent | MCP server (miễn phí) | Skill | Vai trò demo |
|---|---|---|---|
| orchestrator | **agent-manager** (AgentHub), time | task-delegation | Chia việc, giao task, theo dõi, tổng hợp |
| researcher | **duckduckgo-mcp-server**, **server-fetch** (official) | web-research | Tìm & đọc web, trích nguồn |
| writer (engine **langgraph**) | **server-filesystem**, **server-memory** (official) | report-writing | Viết báo cáo, **chờ người duyệt** rồi lưu `/workspace/reports`, ghi knowledge graph |

Kịch bản (`scripts/demo_mcp_client.py` — điều khiển **hoàn toàn qua MCP**):
1. `list_agents` → thấy 3 agent online.
2. `assign_task(researcher)` → `wait_for_task` → kết quả có URL nguồn.
3. `assign_task(writer, ghi chú từ bước 2)` → file báo cáo trong volume `workspace`.
4. `assign_task(orchestrator, "nghiên cứu + viết báo cáo")` → orchestrator tự gọi agent-manager MCP để giao
   researcher → writer; UI hiển thị cây task con + timeline realtime.

---

## 10. Kế hoạch triển khai

Giả định: 2–3 kỹ sư (1 BE/agent, 1 FE, 0,5 DevOps).

| Giai đoạn | Thời gian | Hạng mục | Tiêu chí nghiệm thu | Trạng thái |
|---|---|---|---|---|
| P0 — Nền tảng | Tuần 1 | Repo, compose, agent runtime (LLM + tools + skills + MCP), 1 agent chat được | Agent gọi tool MCP qua Ollama & OpenRouter | ✅ v1.0 |
| P1 — MVP control plane | Tuần 2–3 | Registry/heartbeat, task queue, SSE timeline, chat proxy, UI 4 trang, MCP agent-manager, 3 agent demo | Demo 3 kịch bản end-to-end; huỷ task; scale researcher=3 | ✅ v1.0 (cần chạy nghiệm thu trên môi trường thật) |
| P1.5 — Engine adapters | Tuần 3 | Engine port, adapter Pydantic AI & LangGraph, phê duyệt tool (UI/API/MCP), checkpoint Postgres | Writer chờ duyệt → duyệt/từ chối chạy đúng; task chạy tiếp sau khi kill container | ✅ v1.1 (logic đã test mô phỏng; cần test với thư viện thật) |
| P2a — Bảo mật | Tuần 4 | OIDC + API key, RBAC (`policy.yaml`), maker-checker, hộp thư Chờ duyệt + webhook nhắc / hết hạn, audit log, rate limit, token riêng từng agent, CSP | Đăng nhập Keycloak; alice không tự duyệt được, bob duyệt được; mọi 403 có audit | ✅ v1.2 (logic phân quyền & xác thực JWT đã test; endpoint/UI/Keycloak cần chạy thật) — xem docs/SECURITY.md |
| P2b — Vận hành | Tuần 5 | Alembic, DLQ & retry policy, OpenTelemetry + Prometheus, test e2e CI, pen-test | Pen-test cơ bản đạt; p95 API < 200 ms; trace đầy đủ 1 task | ⏳ |
| P3 — Scale & hệ sinh thái | Tuần 6–7 | Helm chart, KEDA autoscale, LiteLLM gateway (budget/cache), UI tạo agent từ template + deploy, tích hợp MCP gateway (MCP Tool Platform), endpoint A2A | Tạo agent mới từ UI < 5 phút; autoscale theo lag | ⏳ |
| P4 — Nâng cao | Tuần 8+ | Memory dài hạn (pgvector), bộ đánh giá agent (golden tasks), adapter LangGraph/Temporal cho workflow durable, nâng MCP SDK lên spec 2026-07-28, multi-tenant | Điểm eval ổn định giữa các model; workflow chạy nhiều ngày | ⏳ |

**Backlog kỹ thuật P2 (ưu tiên)**
1. Migration Alembic thay `create_all`. 2. Test tích hợp backend (Postgres/Redis bằng testcontainers).
3. Chế độ `tool_calling: prompt` (ReAct JSON) cho model không hỗ trợ native tools.
4. Giới hạn token/chi phí theo task; ghi usage vào dashboard. 5. Retention `task_events`.

---

## 11. Rủi ro & giảm thiểu

| Rủi ro | Ảnh hưởng | Giảm thiểu |
|---|---|---|
| Model nhỏ (Ollama) gọi tool kém / sai JSON | Task thất bại | Model ≥7–8B hỗ trợ tools; báo lỗi JSON để model tự sửa; orchestrator dùng model mạnh (OpenRouter) |
| Model free OpenRouter giới hạn rate/ngừng | Gián đoạn | `fallback_models`, LiteLLM gateway, chuyển Ollama |
| Spec MCP thay đổi (2026-07-28 stateless) | Vỡ tương thích | Pin SDK, session theo lượt, server stateless, lớp `mcp_manager` cô lập |
| Prompt injection từ web | Hành động ngoài ý muốn | allowlist tool, filesystem sandbox, không cấp tool nguy hiểm cho researcher, human approval (P2) |
| Vòng lặp ủy quyền | Treo tài nguyên | Giới hạn depth, chặn agent tổ tiên, timeout, reaper |
| Task trùng do at-least-once | Ghi file 2 lần | `/start` idempotent, thiết kế tool idempotent (ghi đè theo slug) |

## 12. Câu hỏi mở
1. Môi trường đích: Docker Compose trên VPS hay K8s on-prem? (ảnh hưởng P3)
2. Nguồn danh tính: AD/LDAP, Keycloak hay token broker của MCP Tool Platform?
3. Chính sách dữ liệu: có cho phép gửi dữ liệu nội bộ ra OpenRouter không, hay chỉ Ollama?
4. Số agent & tải dự kiến (task/ngày) để định cỡ GPU cho Ollama.

---

## Phụ lục A — Cấu trúc repo
```
agenthub/
├── docker-compose.yml · .env.example · Makefile · README.md
├── docs/BLUEPRINT.md · docs/AGENT_TEMPLATE.md
├── backend/            FastAPI control plane
├── frontend/           React + Vite UI
├── agent-runtime/      Agent template runtime (image dùng chung) + tests
├── agents/
│   ├── _template/      agent.yaml mẫu, skill mẫu, custom tool mẫu, Dockerfile bake
│   ├── orchestrator/   skill task-delegation, MCP agent-manager + time
│   ├── researcher/     skill web-research, MCP duckduckgo + fetch
│   └── writer/         skill report-writing, MCP filesystem + memory
├── mcp-servers/
│   ├── agent-manager/  MCP control-plane (FastMCP)
│   └── bridge/         image chạy MCP stdio miễn phí qua mcp-proxy
└── scripts/            demo_mcp_client.py · demo_rest.sh
```
