# Bảo mật AgentHub (v1.2) — đăng nhập, phân quyền, phê duyệt, audit

Tài liệu này dành cho người mới: đọc §1 để hiểu bức tranh, §6 để chạy demo, §8 trước khi lên production.

---

## 1. Tổng quan — 5 lớp kiểm soát

| Lớp | Câu hỏi | Cơ chế |
|---|---|---|
| Xác thực người dùng | Bạn là ai? | OIDC (Keycloak, Microsoft Entra ID, ADFS, Okta…) · API key (service) · token tĩnh (chỉ dev) |
| Phân quyền (RBAC) | Bạn được làm gì? | Vai trò → permission (`config/policy.yaml`) |
| Quyền theo tài nguyên | Trên agent / task nào? | `agent_access` (ai dùng agent nào) · chỉ xem / huỷ task của mình |
| Phê duyệt tool | Ai cho phép agent làm việc nhạy cảm? | Luật duyệt theo tool + **maker-checker** (người tạo task không tự duyệt) |
| Truy vết | Ai đã làm gì, khi nào? | Bảng `audit_log` + log JSON cho SIEM |

Thêm vào đó: token **riêng cho từng agent** (agent → backend), rate limit, header bảo mật (CSP…),
MCP agent-manager **bắt buộc** token của người gọi.

```
Trình duyệt ──OIDC code+PKCE──► IdP (Keycloak)
    │ access token (JWT, aud=agenthub-api)
    ▼
Backend ── kiểm chữ ký qua JWKS, iss, aud, exp ──► Principal {sub, name, roles}
    │                                                  │
    │                         policy.yaml: permission · agent_access · approvals
    ▼
Agent (service account "delegator") ──MCP agent-manager (token của chính nó)──► Backend
```

---

## 2. Xác thực

### 2.1 Chế độ `AUTH_MODE`
| Giá trị | Dùng khi |
|---|---|
| `static` | Dev / demo: token tĩnh trong `API_TOKENS` (mặc định) |
| `oidc` | Chỉ nhận JWT từ IdP |
| `both` | **Khuyến nghị production**: người dùng đăng nhập OIDC; service/tích hợp dùng API key |

### 2.2 OIDC — backend kiểm tra gì
- Chữ ký bằng khoá công khai lấy từ **JWKS** (`OIDC_JWKS_URL`, hoặc tự tìm qua `<issuer>/.well-known/openid-configuration`).
- Chỉ nhận thuật toán bất đối xứng khai báo trong `OIDC_ALGORITHMS` (mặc định RS256, ES256, PS256) →
  chặn `alg=none` và tấn công nhầm thuật toán (dùng public key làm secret HS256).
- `iss` = `OIDC_ISSUER`, `aud` chứa `OIDC_AUDIENCE`, còn hạn (`exp`, lệch giờ cho phép 30 giây), có `sub`.
- **Vai trò** đọc từ claim `OIDC_ROLE_CLAIMS` (mặc định `realm_access.roles,roles,groups`) rồi ánh xạ qua
  `OIDC_ROLE_MAP` (mặc định `agenthub-admin:admin,agenthub-approver:approver,…`).
  Không có ánh xạ ngầm: vai trò `admin` của **ứng dụng khác** trong cùng IdP không thành admin AgentHub.

### 2.3 Dùng IdP khác
| IdP | Cấu hình |
|---|---|
| Keycloak | Như demo (§6). `OIDC_ROLE_CLAIMS=realm_access.roles` |
| Microsoft Entra ID | `OIDC_ISSUER=https://login.microsoftonline.com/<tenant>/v2.0`, `OIDC_AUDIENCE=api://agenthub-api`, App roles → `OIDC_ROLE_CLAIMS=roles` |
| ADFS / Okta / Auth0 | Issuer + audience của IdP; claim vai trò thường là `roles` hoặc `groups` |
| Token broker nội bộ (vd. MCP Tool Platform) | Nếu broker công bố JWKS: dùng như OIDC. Nếu ký HS256: `JWT_HS256_SECRET` (≥ 32 byte) + `OIDC_ISSUER` của broker |

### 2.4 API key cho service / tích hợp
- Chỉ lưu **SHA-256** trong `config/api_keys.yaml`, so sánh thời gian hằng (`hmac.compare_digest`).
- Tạo khoá: `python backend/scripts/gen_api_key.py --name ci-bot --roles operator` (khoá chỉ hiện 1 lần).
- Thu hồi: `disabled: true` rồi restart backend.
- Service account gắn agent: thêm `agent: orchestrator` → chỉ giao task con từ task của chính agent đó.

### 2.5 Token giữa các thành phần
| Hướng | Token | Ghi chú |
|---|---|---|
| Agent → backend (`/internal/*`) | `X-Agent-Name` + `X-Internal-Token` **riêng từng agent** (`AGENT_TOKENS`) | Agent chỉ đăng ký/heartbeat cho chính nó và chỉ báo cáo task giao cho nó; không giả được sự kiện `task_status`, `approval_submitted` |
| Backend → agent (`/v1/chat`) | `AGENT_API_TOKEN` | |
| Orchestrator → MCP agent-manager → backend | API key vai trò `delegator` (`ORCHESTRATOR_SERVICE_KEY`) | Agent-manager chuyển tiếp token người gọi; **không còn token dự phòng** |
| Claude Desktop / Cursor → MCP agent-manager | API key / access token của **chính người dùng** | Quyền bằng đúng quyền của người đó |

---

## 3. Phân quyền — `config/policy.yaml`

### 3.1 Vai trò mặc định
| Vai trò | Permission | Dành cho |
|---|---|---|
| `viewer` | `agents:read`, `tasks:read:all` | Quan sát, kiểm toán nghiệp vụ |
| `operator` | `agents:read`, `tasks:read` (của mình), `tasks:create`, `tasks:cancel` (của mình), `chat` | Người dùng nghiệp vụ (maker) |
| `approver` | kế thừa `viewer` + `tasks:approve` | Người duyệt (checker) |
| `admin` | `*` | Quản trị (bật/tắt agent, xem audit, huỷ mọi task) |
| `delegator` | `agents:read`, `tasks:delegate`, `tasks:read:all` | **Chỉ** service account của orchestrator |

Một người có thể có nhiều vai trò (vd. `operator` + `approver`). Danh sách permission: `GET /api/permissions`.

### 3.2 Quyền dùng agent
```yaml
agent_access:
  "*": [operator, admin]
  finance-*: [finance-operator, admin]     # tên cụ thể / wildcard dài hơn được ưu tiên
```
UI ẩn nút Chat / Giao task với agent bạn không được dùng; backend vẫn kiểm tra lại (403 + audit).

### 3.3 Task của ai?
- `created_by` = `sub` của người tạo. Người chỉ có `tasks:read` thấy task của mình; xem task người khác → **404**
  (không lộ sự tồn tại).
- **Uỷ quyền qua orchestrator**: task con do service account `delegator` tạo **mang danh người tạo task gốc**
  (`created_by` giữ nguyên, `delegated_by = svc-orchestrator`), và bị giới hạn bởi **vai trò của người đó**
  → orchestrator không thể giao việc cho agent mà người dùng không được dùng (không leo thang quyền).
- Metadata do client gửi bị lọc các khoá hệ thống (`resume`, `created_by_*`, `approvals`…).

---

## 4. Phê duyệt tool

### 4.1 Luật duyệt
```yaml
approvals:
  maker_checker: true
  rules:                                   # luật ĐẦU TIÊN khớp (agent + tool) quyết định
    - agents: ["*"]
      tools: [fs__write_file, fs__edit_file, fs__move_file]
      roles: [approver, admin]
    - agents: ["*"]
      tools: ["*"]
      roles: [admin]                       # tool không khớp luật nào: chỉ admin
```
Người duyệt phải: là **con người** (`kind=user`) · có `tasks:approve` · có vai trò trong luật của **mọi** tool đang chờ ·
và **không phải người tạo task** (maker-checker). Lý do bị chặn hiển thị ngay trên UI.

### 4.2 Hộp thư "Chờ duyệt" & thông báo
- UI: menu **🛂 Chờ duyệt** có badge số việc bạn duyệt được (`GET /api/approvals`).
- Webhook (`NOTIFY_WEBHOOK_URL`) khi có task mới chờ duyệt, nhắc lại sau `APPROVAL_REMIND_AFTER_MIN` (30 phút),
  và khi hết hạn. `NOTIFY_WEBHOOK_FORMAT=slack` gửi `{"text": …}` (Slack, Mattermost, Google Chat);
  `generic` gửi JSON + header `X-AgentHub-Signature: sha256=<HMAC>` để bên nhận xác minh.
- Payload **không chứa tham số tool** (nội dung file có thể nhạy cảm) — chỉ tên tool, agent, người yêu cầu, link.

### 4.3 Hết hạn phê duyệt
Sau `APPROVAL_TIMEOUT_MIN` (mặc định 1440 = 24 giờ): `APPROVAL_TIMEOUT_ACTION=reject` (agent nhận "bị từ chối" và
làm tiếp bằng cách khác) hoặc `cancel` (huỷ task). Ghi audit `task.approval.expired`.

---

## 5. Audit, rate limit, header bảo mật
- **Audit** (`GET /api/audit`, trang 📜 Audit cho admin): `task.create`, `task.cancel`, `task.approve`, `task.reject`,
  `task.approval.expired`, `agent.update`, `chat.start` và mọi lần bị từ chối (`outcome=deny`).
  Không ghi nội dung tin nhắn. 401 chỉ ghi log (không ghi DB) để không bị làm phình bảng.
  Logger `agenthub.audit` in JSON một dòng → chuyển sang SIEM.
- **Rate limit** theo người dùng/phút: giao task 30, chat 20, phê duyệt 30 (`RATE_LIMIT_*`). Redis lỗi → tạm bỏ qua.
- **Header**: backend `nosniff`, `X-Frame-Options: DENY`, `Referrer-Policy`, `Cache-Control: no-store`;
  frontend thêm **CSP** chỉ cho phép script cùng origin. Token không còn đặt trên URL (`ALLOW_QUERY_TOKEN=false`),
  frontend lưu token ở `sessionStorage` và không nhúng token nào vào bản build.

---

## 6. Chạy demo

### 6.1 Chế độ static (mặc định, không cần IdP)
5 danh tính demo trong `.env`:

| Token | Người | Vai trò |
|---|---|---|
| `dev-operator-token` | alice | operator — giao task |
| `dev-approver-token` | bob | approver + operator — duyệt |
| `dev-viewer-token` | dave | viewer |
| `dev-admin-token` | admin | admin |
| `dev-orchestrator-key` | svc-orchestrator | delegator (agent orchestrator dùng) |

Thử maker-checker: đăng nhập UI bằng token của **alice**, giao task cho `writer` → task chờ duyệt, alice thấy
"Bạn không duyệt được: Maker-checker…". Mở tab ẩn danh, đăng nhập **bob** → menu Chờ duyệt có badge → duyệt.
Script: `python scripts/demo_mcp_client.py` (tự dùng 2 danh tính alice / bob).

### 6.2 Chế độ OIDC với Keycloak
```bash
# .env: bỏ comment khối "OIDC" (AUTH_MODE=both, OIDC_*, VITE_*, KEYCLOAK_PUBLIC_URL)
docker compose --profile oidc up -d --build
```
- Keycloak: http://localhost:8081 (realm `agenthub` nạp từ `deploy/keycloak/agenthub-realm.json`).
- Tài khoản demo: `alice` / `alice-demo-123` (operator) · `bob` / `bob-demo-123` (approver) ·
  `carol` / `carol-demo-123` (admin) · `dave` / `dave-demo-123` (viewer).
- Vì sao có 2 URL Keycloak: trình duyệt gọi `localhost:8081` (nên `iss` = `http://localhost:8081/realms/agenthub`),
  còn backend trong Docker lấy JWKS qua `http://keycloak:8080/...` → khai báo cả `OIDC_ISSUER` và `OIDC_JWKS_URL`.

---

## 7. Mối đe doạ & biện pháp

| Mối đe doạ | Biện pháp |
|---|---|
| Lộ token tĩnh / token trong bundle JS | OIDC cho người; API key chỉ lưu hash; bỏ `VITE_API_TOKEN`; sessionStorage |
| Giả mạo JWT (`alg=none`, nhầm thuật toán, khoá lạ) | Allowlist thuật toán, JWKS theo `kid`, kiểm `iss`/`aud`/`exp` |
| IDOR: xem / huỷ / duyệt task người khác | Kiểm tra quyền trên từng task; trả 404 cho task không được xem |
| Người tạo task tự duyệt việc nhạy cảm | Maker-checker |
| Orchestrator bị prompt injection rồi tự duyệt / leo thang | Không cấp `approve_task` (allowlist) **và** backend chặn service account duyệt; uỷ quyền giới hạn bởi vai trò người tạo gốc |
| Agent bị chiếm quyền giả mạo agent khác / báo kết quả task khác | Token riêng từng agent, kiểm `task.agent` |
| Ai đó vào cổng MCP 8090 mượn quyền service | Bỏ token dự phòng, bắt buộc token người gọi |
| Spam giao task / chat làm tốn LLM | Rate limit theo người dùng |
| Lộ dữ liệu qua thông báo | Payload không chứa tham số tool; webhook ký HMAC |
| Chối bỏ trách nhiệm | Audit mọi thao tác và mọi lần bị từ chối |

---

## 8. Checklist trước production
- [ ] `AUTH_MODE=both`, tắt mọi token `dev-*` trong `API_TOKENS` (để trống), dùng `config/api_keys.yaml`
- [ ] Sinh lại `*_INTERNAL_TOKEN`, `AGENT_API_TOKEN`, `ORCHESTRATOR_SERVICE_KEY`, `POSTGRES_PASSWORD` (≥ 32 ký tự ngẫu nhiên), lưu ở secret manager
- [ ] Keycloak chạy `start` (không phải `start-dev`) với PostgreSQL riêng, HTTPS, đổi mật khẩu admin, bỏ user demo
- [ ] HTTPS trước frontend / backend / MCP 8090 (reverse proxy); `ENABLE_API_DOCS=false`
- [ ] Rà `config/policy.yaml`: `agent_access`, luật duyệt cho mọi tool nhạy cảm, `maker_checker: true`
- [ ] Cấu hình `NOTIFY_WEBHOOK_URL` (+ `NOTIFY_WEBHOOK_SECRET`) để người duyệt nhận thông báo
- [ ] Chuyển log `agenthub.audit` sang SIEM; định kỳ sao lưu bảng `audit_log`
- [ ] Không mở cổng 8090 ra Internet

## 9. Trạng thái kiểm thử (v1.2)
- **Đã chạy được trong môi trường phát triển**: toàn bộ luật phân quyền (vai trò, quyền dùng agent, xem/huỷ task,
  ma trận phê duyệt + maker-checker, uỷ quyền không leo thang, kiểm tra file policy); xác thực token tĩnh, API key
  file, **JWT thật** (RS256 qua JWKS server cục bộ, HS256) cùng các ca tấn công (`alg=none`, nhầm thuật toán, khoá lạ,
  `kid` lạ, sai `aud` / `iss`, hết hạn); lớp FastAPI (401 / 403 + audit, token riêng từng agent).
  Test tương ứng: `backend/tests/test_security.py`.
- **Chưa chạy**: các endpoint backend gắn với DB (giao task, duyệt, audit, hộp thư Chờ duyệt, nhắc / hết hạn),
  thông báo webhook, giao diện đăng nhập OIDC, realm Keycloak, Docker Compose.
