"""Mô hình sự kiện chuẩn của một lượt chạy agent (dùng chung cho chat SSE và task timeline)."""
from __future__ import annotations

import time
from dataclasses import dataclass, field
from typing import Any, Awaitable, Callable

# Các loại sự kiện
RUN_STARTED = "run_started"
STEP = "step"
TOKEN = "token"              # chỉ dùng cho chat streaming
TOOL_CALL = "tool_call"
TOOL_RESULT = "tool_result"
MESSAGE = "message"          # nội dung assistant trung gian (có kèm tool call)
WARNING = "warning"
ERROR = "error"
INTERRUPT = "interrupt"      # engine tạm dừng, chờ con người (LangGraph human-in-the-loop)
APPROVAL = "approval"        # quyết định phê duyệt / từ chối tool
RUN_FINISHED = "run_finished"


@dataclass
class Event:
    type: str
    data: dict[str, Any] = field(default_factory=dict)
    ts: float = field(default_factory=time.time)

    def to_dict(self) -> dict[str, Any]:
        return {"type": self.type, "data": self.data, "ts": self.ts}


Emitter = Callable[[Event], Awaitable[None]]


async def null_emitter(_: Event) -> None:  # pragma: no cover - trivial
    return None
