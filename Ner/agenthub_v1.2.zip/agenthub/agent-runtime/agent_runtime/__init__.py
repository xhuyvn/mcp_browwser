"""AgentHub Agent Runtime — template chạy agent trên API OpenAI-compatible + Skills + Tools + MCP."""
__version__ = "1.0.0"
