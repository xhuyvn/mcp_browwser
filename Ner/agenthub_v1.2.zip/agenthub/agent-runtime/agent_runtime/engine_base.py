"""Engine port — hợp đồng chung cho mọi agent engine (native, Pydantic AI, LangGraph, engine tự viết).

Mọi engine:
  * nhận cùng đầu vào:  messages (user/assistant), RunContext, emit (hàm phát Event)
  * dùng chung lớp tool: local tools + skills + MCP (MCPManager: allowlist, namespacing, fail-soft)
  * phát cùng bộ Event (run_started, step, token, tool_call, tool_result, run_finished, ...)
  * trả về RunResult

=> Backend, worker, UI không cần biết bên trong agent chạy framework nào.
Engine mới chỉ cần kế thừa BaseEngine và cài đặt `_run()`.
"""
from __future__ import annotations

import asyncio
import json
import os
import time
import uuid
from dataclasses import dataclass, field
from datetime import datetime
from typing import Any, Awaitable, Callable, Literal
from zoneinfo import ZoneInfo

from .config import AgentManifest
from .events import (ERROR, INTERRUPT, RUN_FINISHED, RUN_STARTED, TOKEN, TOOL_CALL, TOOL_RESULT, Emitter, Event,
                     null_emitter)
from .llm import LLMClient
from .mcp_manager import MCPManager, MCPToolbox
from .skills import SkillLibrary
from .tools import ToolSpec

RunStatus = Literal["succeeded", "failed", "cancelled", "waiting_input"]

FINAL_ANSWER_PROMPT = (
    "Bạn đã dùng hết số bước cho phép. Hãy đưa ra câu trả lời cuối cùng tốt nhất "
    "dựa trên thông tin đã có, không gọi thêm công cụ."
)


class RunCancelled(Exception):
    """Người dùng đã huỷ task — engine dừng ở điểm kiểm tra kế tiếp."""


@dataclass
class RunContext:
    kind: Literal["chat", "task"] = "chat"
    run_id: str = field(default_factory=lambda: uuid.uuid4().hex)
    task_id: str | None = None
    parent_task_id: str | None = None
    user: str | None = None
    stream_tokens: bool = False
    is_cancelled: Callable[[], Awaitable[bool]] | None = None
    resume: Any = None                       # quyết định của con người khi tiếp tục task đang chờ duyệt
    extra: dict[str, Any] = field(default_factory=dict)


@dataclass
class RunResult:
    status: RunStatus
    output: str
    steps: int
    usage: dict[str, int]
    error: str | None = None
    messages: list[dict[str, Any]] = field(default_factory=list)
    duration_ms: int = 0
    interrupt: dict[str, Any] | None = None  # nội dung cần con người xử lý (status = waiting_input)


_USAGE_ALIAS = {"input_tokens": "prompt_tokens", "output_tokens": "completion_tokens",
                "request_tokens": "prompt_tokens", "response_tokens": "completion_tokens"}


def merge_usage(total: dict[str, int], usage: dict[str, Any] | None) -> None:
    """Cộng dồn usage; chấp nhận cả tên trường kiểu OpenAI và kiểu Pydantic AI."""
    if not usage:
        return
    has_total = False
    for k, v in usage.items():
        key = _USAGE_ALIAS.get(k, k)
        if key in ("prompt_tokens", "completion_tokens", "total_tokens") and isinstance(v, int):
            total[key] = total.get(key, 0) + v
            has_total = has_total or key == "total_tokens"
    if not has_total:
        total["total_tokens"] = total.get("prompt_tokens", 0) + total.get("completion_tokens", 0)


def _find(exc: BaseException, kind: type) -> BaseException | None:
    """Tìm exception loại `kind` kể cả khi bị bọc trong ExceptionGroup (anyio/MCP transport)."""
    if isinstance(exc, kind):
        return exc
    if isinstance(exc, BaseExceptionGroup):
        for sub in exc.exceptions:
            found = _find(sub, kind)
            if found is not None:
                return found
    return None


def _leaf(exc: BaseException) -> BaseException:
    while isinstance(exc, BaseExceptionGroup) and exc.exceptions:
        exc = exc.exceptions[0]
    return exc


class BaseEngine:
    engine_name = "base"

    def __init__(self, manifest: AgentManifest, llm: LLMClient, local_tools: list[ToolSpec],
                 skills: SkillLibrary, mcp: MCPManager):
        self.m = manifest
        self.cfg = manifest.engine
        self.llm = llm
        self.local_tools = local_tools
        self.skills = skills
        self.mcp = mcp

    # ------------------------------------------------------------------ dùng chung
    def check_available(self) -> None:
        """Gọi lúc khởi động: báo lỗi rõ ràng nếu thiếu thư viện của engine."""

    def system_prompt(self, ctx: RunContext) -> str:
        tz = os.environ.get("TZ", "Asia/Ho_Chi_Minh")
        try:
            now = datetime.now(ZoneInfo(tz)).isoformat(timespec="minutes")
        except Exception:  # noqa: BLE001
            now = datetime.utcnow().isoformat(timespec="minutes") + "Z"
        parts = [self.m.system_prompt.strip()]
        catalog = self.skills.catalog_prompt()
        if catalog:
            parts.append(catalog)
        runtime = ["<runtime_context>", f"agent_name: {self.m.name}", f"current_time: {now} ({tz})",
                   f"mode: {ctx.kind}"]
        if ctx.task_id:
            runtime.append(f"current_task_id: {ctx.task_id}")
        if ctx.parent_task_id:
            runtime.append(f"parent_task_id: {ctx.parent_task_id}")
        runtime.append("</runtime_context>")
        parts.append("\n".join(runtime))
        parts.append(
            "Quy tắc: chỉ gọi công cụ khi cần; không bịa kết quả công cụ; nếu công cụ lỗi hãy thử cách khác "
            "hoặc nói rõ hạn chế. Trả lời cuối cùng bằng ngôn ngữ của người dùng"
            + (" (mặc định tiếng Việt)." if self.m.language == "vi" else ".")
        )
        return "\n\n".join(parts)

    def collect_tools(self, toolbox: MCPToolbox) -> dict[str, ToolSpec]:
        specs: dict[str, ToolSpec] = {}
        for s in [*self.local_tools, *self.skills.tools(), *toolbox.specs]:
            specs[s.name] = s
        return specs

    def token_callback(self, ctx: RunContext, emit: Emitter):
        if not ctx.stream_tokens:
            return None

        async def on_token(text: str) -> None:
            await emit(Event(TOKEN, {"text": text}))
        return on_token

    async def check_cancel(self, ctx: RunContext) -> None:
        if ctx.is_cancelled and await ctx.is_cancelled():
            raise RunCancelled()

    async def exec_tool(self, name: str, args: dict[str, Any], call_id: str, specs: dict[str, ToolSpec],
                        emit: Emitter, step: int) -> tuple[str, bool]:
        """Chạy 1 tool + phát tool_call/tool_result + cắt output. Mọi engine dùng chung hàm này."""
        spec = specs.get(name)
        await emit(Event(TOOL_CALL, {"id": call_id, "name": name, "arguments": args, "step": step,
                                     "source": spec.group if spec else "unknown"}))
        t0 = time.monotonic()
        is_error = False
        if spec is None:
            out, is_error = f"ERROR: không có công cụ '{name}'. Công cụ hợp lệ: {', '.join(specs)}", True
        elif "__raw__" in args:
            out, is_error = "ERROR: arguments không phải JSON hợp lệ, hãy gọi lại với JSON đúng schema.", True
        else:
            try:
                res = await spec.invoke(args)
                out = res if isinstance(res, str) else json.dumps(res, ensure_ascii=False, default=str)
                is_error = out.startswith("ERROR:")
            except RunCancelled:
                raise
            except Exception as exc:  # noqa: BLE001
                out, is_error = f"ERROR: {type(exc).__name__}: {exc}", True
        limit = self.m.limits.max_tool_output_chars
        if len(out) > limit:
            out = out[:limit] + f"\n...[đã cắt bớt {len(out) - limit} ký tự]"
        await emit(Event(TOOL_RESULT, {"id": call_id, "name": name, "is_error": is_error, "step": step,
                                       "duration_ms": int((time.monotonic() - t0) * 1000), "output": out[:2000]}))
        return out, is_error

    # ------------------------------------------------------------------ vòng đời 1 lượt chạy
    async def run(self, messages: list[dict[str, Any]], ctx: RunContext | None = None,
                  emit: Emitter = null_emitter) -> RunResult:
        ctx = ctx or RunContext()
        started = time.monotonic()
        await emit(Event(RUN_STARTED, {"agent": self.m.name, "run_id": ctx.run_id, "kind": ctx.kind,
                                       "engine": self.engine_name, "resumed": ctx.resume is not None}))
        try:
            async with asyncio.timeout(self.m.limits.task_timeout_s):
                result = await self._run(messages, ctx, emit)
        except asyncio.CancelledError:
            raise
        except BaseException as exc:  # noqa: BLE001 - gồm cả ExceptionGroup
            if isinstance(exc, (KeyboardInterrupt, SystemExit)):
                raise
            if _find(exc, RunCancelled) is not None:
                result = RunResult("cancelled", "", 0, {}, error="Bị huỷ bởi người dùng")
            elif _find(exc, TimeoutError) is not None:
                result = RunResult("failed", "", 0, {}, error=f"Quá thời gian {self.m.limits.task_timeout_s}s")
            else:
                leaf = _leaf(exc)
                result = RunResult("failed", "", 0, {}, error=f"{type(leaf).__name__}: {leaf}")
        result.duration_ms = int((time.monotonic() - started) * 1000)
        if result.status == "failed":
            await emit(Event(ERROR, {"error": result.error}))
        if result.status == "waiting_input":
            await emit(Event(INTERRUPT, result.interrupt or {}))
        await emit(Event(RUN_FINISHED, {"status": result.status, "output": result.output, "error": result.error,
                                        "steps": result.steps, "usage": result.usage,
                                        "duration_ms": result.duration_ms, "interrupt": result.interrupt,
                                        "engine": self.engine_name}))
        return result

    async def _run(self, messages: list[dict[str, Any]], ctx: RunContext, emit: Emitter) -> RunResult:
        raise NotImplementedError
