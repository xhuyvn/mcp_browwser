"""Client gọi Control Plane (backend) — đăng ký agent, heartbeat, báo cáo tiến độ/kết quả task."""
from __future__ import annotations

import asyncio
import logging
from typing import Any

import httpx

log = logging.getLogger("agent.control_plane")


class ControlPlane:
    def __init__(self, base_url: str, internal_token: str, agent_name: str):
        self.agent_name = agent_name
        self.http = httpx.AsyncClient(
            base_url=base_url.rstrip("/"),
            headers={"X-Internal-Token": internal_token, "X-Agent-Name": agent_name},
            timeout=httpx.Timeout(15.0),
        )

    async def _request(self, method: str, url: str, retries: int = 3, **kw: Any) -> httpx.Response:
        delay = 0.5
        for attempt in range(1, retries + 1):
            try:
                resp = await self.http.request(method, url, **kw)
                if resp.status_code < 500:
                    return resp
                log.warning("%s %s -> %s", method, url, resp.status_code)
            except httpx.HTTPError as exc:
                log.warning("%s %s lỗi (lần %d): %s", method, url, attempt, exc)
                if attempt == retries:
                    raise
            await asyncio.sleep(delay)
            delay *= 2
        return resp  # type: ignore[possibly-undefined]

    async def register(self, payload: dict[str, Any]) -> None:
        resp = await self._request("POST", "/internal/agents/register", json=payload)
        resp.raise_for_status()

    async def heartbeat(self, payload: dict[str, Any] | None = None) -> bool:
        resp = await self._request("POST", f"/internal/agents/{self.agent_name}/heartbeat", json=payload or {})
        return resp.status_code == 200  # 404 => cần đăng ký lại

    async def start_task(self, task_id: str) -> dict[str, Any] | None:
        """Đánh dấu task running; trả về task (input...) hoặc None nếu task không còn ở trạng thái chạy được."""
        resp = await self._request("POST", f"/internal/tasks/{task_id}/start")
        if resp.status_code == 200:
            return resp.json()
        log.info("Bỏ qua task %s (start -> %s)", task_id, resp.status_code)
        return None

    async def post_events(self, task_id: str, events: list[dict[str, Any]]) -> None:
        try:
            await self._request("POST", f"/internal/tasks/{task_id}/events", retries=2, json={"events": events})
        except Exception as exc:  # noqa: BLE001 - không để lỗi báo cáo làm hỏng task
            log.warning("Không gửi được event của task %s: %s", task_id, exc)

    async def complete_task(self, task_id: str, status: str, result: str, error: str | None,
                            usage: dict[str, Any] | None = None, steps: int = 0, duration_ms: int = 0,
                            interrupt: dict[str, Any] | None = None) -> None:
        """status: succeeded | failed | cancelled | waiting_input (kèm interrupt = nội dung cần người duyệt)."""
        await self._request("POST", f"/internal/tasks/{task_id}/complete", retries=5, json={
            "status": status, "result": result, "error": error, "usage": usage or {},
            "steps": steps, "duration_ms": duration_ms, "interrupt": interrupt,
        })

    async def aclose(self) -> None:
        await self.http.aclose()
