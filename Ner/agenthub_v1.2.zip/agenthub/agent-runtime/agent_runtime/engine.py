"""Native engine (mặc định) — vòng lặp ReAct với native tool calling, chạy trên mọi API OpenAI-compatible.

Ưu điểm: không phụ thuộc framework, ít tầng trừu tượng, dễ debug. Các engine khác nằm trong
`agent_runtime/engines/` và dùng chung BaseEngine (xem docs/ENGINES.md).
"""
from __future__ import annotations

import asyncio
from typing import Any

from .engine_base import (FINAL_ANSWER_PROMPT, BaseEngine, RunCancelled, RunContext,  # noqa: F401 - re-export
                          RunResult, merge_usage)
from .events import MESSAGE, STEP, Emitter, Event


class NativeEngine(BaseEngine):
    engine_name = "native"

    async def _run(self, messages: list[dict[str, Any]], ctx: RunContext, emit: Emitter) -> RunResult:
        usage: dict[str, int] = {}
        async with self.mcp.connect(emit) as toolbox:
            specs = self.collect_tools(toolbox)
            schemas = [s.openai_schema() for s in specs.values()] or None
            convo: list[dict[str, Any]] = [{"role": "system", "content": self.system_prompt(ctx)}, *messages]
            token_cb = self.token_callback(ctx, emit)
            max_steps = self.m.limits.max_steps
            parallel = self.m.limits.parallel_tool_calls

            for step in range(1, max_steps + 1):
                await self.check_cancel(ctx)
                await emit(Event(STEP, {"step": step, "max_steps": max_steps}))
                resp = await self.llm.chat(convo, schemas, token_cb, parallel)
                merge_usage(usage, resp.usage)
                msg = resp.as_message()
                if msg.get("content") is None:
                    msg["content"] = ""
                convo.append(msg)

                if not resp.tool_calls:
                    return RunResult("succeeded", resp.content.strip(), step, usage, messages=convo)

                if resp.content.strip():
                    await emit(Event(MESSAGE, {"content": resp.content.strip(), "step": step}))
                calls = [self.exec_tool(tc.name, tc.parsed_args(), tc.id, specs, emit, step) for tc in resp.tool_calls]
                outputs = await asyncio.gather(*calls) if parallel else [await c for c in calls]
                for tc, (out, _err) in zip(resp.tool_calls, outputs):
                    convo.append({"role": "tool", "tool_call_id": tc.id, "content": out})

            # Hết bước: yêu cầu model tổng hợp câu trả lời cuối cùng, không dùng tool
            convo.append({"role": "user", "content": FINAL_ANSWER_PROMPT})
            resp = await self.llm.chat(convo, None, token_cb)
            merge_usage(usage, resp.usage)
            convo.append({"role": "assistant", "content": resp.content})
            return RunResult("succeeded", resp.content.strip(), max_steps, usage, messages=convo)


# Tên cũ (v1.0) — giữ để tương thích
AgentEngine = NativeEngine
