"""HTTP API của mỗi agent container.

GET  /health                         -> liveness
GET  /.well-known/agent-card.json    -> Agent Card (tương thích tinh thần A2A) để discovery
GET  /v1/tools                       -> danh sách tool/skill/MCP đang dùng
POST /v1/chat                        -> chat (SSE stream các Event, hoặc JSON nếu stream=false)
"""
from __future__ import annotations

import asyncio
import json
import os
from typing import TYPE_CHECKING, Any, AsyncIterator, Literal

from fastapi import Depends, FastAPI, Header, HTTPException
from fastapi.responses import StreamingResponse
from pydantic import BaseModel, Field

from .engine_base import RunContext
from .events import Event

if TYPE_CHECKING:
    from .main import AgentRuntime


class ChatMessage(BaseModel):
    role: Literal["user", "assistant", "system"]
    content: str


class ChatRequest(BaseModel):
    messages: list[ChatMessage] = Field(min_length=1)
    stream: bool = True
    conversation_id: str | None = None
    user: str | None = None


def sse(event: dict[str, Any]) -> str:
    return f"event: {event['type']}\ndata: {json.dumps(event, ensure_ascii=False, default=str)}\n\n"


def create_app(rt: "AgentRuntime") -> FastAPI:
    app = FastAPI(title=f"Agent {rt.manifest.name}", version=rt.manifest.version, lifespan=rt.lifespan)
    token = os.environ.get("AGENT_API_TOKEN", "")

    async def auth(x_agent_token: str | None = Header(default=None)) -> None:
        if token and x_agent_token != token:
            raise HTTPException(401, "invalid agent token")

    @app.get("/health")
    async def health() -> dict[str, Any]:
        return {"status": "ok", "agent": rt.manifest.name, "version": rt.manifest.version}

    @app.get("/.well-known/agent-card.json")
    async def agent_card() -> dict[str, Any]:
        return rt.agent_card()

    @app.get("/v1/tools", dependencies=[Depends(auth)])
    async def tools() -> dict[str, Any]:
        return rt.describe_tools()

    @app.post("/v1/chat", dependencies=[Depends(auth)])
    async def chat(req: ChatRequest):
        messages = [m.model_dump() for m in req.messages if m.role != "system"]
        ctx = RunContext(kind="chat", user=req.user, stream_tokens=req.stream,
                         extra={"conversation_id": req.conversation_id})
        if not req.stream:
            result = await rt.engine.run(messages, ctx)
            return {"status": result.status, "output": result.output, "error": result.error,
                    "steps": result.steps, "usage": result.usage, "engine": rt.engine.engine_name}

        queue: asyncio.Queue[Event | None] = asyncio.Queue()

        async def emit(ev: Event) -> None:
            await queue.put(ev)

        async def runner() -> None:
            try:
                await rt.engine.run(messages, ctx, emit)
            finally:
                await queue.put(None)

        async def gen() -> AsyncIterator[str]:
            task = asyncio.create_task(runner())
            try:
                while True:
                    try:
                        ev = await asyncio.wait_for(queue.get(), timeout=15)
                    except asyncio.TimeoutError:
                        yield ": keep-alive\n\n"
                        continue
                    if ev is None:
                        break
                    yield sse(ev.to_dict())
            finally:
                if not task.done():
                    task.cancel()

        return StreamingResponse(gen(), media_type="text/event-stream",
                                 headers={"Cache-Control": "no-cache", "X-Accel-Buffering": "no"})

    return app
