"""Agent manifest (agent.yaml) loading with ${ENV:-default} interpolation.

Mỗi agent được mô tả hoàn toàn bằng 1 file agent.yaml + thư mục skills/ + tools/.
Runtime dùng chung 1 image, chỉ khác manifest => thêm agent mới không cần viết code.
"""
from __future__ import annotations

import os
import re
from pathlib import Path
from typing import Any, Literal

import yaml
from pydantic import BaseModel, Field, field_validator

_ENV_PATTERN = re.compile(r"\$\{([A-Za-z_][A-Za-z0-9_]*)(?::-([^}]*))?\}")

PROVIDER_PRESETS: dict[str, dict[str, Any]] = {
    # Ollama expose OpenAI-compatible API tại /v1
    "ollama": {"base_url": "http://ollama:11434/v1", "api_key": "ollama"},
    "openrouter": {
        "base_url": "https://openrouter.ai/api/v1",
        "extra_headers": {"HTTP-Referer": "https://agenthub.local", "X-Title": "AgentHub"},
    },
    "openai": {"base_url": "https://api.openai.com/v1"},
    # LiteLLM proxy / vLLM / LM Studio / llama.cpp server ... => openai_compat + base_url
    "openai_compat": {},
}


def interpolate_env(value: Any) -> Any:
    """Thay ${VAR} / ${VAR:-default} trong mọi chuỗi của cấu trúc YAML."""
    if isinstance(value, str):
        def repl(m: re.Match) -> str:
            return os.environ.get(m.group(1)) or (m.group(2) or "")
        return _ENV_PATTERN.sub(repl, value)
    if isinstance(value, list):
        return [interpolate_env(v) for v in value]
    if isinstance(value, dict):
        return {k: interpolate_env(v) for k, v in value.items()}
    return value


class ModelConfig(BaseModel):
    provider: Literal["ollama", "openrouter", "openai", "openai_compat"] | str = ""
    base_url: str = ""
    api_key: str = ""
    model: str = ""
    temperature: float = 0.2
    max_tokens: int | None = None
    timeout_s: float = 120
    stream: bool = True
    fallback_models: list[str] = Field(default_factory=list)
    extra_headers: dict[str, str] = Field(default_factory=dict)
    extra_body: dict[str, Any] = Field(default_factory=dict)

    def resolved(self) -> "ModelConfig":
        """Điền giá trị mặc định từ biến môi trường LLM_* và preset của provider.

        - provider trống hoặc trùng LLM_PROVIDER  => dùng LLM_BASE_URL / LLM_API_KEY / LLM_MODEL
        - provider khác LLM_PROVIDER (vd. orchestrator dùng openrouter, agent khác dùng ollama)
          => dùng preset của provider + <PROVIDER>_API_KEY (vd. OPENROUTER_API_KEY)
        """
        env_provider = os.environ.get("LLM_PROVIDER", "")
        provider = self.provider or env_provider or "openai_compat"
        same_as_env = (not self.provider) or provider == env_provider
        preset = PROVIDER_PRESETS.get(provider, {})
        provider_key = os.environ.get(f"{provider.upper()}_API_KEY", "")
        if same_as_env:
            base_url = self.base_url or os.environ.get("LLM_BASE_URL") or preset.get("base_url", "")
            api_key = self.api_key or os.environ.get("LLM_API_KEY") or provider_key or preset.get("api_key", "")
            model = self.model or os.environ.get("LLM_MODEL", "")
        else:
            base_url = self.base_url or preset.get("base_url", "")
            api_key = self.api_key or provider_key or preset.get("api_key", "")
            model = self.model
        api_key = api_key or "not-needed"
        if not base_url:
            raise ValueError("Thiếu base_url cho model (đặt model.base_url hoặc LLM_BASE_URL)")
        if not model:
            raise ValueError("Thiếu tên model (đặt model.model hoặc LLM_MODEL)")
        headers = {**preset.get("extra_headers", {}), **self.extra_headers}
        fallbacks = self.fallback_models or [
            m.strip() for m in os.environ.get("LLM_FALLBACK_MODELS", "").split(",") if m.strip()
        ] if same_as_env else self.fallback_models
        return self.model_copy(update={
            "provider": provider, "base_url": base_url.rstrip("/"), "api_key": api_key,
            "model": model, "extra_headers": headers, "fallback_models": fallbacks,
        })


class MCPServerConfig(BaseModel):
    name: str
    url: str
    transport: Literal["streamable_http", "sse"] = "streamable_http"
    headers: dict[str, str] = Field(default_factory=dict)
    allowed_tools: list[str] | None = None   # None = cho phép tất cả tool của server
    required: bool = False                   # True => run thất bại nếu không kết nối được
    timeout_s: float = 30                    # timeout kết nối + list_tools
    read_timeout_s: float = 600              # timeout đọc cho tool chạy lâu (vd. wait_for_task)

    @field_validator("name")
    @classmethod
    def _name_ok(cls, v: str) -> str:
        if not re.fullmatch(r"[a-zA-Z0-9_-]{1,32}", v):
            raise ValueError("mcp server name chỉ gồm a-z, 0-9, _, - (<=32 ký tự)")
        return v


class LimitsConfig(BaseModel):
    max_steps: int = 10
    task_timeout_s: float = 600
    max_tool_output_chars: int = 12000
    concurrency: int = 2
    parallel_tool_calls: bool = True


class EngineConfig(BaseModel):
    """Chọn engine chạy vòng lặp agent (xem docs/ENGINES.md).

    type: native | pydantic_ai | langgraph | "<module>:<Class>" (engine tự viết)
    """
    type: str = "native"
    # --- pydantic_ai ---
    output_schema: dict[str, Any] | None = None          # JSON schema => kết quả có cấu trúc (JSON)
    # --- langgraph ---
    checkpointer: Literal["memory", "postgres", "none"] = "memory"
    checkpoint_url: str = ""                              # postgresql://... (psycopg 3)
    approval_required_tools: list[str] = Field(default_factory=list)   # tool cần con người phê duyệt
    # --- tuỳ chọn riêng của từng engine ---
    options: dict[str, Any] = Field(default_factory=dict)

    @field_validator("type")
    @classmethod
    def _type_default(cls, v: str) -> str:
        return (v or "native").strip()

    @field_validator("checkpointer", mode="before")
    @classmethod
    def _cp_default(cls, v: Any) -> Any:
        return v or "memory"


class AgentManifest(BaseModel):
    name: str
    version: str = "0.1.0"
    description: str = ""
    system_prompt: str = "You are a helpful assistant."
    model: ModelConfig = Field(default_factory=ModelConfig)
    engine: EngineConfig = Field(default_factory=EngineConfig)
    skills: list[str] | Literal["*"] = "*"
    tools: list[str] = Field(default_factory=list)
    mcp_servers: list[MCPServerConfig] = Field(default_factory=list)
    limits: LimitsConfig = Field(default_factory=LimitsConfig)
    tags: list[str] = Field(default_factory=list)
    language: str = "vi"

    @field_validator("name")
    @classmethod
    def _agent_name(cls, v: str) -> str:
        if not re.fullmatch(r"[a-z][a-z0-9-]{1,40}", v):
            raise ValueError("agent name: chữ thường, số, '-', bắt đầu bằng chữ (2-41 ký tự)")
        return v


def load_manifest(agent_dir: str | Path) -> AgentManifest:
    path = Path(agent_dir) / "agent.yaml"
    raw = yaml.safe_load(path.read_text(encoding="utf-8")) or {}
    return AgentManifest.model_validate(interpolate_env(raw))
