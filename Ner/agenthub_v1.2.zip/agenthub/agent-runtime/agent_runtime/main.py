"""Entry point của Agent Runtime (dùng chung cho mọi agent — khác nhau ở thư mục /agent).

Biến môi trường chính:
  AGENT_DIR            thư mục chứa agent.yaml, skills/, tools/   (mặc định /agent)
  LLM_PROVIDER         ollama | openrouter | openai | openai_compat
  LLM_BASE_URL         ví dụ http://ollama:11434/v1  |  https://openrouter.ai/api/v1
  LLM_API_KEY          API key (Ollama: bất kỳ)
  LLM_MODEL            ví dụ qwen3:8b  |  <model-id>:free trên OpenRouter
  CONTROL_PLANE_URL    http://backend:8000
  INTERNAL_TOKEN       token nội bộ agent <-> backend
  REDIS_URL            redis://redis:6379/0  (bật task worker)
  AGENT_PUBLIC_URL     URL backend dùng để gọi agent (mặc định http://<name>:8000)
"""
from __future__ import annotations

import asyncio
import logging
import os
from contextlib import asynccontextmanager
from pathlib import Path
from typing import Any

import uvicorn

from .config import load_manifest
from .control_plane import ControlPlane
from .engines import create_engine
from .llm import LLMClient
from .mcp_manager import MCPManager
from .server import create_app
from .skills import SkillLibrary
from .tools import load_custom_tools, select_tools
from .worker import TaskWorker

logging.basicConfig(level=os.environ.get("LOG_LEVEL", "INFO"),
                    format="%(asctime)s %(levelname)s %(name)s: %(message)s")
log = logging.getLogger("agent.main")


class AgentRuntime:
    def __init__(self, agent_dir: str | Path):
        self.agent_dir = Path(agent_dir)
        self.manifest = load_manifest(self.agent_dir)
        n_custom = load_custom_tools(self.agent_dir / "tools")
        self.local_tools = select_tools(self.manifest.tools)
        self.skills = SkillLibrary(self.agent_dir / "skills", self.manifest.skills)
        self.mcp = MCPManager(self.manifest.mcp_servers)
        self.llm = LLMClient(self.manifest.model)
        self.engine = create_engine(self.manifest, self.llm, self.local_tools, self.skills, self.mcp)
        self.public_url = os.environ.get("AGENT_PUBLIC_URL", f"http://{self.manifest.name}:8000")
        cp_url = os.environ.get("CONTROL_PLANE_URL", "")
        self.cp = ControlPlane(cp_url, os.environ.get("INTERNAL_TOKEN", ""), self.manifest.name) if cp_url else None
        self.worker: TaskWorker | None = None
        log.info("Agent %s v%s | engine=%s | model=%s @ %s | tools=%d (custom files=%d) | skills=%d | mcp=%d",
                 self.manifest.name, self.manifest.version, self.engine.engine_name, self.llm.cfg.model, self.llm.cfg.base_url,
                 len(self.local_tools), n_custom, len(self.skills.skills), len(self.manifest.mcp_servers))

    # ------------------------------------------------------------ metadata
    def agent_card(self) -> dict[str, Any]:
        m = self.manifest
        return {
            "protocolVersion": "0.3.0",
            "name": m.name,
            "description": m.description,
            "version": m.version,
            "url": self.public_url,
            "capabilities": {"streaming": True, "pushNotifications": False,
                             "humanApproval": bool(m.engine.approval_required_tools)},
            "defaultInputModes": ["text/plain"],
            "defaultOutputModes": ["text/markdown"],
            "skills": [{"id": s["name"], "name": s["name"], "description": s["description"], "tags": m.tags}
                       for s in self.skills.summary()],
        }

    def describe_tools(self) -> dict[str, Any]:
        return {
            "engine": self.engine.engine_name,
            "local": [{"name": t.name, "group": t.group, "description": t.description} for t in self.local_tools],
            "skills": self.skills.summary(),
            "mcp_servers": self.mcp.describe(),
        }

    def registration_payload(self) -> dict[str, Any]:
        m = self.manifest
        return {
            "name": m.name, "version": m.version, "description": m.description, "tags": m.tags,
            "endpoint": self.public_url, "card": self.agent_card(),
            # thông tin engine đặt trong "model" để không phải đổi schema bảng agents
            "model": {"provider": self.llm.cfg.provider, "model": self.llm.cfg.model,
                      "fallback_models": self.llm.cfg.fallback_models,
                      "engine": {"type": self.engine.engine_name, "checkpointer": m.engine.checkpointer,
                                 "approval_required_tools": m.engine.approval_required_tools,
                                 "structured_output": bool(m.engine.output_schema)}},
            "skills": [{"name": s["name"], "description": s["description"]} for s in self.skills.summary()],
            "tools": [t.name for t in self.local_tools],
            "mcp_servers": self.mcp.describe(),
            "limits": m.limits.model_dump(),
        }

    # ------------------------------------------------------------ lifecycle
    async def _control_loop(self) -> None:
        assert self.cp
        registered = False
        beats = 0
        while True:
            try:
                mcp_down = any(not s.connected for s in self.mcp.last_status.values())
                # probe MCP: khi chưa đăng ký, khi có server chưa kết nối, hoặc ~5 phút/lần
                if not registered or mcp_down or beats % 20 == 0:
                    await self.mcp.probe()
                if not registered:
                    await self.cp.register(self.registration_payload())
                    registered = True
                    log.info("Đã đăng ký với control plane")
                elif not await self.cp.heartbeat({"mcp_servers": self.mcp.describe()}):
                    registered = False
                    continue
                beats += 1
            except Exception as exc:  # noqa: BLE001
                registered = False
                log.warning("Control plane chưa sẵn sàng: %s", exc)
            await asyncio.sleep(15)

    @asynccontextmanager
    async def lifespan(self, _app):
        bg: list[asyncio.Task] = []
        if self.cp:
            bg.append(asyncio.create_task(self._control_loop()))
            redis_url = os.environ.get("REDIS_URL")
            if redis_url:
                self.worker = TaskWorker(self.engine, self.cp, redis_url, self.manifest.name,
                                         self.manifest.limits.concurrency, self.manifest.limits.task_timeout_s)
                bg.append(asyncio.create_task(self.worker.run_forever()))
        try:
            yield
        finally:
            for t in bg:
                t.cancel()
            if self.worker:
                await self.worker.stop()
            if self.cp:
                await self.cp.aclose()


def main() -> None:
    rt = AgentRuntime(os.environ.get("AGENT_DIR", "/agent"))
    uvicorn.run(create_app(rt), host="0.0.0.0", port=int(os.environ.get("PORT", "8000")),
                log_level=os.environ.get("LOG_LEVEL", "info").lower())


if __name__ == "__main__":
    main()
