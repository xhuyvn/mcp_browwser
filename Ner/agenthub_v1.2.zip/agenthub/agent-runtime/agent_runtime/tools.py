"""Local tools: decorator @tool, registry, builtin tools và nạp custom tools từ /agent/tools/*.py.

Ví dụ custom tool (agents/<name>/tools/my_tools.py):

    from agent_runtime.tools import tool

    @tool(description="Đếm số từ trong văn bản")
    def word_count(text: str) -> int:
        return len(text.split())

Rồi khai báo trong agent.yaml:  tools: ["custom.word_count"]  (hoặc "custom.*")
"""
from __future__ import annotations

import ast
import asyncio
import fnmatch
import importlib.util
import inspect
import json
import logging
import math
import operator
import sys
from dataclasses import dataclass, field
from datetime import datetime
from pathlib import Path
from typing import Any, Callable, get_type_hints
from zoneinfo import ZoneInfo

from pydantic import BaseModel, ConfigDict, create_model

log = logging.getLogger("agent.tools")


@dataclass
class ToolSpec:
    name: str
    description: str
    parameters: dict[str, Any]
    func: Callable[..., Any]
    group: str = "custom"          # builtin | custom | skill | mcp
    args_model: type[BaseModel] | None = None
    meta: dict[str, Any] = field(default_factory=dict)

    @property
    def qualified_name(self) -> str:
        return f"{self.group}.{self.name}"

    def openai_schema(self) -> dict[str, Any]:
        return {
            "type": "function",
            "function": {"name": self.name, "description": self.description[:1024], "parameters": self.parameters},
        }

    async def invoke(self, args: dict[str, Any]) -> Any:
        if self.args_model is not None:
            args = self.args_model.model_validate(args).model_dump()
        result = self.func(**args)
        if inspect.isawaitable(result):
            return await result
        return result


def _args_model(func: Callable[..., Any]) -> type[BaseModel]:
    sig = inspect.signature(func)
    hints = get_type_hints(func, include_extras=True)
    fields: dict[str, Any] = {}
    for pname, p in sig.parameters.items():
        if p.kind in (p.VAR_POSITIONAL, p.VAR_KEYWORD):
            continue
        ann = hints.get(pname, str)
        default = ... if p.default is inspect.Parameter.empty else p.default
        fields[pname] = (ann, default)
    return create_model(f"{func.__name__}_Args", __config__=ConfigDict(extra="ignore"), **fields)


def _clean_schema(schema: dict[str, Any]) -> dict[str, Any]:
    schema = dict(schema)
    schema.pop("title", None)
    for prop in schema.get("properties", {}).values():
        if isinstance(prop, dict):
            prop.pop("title", None)
    schema.setdefault("type", "object")
    schema.setdefault("properties", {})
    return schema


_GLOBAL: dict[str, ToolSpec] = {}


def tool(name: str | None = None, description: str | None = None, group: str = "custom"):
    """Decorator đăng ký 1 Python function thành tool (schema sinh từ type hints)."""
    def deco(func: Callable[..., Any]) -> Callable[..., Any]:
        model = _args_model(func)
        spec = ToolSpec(
            name=name or func.__name__,
            description=(description or inspect.getdoc(func) or func.__name__).strip(),
            parameters=_clean_schema(model.model_json_schema()),
            func=func,
            group=group,
            args_model=model,
        )
        _GLOBAL[spec.qualified_name] = spec
        return func
    return deco


def make_tool(name: str, description: str, parameters: dict[str, Any], func: Callable[..., Any],
              group: str, meta: dict[str, Any] | None = None) -> ToolSpec:
    """Tạo ToolSpec với JSON schema có sẵn (dùng cho MCP và skill tools)."""
    return ToolSpec(name=name, description=description, parameters=_clean_schema(parameters),
                    func=func, group=group, meta=meta or {})


def select_tools(patterns: list[str]) -> list[ToolSpec]:
    """Chọn tool theo pattern 'builtin.current_time', 'custom.*', '*'."""
    chosen: dict[str, ToolSpec] = {}
    for pat in patterns:
        matched = [s for q, s in _GLOBAL.items() if fnmatch.fnmatch(q, pat)]
        if not matched:
            log.warning("Không tìm thấy tool khớp pattern %s", pat)
        for s in matched:
            chosen[s.name] = s
    return list(chosen.values())


def load_custom_tools(tools_dir: str | Path) -> int:
    """Import mọi file *.py trong thư mục tools của agent (để chạy decorator @tool)."""
    d = Path(tools_dir)
    if not d.is_dir():
        return 0
    count = 0
    for f in sorted(d.glob("*.py")):
        if f.name.startswith("_"):
            continue
        mod_name = f"agent_custom_tools.{f.stem}"
        spec = importlib.util.spec_from_file_location(mod_name, f)
        if spec and spec.loader:
            module = importlib.util.module_from_spec(spec)
            sys.modules[mod_name] = module
            spec.loader.exec_module(module)
            count += 1
    return count


# ----------------------------- builtin tools -----------------------------
_OPS = {
    ast.Add: operator.add, ast.Sub: operator.sub, ast.Mult: operator.mul, ast.Div: operator.truediv,
    ast.FloorDiv: operator.floordiv, ast.Mod: operator.mod, ast.Pow: operator.pow,
    ast.USub: operator.neg, ast.UAdd: operator.pos,
}
_FUNCS = {k: getattr(math, k) for k in ("sqrt", "log", "log10", "exp", "sin", "cos", "tan", "floor", "ceil")}
_FUNCS.update({"abs": abs, "round": round, "min": min, "max": max})


def _safe_eval(node: ast.AST) -> Any:
    if isinstance(node, ast.Expression):
        return _safe_eval(node.body)
    if isinstance(node, ast.Constant) and isinstance(node.value, (int, float)):
        return node.value
    if isinstance(node, ast.BinOp) and type(node.op) in _OPS:
        if isinstance(node.op, ast.Pow) and abs(_safe_eval(node.right)) > 100:
            raise ValueError("số mũ quá lớn")
        return _OPS[type(node.op)](_safe_eval(node.left), _safe_eval(node.right))
    if isinstance(node, ast.UnaryOp) and type(node.op) in _OPS:
        return _OPS[type(node.op)](_safe_eval(node.operand))
    if isinstance(node, ast.Call) and isinstance(node.func, ast.Name) and node.func.id in _FUNCS:
        return _FUNCS[node.func.id](*[_safe_eval(a) for a in node.args])
    if isinstance(node, ast.Name) and node.id in ("pi", "e"):
        return getattr(math, node.id)
    raise ValueError("biểu thức không được hỗ trợ")


@tool(name="calculator", group="builtin")
def calculator(expression: str) -> str:
    """Tính toán biểu thức số học an toàn, ví dụ '(12.5*4)/3 + sqrt(16)'."""
    return str(_safe_eval(ast.parse(expression, mode="eval")))


@tool(name="current_time", group="builtin")
def current_time(timezone: str = "Asia/Ho_Chi_Minh") -> str:
    """Trả về ngày giờ hiện tại (ISO 8601) theo múi giờ IANA."""
    return datetime.now(ZoneInfo(timezone)).isoformat(timespec="seconds")


@tool(name="json_format", group="builtin")
def json_format(data: str) -> str:
    """Kiểm tra và định dạng lại một chuỗi JSON (pretty print)."""
    return json.dumps(json.loads(data), ensure_ascii=False, indent=2)


async def run_sync(func: Callable[..., Any], *args: Any, **kwargs: Any) -> Any:
    return await asyncio.to_thread(func, *args, **kwargs)
