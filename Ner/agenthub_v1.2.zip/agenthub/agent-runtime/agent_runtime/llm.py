"""LLM client cho mọi endpoint OpenAI-compatible (Ollama, OpenRouter, vLLM, LiteLLM, OpenAI...).

- Hỗ trợ streaming có tool calls (gộp delta theo index).
- Fallback sang model dự phòng khi model chính lỗi / hết quota (hữu ích với model free của OpenRouter).
"""
from __future__ import annotations

import json
import logging
from dataclasses import dataclass, field
from typing import Any, Awaitable, Callable

from openai import AsyncOpenAI

from .config import ModelConfig

log = logging.getLogger("agent.llm")

TokenCallback = Callable[[str], Awaitable[None]]


@dataclass
class ToolCall:
    id: str
    name: str
    arguments: str  # JSON string như OpenAI trả về

    def parsed_args(self) -> dict[str, Any]:
        if not self.arguments:
            return {}
        try:
            val = json.loads(self.arguments)
            return val if isinstance(val, dict) else {"value": val}
        except json.JSONDecodeError:
            return {"__raw__": self.arguments}


@dataclass
class LLMResponse:
    content: str = ""
    tool_calls: list[ToolCall] = field(default_factory=list)
    model: str = ""
    usage: dict[str, int] = field(default_factory=dict)
    finish_reason: str | None = None

    def as_message(self) -> dict[str, Any]:
        msg: dict[str, Any] = {"role": "assistant", "content": self.content or None}
        if self.tool_calls:
            msg["tool_calls"] = [
                {"id": tc.id, "type": "function", "function": {"name": tc.name, "arguments": tc.arguments or "{}"}}
                for tc in self.tool_calls
            ]
        return msg


class LLMClient:
    def __init__(self, cfg: ModelConfig, client: Any | None = None):
        self.cfg = cfg.resolved() if client is None else cfg
        self.client = client or AsyncOpenAI(
            base_url=self.cfg.base_url,
            api_key=self.cfg.api_key,
            timeout=self.cfg.timeout_s,
            max_retries=2,
            default_headers=self.cfg.extra_headers or None,
        )

    async def chat(
        self,
        messages: list[dict[str, Any]],
        tools: list[dict[str, Any]] | None = None,
        on_token: TokenCallback | None = None,
        parallel_tool_calls: bool = True,
    ) -> LLMResponse:
        models = [self.cfg.model, *self.cfg.fallback_models]
        last_exc: Exception | None = None
        for model in models:
            try:
                return await self._chat_once(model, messages, tools, on_token, parallel_tool_calls)
            except Exception as exc:  # noqa: BLE001 - chuyển sang model dự phòng
                last_exc = exc
                log.warning("LLM model %s lỗi: %s", model, exc)
        raise RuntimeError(f"Tất cả model đều lỗi: {last_exc}") from last_exc

    async def _chat_once(self, model, messages, tools, on_token, parallel_tool_calls) -> LLMResponse:
        kwargs: dict[str, Any] = {
            "model": model,
            "messages": messages,
            "temperature": self.cfg.temperature,
        }
        if self.cfg.max_tokens:
            kwargs["max_tokens"] = self.cfg.max_tokens
        if tools:
            kwargs["tools"] = tools
            kwargs["tool_choice"] = "auto"
            if not parallel_tool_calls:
                kwargs["parallel_tool_calls"] = False
        if self.cfg.extra_body:
            kwargs["extra_body"] = self.cfg.extra_body

        if not self.cfg.stream:
            resp = await self.client.chat.completions.create(**kwargs)
            choice = resp.choices[0]
            msg = choice.message
            calls = [
                ToolCall(id=tc.id or f"call_{i}", name=tc.function.name, arguments=tc.function.arguments or "{}")
                for i, tc in enumerate(msg.tool_calls or [])
            ]
            usage = resp.usage.model_dump() if getattr(resp, "usage", None) else {}
            return LLMResponse(msg.content or "", calls, resp.model or model, usage, choice.finish_reason)

        # ---- streaming: gộp content + tool_call deltas ----
        stream = await self.client.chat.completions.create(**kwargs, stream=True)
        content_parts: list[str] = []
        calls: dict[int, dict[str, str]] = {}
        finish_reason = None
        usage: dict[str, int] = {}
        async for chunk in stream:
            if getattr(chunk, "usage", None):
                usage = chunk.usage.model_dump()
            if not chunk.choices:
                continue
            choice = chunk.choices[0]
            delta = choice.delta
            if choice.finish_reason:
                finish_reason = choice.finish_reason
            if delta is None:
                continue
            if delta.content:
                content_parts.append(delta.content)
                if on_token:
                    await on_token(delta.content)
            for tc in delta.tool_calls or []:
                idx = tc.index if tc.index is not None else len(calls)
                slot = calls.setdefault(idx, {"id": "", "name": "", "arguments": ""})
                if tc.id:
                    slot["id"] = tc.id
                if tc.function is not None:
                    if tc.function.name:
                        slot["name"] += tc.function.name
                    if tc.function.arguments:
                        slot["arguments"] += tc.function.arguments
        tool_calls = [
            ToolCall(id=v["id"] or f"call_{k}", name=v["name"], arguments=v["arguments"] or "{}")
            for k, v in sorted(calls.items()) if v["name"]
        ]
        return LLMResponse("".join(content_parts), tool_calls, model, usage, finish_reason)
