"""Task worker: tiêu thụ task từ Redis Streams (consumer group) => scale ngang bằng cách tăng replicas.

- Stream:  agenthub:tasks:<agent_name>      group: workers
- Huỷ:     key agenthub:cancel:<task_id>     (backend đặt khi người dùng bấm Cancel)
- At-least-once: message chỉ ACK sau khi báo complete; message treo quá lâu sẽ được XAUTOCLAIM.
  Backend /start là idempotent-guard: task đã kết thúc => 409 => worker bỏ qua.
"""
from __future__ import annotations

import asyncio
import logging
import os
import socket
import time
from typing import Any

import redis.asyncio as aioredis
from redis.exceptions import ResponseError

from .control_plane import ControlPlane
from .engine_base import BaseEngine, RunContext
from .events import TOKEN, Event

log = logging.getLogger("agent.worker")

GROUP = "workers"


class TaskWorker:
    def __init__(self, engine: BaseEngine, cp: ControlPlane, redis_url: str, agent_name: str,
                 concurrency: int = 2, task_timeout_s: float = 600):
        self.engine = engine
        self.cp = cp
        self.r = aioredis.from_url(redis_url, decode_responses=True)
        self.stream = f"agenthub:tasks:{agent_name}"
        self.consumer = f"{socket.gethostname()}-{os.getpid()}"
        self.sem = asyncio.Semaphore(max(1, concurrency))
        self.claim_idle_ms = int(task_timeout_s * 1000 * 1.5)
        self._stopping = False
        self._inflight: set[asyncio.Task] = set()

    async def _ensure_group(self) -> None:
        try:
            await self.r.xgroup_create(self.stream, GROUP, id="0", mkstream=True)
        except ResponseError as exc:
            if "BUSYGROUP" not in str(exc):
                raise

    async def run_forever(self) -> None:
        while True:
            try:
                await self._ensure_group()
                break
            except Exception as exc:  # noqa: BLE001
                log.warning("Chờ Redis... %s", exc)
                await asyncio.sleep(3)
        log.info("Worker %s lắng nghe %s", self.consumer, self.stream)
        last_claim = 0.0
        while not self._stopping:
            await self.sem.acquire()
            try:
                entries: list[tuple[str, dict[str, Any]]] = []
                if time.monotonic() - last_claim > 60:
                    last_claim = time.monotonic()
                    claimed = await self.r.xautoclaim(self.stream, GROUP, self.consumer,
                                                      min_idle_time=self.claim_idle_ms, start_id="0-0", count=1)
                    entries = list(claimed[1]) if claimed and len(claimed) > 1 else []
                if not entries:
                    resp = await self.r.xreadgroup(GROUP, self.consumer, {self.stream: ">"}, count=1, block=5000)
                    for _stream, items in resp or []:
                        entries.extend(items)
            except asyncio.CancelledError:
                self.sem.release()
                raise
            except Exception as exc:  # noqa: BLE001
                self.sem.release()
                log.warning("Lỗi đọc stream: %s", exc)
                await asyncio.sleep(2)
                continue
            if not entries:
                self.sem.release()
                continue
            msg_id, fields = entries[0]
            t = asyncio.create_task(self._handle(msg_id, fields or {}))
            self._inflight.add(t)
            t.add_done_callback(self._inflight.discard)

    async def _handle(self, msg_id: str, fields: dict[str, Any]) -> None:
        task_id = fields.get("task_id", "")
        try:
            task = await self.cp.start_task(task_id) if task_id else None
            if not task:
                return
            cancel_key = f"agenthub:cancel:{task_id}"

            async def is_cancelled() -> bool:
                return bool(await self.r.exists(cancel_key))

            async def emit(ev: Event) -> None:
                if ev.type == TOKEN:
                    return  # task không stream token, chỉ gửi các mốc quan trọng
                await self.cp.post_events(task_id, [ev.to_dict()])

            meta = task.get("metadata") or {}
            ctx = RunContext(kind="task", task_id=task_id, parent_task_id=task.get("parent_id"),
                             user=task.get("created_by"), is_cancelled=is_cancelled,
                             resume=meta.get("resume"))          # có giá trị khi người dùng vừa duyệt/từ chối
            messages = [{"role": "user", "content": task["input"]}]
            result = await self.engine.run(messages, ctx, emit)
            await self.cp.complete_task(task_id, result.status, result.output, result.error,
                                        result.usage, result.steps, result.duration_ms,
                                        interrupt=result.interrupt)
        except Exception as exc:  # noqa: BLE001
            log.exception("Task %s lỗi", task_id)
            try:
                await self.cp.complete_task(task_id, "failed", "", f"{type(exc).__name__}: {exc}")
            except Exception:  # noqa: BLE001
                log.error("Không báo được trạng thái lỗi của task %s", task_id)
        finally:
            try:
                await self.r.xack(self.stream, GROUP, msg_id)
            except Exception as exc:  # noqa: BLE001
                log.warning("XACK lỗi %s: %s", msg_id, exc)
            self.sem.release()

    async def stop(self) -> None:
        self._stopping = True
        if self._inflight:
            await asyncio.wait(self._inflight, timeout=30)
        await self.r.aclose()
