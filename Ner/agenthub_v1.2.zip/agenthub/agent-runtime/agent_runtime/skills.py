"""Skills theo chuẩn Agent Skills (thư mục chứa SKILL.md có YAML frontmatter).

Progressive disclosure:
  1. System prompt chỉ chứa danh mục (name + description) của skill  -> tốn ít token.
  2. Khi cần, model gọi tool `load_skill(name)` để đọc toàn bộ hướng dẫn.
  3. Skill có thể kèm file tài nguyên (templates, checklist...) đọc qua `read_skill_file`.

skills/
  web-research/
    SKILL.md          # ---\nname: web-research\ndescription: ...\n---\n<hướng dẫn>
    references/checklist.md
"""
from __future__ import annotations

import logging
from dataclasses import dataclass, field
from pathlib import Path
from typing import Literal

import yaml

from .tools import ToolSpec, make_tool

log = logging.getLogger("agent.skills")


@dataclass
class Skill:
    name: str
    description: str
    body: str
    path: Path
    allowed_tools: list[str] = field(default_factory=list)

    def resources(self) -> list[str]:
        return sorted(
            str(p.relative_to(self.path)) for p in self.path.rglob("*")
            if p.is_file() and p.name != "SKILL.md"
        )


def parse_skill_md(path: Path) -> Skill:
    text = path.read_text(encoding="utf-8")
    meta: dict = {}
    body = text
    if text.startswith("---"):
        parts = text.split("---", 2)
        if len(parts) == 3:
            meta = yaml.safe_load(parts[1]) or {}
            body = parts[2].strip()
    name = str(meta.get("name") or path.parent.name)
    desc = str(meta.get("description") or "").strip()
    allowed = meta.get("allowed-tools") or meta.get("allowed_tools") or []
    if isinstance(allowed, str):
        allowed = [t.strip() for t in allowed.replace(",", " ").split() if t.strip()]
    return Skill(name=name, description=desc, body=body, path=path.parent, allowed_tools=list(allowed))


class SkillLibrary:
    def __init__(self, skills_dir: str | Path, enabled: list[str] | Literal["*"] = "*"):
        self.skills: dict[str, Skill] = {}
        root = Path(skills_dir)
        if not root.is_dir():
            return
        for md in sorted(root.glob("*/SKILL.md")):
            try:
                sk = parse_skill_md(md)
            except Exception as exc:  # noqa: BLE001
                log.error("Lỗi đọc skill %s: %s", md, exc)
                continue
            if enabled == "*" or sk.name in enabled:
                self.skills[sk.name] = sk

    def catalog_prompt(self) -> str:
        if not self.skills:
            return ""
        lines = ["<available_skills>"]
        for sk in self.skills.values():
            lines.append(f'<skill name="{sk.name}">{sk.description}</skill>')
        lines.append("</available_skills>")
        lines.append(
            "Khi một yêu cầu thuộc phạm vi của skill nào, hãy gọi tool `load_skill` với tên skill đó "
            "TRƯỚC khi thực hiện, rồi làm theo hướng dẫn trong skill."
        )
        return "\n".join(lines)

    def summary(self) -> list[dict]:
        return [{"name": s.name, "description": s.description, "resources": s.resources()} for s in self.skills.values()]

    # --------------------------- tools ---------------------------
    def _load_skill(self, name: str) -> str:
        sk = self.skills.get(name)
        if not sk:
            return f"ERROR: không có skill '{name}'. Skill hiện có: {', '.join(self.skills) or '(trống)'}"
        res = sk.resources()
        extra = f"\n\n[Tài nguyên kèm theo: {', '.join(res)} — đọc bằng read_skill_file]" if res else ""
        return f"# Skill: {sk.name}\n\n{sk.body}{extra}"

    def _read_skill_file(self, skill: str, path: str) -> str:
        sk = self.skills.get(skill)
        if not sk:
            return f"ERROR: không có skill '{skill}'"
        target = (sk.path / path).resolve()
        if sk.path.resolve() not in target.parents or not target.is_file():
            return "ERROR: đường dẫn không hợp lệ"
        return target.read_text(encoding="utf-8")[:20000]

    def tools(self) -> list[ToolSpec]:
        if not self.skills:
            return []
        names = list(self.skills)
        return [
            make_tool(
                "load_skill",
                "Nạp toàn bộ hướng dẫn của một skill theo tên.",
                {"type": "object", "properties": {"name": {"type": "string", "enum": names}}, "required": ["name"]},
                self._load_skill, group="skill",
            ),
            make_tool(
                "read_skill_file",
                "Đọc một file tài nguyên đi kèm skill (template, checklist...).",
                {"type": "object", "properties": {"skill": {"type": "string", "enum": names},
                                                  "path": {"type": "string"}}, "required": ["skill", "path"]},
                self._read_skill_file, group="skill",
            ),
        ]
