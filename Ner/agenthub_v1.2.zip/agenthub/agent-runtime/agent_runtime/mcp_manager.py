"""Kết nối tới các MCP server (mỗi server chạy trong container riêng) qua Streamable HTTP hoặc SSE.

Thiết kế: mở kết nối theo từng lượt chạy (per-run) trong cùng 1 asyncio task
=> không giữ session lâu dài, chịu lỗi tốt khi MCP server restart, phù hợp xu hướng MCP stateless.
Tool của MCP được đổi tên thành  <server>__<tool>  để tránh trùng giữa các server.
"""
from __future__ import annotations

import asyncio
import json
import logging
import re
import time
from contextlib import AsyncExitStack, asynccontextmanager
from dataclasses import dataclass, field
from typing import Any, AsyncIterator

from mcp import ClientSession
from mcp.client.sse import sse_client

try:  # tên hàm mới (mcp >= 1.2x) và cũ
    from mcp.client.streamable_http import streamablehttp_client as _streamable_client
except ImportError:  # pragma: no cover
    from mcp.client.streamable_http import streamable_http_client as _streamable_client

from .config import MCPServerConfig
from .events import WARNING, Emitter, Event, null_emitter
from .tools import ToolSpec, make_tool

log = logging.getLogger("agent.mcp")
_SAFE = re.compile(r"[^a-zA-Z0-9_-]")


def mcp_tool_name(server: str, tool: str) -> str:
    return _SAFE.sub("_", f"{server}__{tool}")[:64]


def render_call_result(res: Any) -> str:
    parts: list[str] = []
    for c in getattr(res, "content", None) or []:
        ctype = getattr(c, "type", "")
        if ctype == "text":
            parts.append(c.text)
        elif ctype == "image":
            parts.append(f"[image {getattr(c, 'mimeType', '')}]")
        elif ctype == "resource":
            r = getattr(c, "resource", None)
            parts.append(getattr(r, "text", None) or f"[resource {getattr(r, 'uri', '')}]")
        elif ctype == "resource_link":
            parts.append(f"[resource_link {getattr(c, 'uri', '')}]")
    structured = getattr(res, "structuredContent", None)
    if not parts and structured is not None:
        parts.append(json.dumps(structured, ensure_ascii=False))
    text = "\n".join(parts) if parts else "(empty result)"
    return f"ERROR: {text}" if getattr(res, "isError", False) else text


@dataclass
class ServerStatus:
    name: str
    url: str
    connected: bool = False
    tools: list[str] = field(default_factory=list)
    error: str | None = None
    checked_at: float = 0.0


@dataclass
class MCPToolbox:
    specs: list[ToolSpec]
    status: dict[str, ServerStatus]


class MCPManager:
    def __init__(self, servers: list[MCPServerConfig]):
        self.servers = servers
        self.last_status: dict[str, ServerStatus] = {
            s.name: ServerStatus(s.name, s.url) for s in servers
        }
        self.last_specs: list[ToolSpec] = []

    async def _open(self, stack: AsyncExitStack, srv: MCPServerConfig) -> ClientSession:
        if srv.transport == "sse":
            read, write = await stack.enter_async_context(
                sse_client(srv.url, headers=srv.headers or None, timeout=srv.timeout_s,
                           sse_read_timeout=srv.read_timeout_s))
        else:
            read, write, _ = await stack.enter_async_context(
                _streamable_client(srv.url, headers=srv.headers or None, timeout=srv.timeout_s,
                                   sse_read_timeout=srv.read_timeout_s)
            )
        session = await stack.enter_async_context(ClientSession(read, write))
        await session.initialize()
        return session

    def _wrap_tool(self, srv: MCPServerConfig, session: ClientSession, t: Any) -> ToolSpec:
        remote_name = t.name

        async def call(**kwargs: Any) -> str:
            res = await session.call_tool(remote_name, arguments=kwargs)
            return render_call_result(res)

        schema = t.inputSchema if isinstance(t.inputSchema, dict) else {"type": "object", "properties": {}}
        desc = (t.description or remote_name).strip()
        return make_tool(
            mcp_tool_name(srv.name, remote_name), f"[MCP:{srv.name}] {desc}", schema, call,
            group="mcp", meta={"server": srv.name, "remote_name": remote_name},
        )

    @asynccontextmanager
    async def connect(self, emit: Emitter = null_emitter) -> AsyncIterator[MCPToolbox]:
        """Kết nối mọi MCP server cho 1 lượt chạy; server lỗi (không required) sẽ bị bỏ qua."""
        specs: list[ToolSpec] = []
        status: dict[str, ServerStatus] = {}
        async with AsyncExitStack() as stack:
            for srv in self.servers:
                st = ServerStatus(srv.name, srv.url, checked_at=time.time())
                sub = AsyncExitStack()
                try:
                    async with asyncio.timeout(srv.timeout_s):
                        session = await self._open(sub, srv)
                        listed = await session.list_tools()
                    for t in listed.tools:
                        if srv.allowed_tools is not None and t.name not in srv.allowed_tools:
                            continue
                        specs.append(self._wrap_tool(srv, session, t))
                        st.tools.append(t.name)
                    st.connected = True
                    stack.push_async_callback(sub.aclose)
                except BaseException as exc:  # noqa: BLE001 - gồm cả ExceptionGroup của anyio
                    if isinstance(exc, (KeyboardInterrupt, SystemExit)):
                        raise
                    close_exc: BaseException | None = None
                    try:
                        await sub.aclose()   # thoát task group của transport => lộ lỗi thật
                    except BaseException as e2:  # noqa: BLE001
                        close_exc = e2
                    current = asyncio.current_task()
                    if isinstance(exc, asyncio.CancelledError) and current is not None and current.cancelling():
                        raise  # bị huỷ thật từ bên ngoài
                    real = close_exc if isinstance(exc, asyncio.CancelledError) and close_exc else exc
                    if isinstance(real, BaseExceptionGroup) and real.exceptions:
                        real = real.exceptions[0]
                    st.error = f"{type(real).__name__}: {real}"[:300]
                    log.warning("MCP %s (%s) không kết nối được: %s", srv.name, srv.url, st.error)
                    await emit(Event(WARNING, {"message": f"MCP server '{srv.name}' không khả dụng", "error": st.error}))
                    if srv.required:
                        raise RuntimeError(f"MCP server bắt buộc '{srv.name}' lỗi: {st.error}") from None
                status[srv.name] = st
            self.last_status = status
            self.last_specs = specs
            yield MCPToolbox(specs=specs, status=status)

    async def probe(self) -> dict[str, ServerStatus]:
        """Kiểm tra kết nối + cache danh sách tool (dùng cho đăng ký agent / UI)."""
        try:
            async with self.connect() as tb:
                return tb.status
        except Exception as exc:  # noqa: BLE001
            log.warning("Probe MCP lỗi: %s", exc)
            return self.last_status

    def describe(self) -> list[dict[str, Any]]:
        return [
            {"name": s.name, "url": s.url, "connected": s.connected, "tools": s.tools, "error": s.error}
            for s in self.last_status.values()
        ]
