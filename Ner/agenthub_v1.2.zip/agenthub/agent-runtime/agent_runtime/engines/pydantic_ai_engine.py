"""Adapter Pydantic AI.

Khi nào dùng: cần kết quả CÓ CẤU TRÚC được kiểm tra theo schema (`engine.output_schema`),
muốn FallbackModel / retry của Pydantic AI, hoặc đội đã quen hệ sinh thái Pydantic.

Điểm quan trọng với Ollama / vLLM / OpenRouter:
  * Dùng OpenAIChatModel (Chat Completions). Prefix 'openai:' mặc định của Pydantic AI là Responses API,
    mà đa số server OpenAI-compatible không có.
  * Profile của model được nới lỏng (tắt strict tool schema...) vì tên model không phải họ OpenAI.

Tool, skill và MCP KHÔNG dùng toolset riêng của Pydantic AI mà đi qua lớp tool dùng chung
(BaseEngine.exec_tool) => cùng allowlist, cùng namespacing `<server>__<tool>`, cùng sự kiện timeline.

Cài đặt:  pip install -r requirements-pydantic-ai.txt
"""
from __future__ import annotations

import dataclasses
import json
import logging
import uuid
from typing import Any

from openai import AsyncOpenAI

from ..engine_base import FINAL_ANSWER_PROMPT, BaseEngine, RunContext, RunResult, merge_usage
from ..events import STEP, Emitter, Event

log = logging.getLogger("agent.engine.pydantic_ai")

# Profile mặc định cho server không phải OpenAI. Trường nào bản Pydantic AI đang cài không có sẽ bị bỏ qua.
DEFAULT_PROFILE = {
    "openai_supports_strict_tool_definition": False,
    "openai_chat_supports_max_completion_tokens": False,
}


def _pai():
    """Import trễ: thiếu thư viện chỉ báo lỗi khi agent thực sự chọn engine này."""
    try:
        import pydantic_ai
        from pydantic_ai import Agent, Tool
        from pydantic_ai.messages import (ModelRequest, ModelResponse, PartDeltaEvent, TextPart, TextPartDelta,
                                          UserPromptPart)
        from pydantic_ai.models.openai import OpenAIChatModel
        from pydantic_ai.providers.openai import OpenAIProvider
        from pydantic_ai.usage import UsageLimits
    except ImportError as exc:
        from . import EngineUnavailable
        raise EngineUnavailable(
            "engine.type=pydantic_ai cần thư viện Pydantic AI: pip install -r requirements-pydantic-ai.txt "
            f"(lỗi: {exc})") from exc
    return dict(pydantic_ai=pydantic_ai, Agent=Agent, Tool=Tool, ModelRequest=ModelRequest,
                ModelResponse=ModelResponse, PartDeltaEvent=PartDeltaEvent, TextPart=TextPart,
                TextPartDelta=TextPartDelta, UserPromptPart=UserPromptPart, OpenAIChatModel=OpenAIChatModel,
                OpenAIProvider=OpenAIProvider, UsageLimits=UsageLimits)


def _usage_dict(u: Any) -> dict[str, int]:
    out: dict[str, int] = {}
    for attr in ("input_tokens", "output_tokens", "request_tokens", "response_tokens", "total_tokens"):
        v = getattr(u, attr, None)
        if isinstance(v, int):
            out[attr] = v
    return out


class PydanticAIEngine(BaseEngine):
    engine_name = "pydantic_ai"

    def check_available(self) -> None:
        _pai()

    # ------------------------------------------------------------------ model
    def _profile(self, P: dict[str, Any]):
        if self.llm.cfg.provider == "openai":
            return None
        try:
            from pydantic_ai.profiles.openai import OpenAIModelProfile
        except ImportError:
            try:
                from pydantic_ai.models.openai import OpenAIModelProfile  # type: ignore[no-redef]
            except ImportError:
                return None
        wanted = {**DEFAULT_PROFILE, **(self.cfg.options.get("profile") or {})}
        known = {f.name for f in dataclasses.fields(OpenAIModelProfile)} if dataclasses.is_dataclass(OpenAIModelProfile) else set(wanted)
        dropped = sorted(set(wanted) - known)
        if dropped:
            log.info("Bỏ qua trường profile không hỗ trợ ở bản Pydantic AI này: %s", dropped)
        return OpenAIModelProfile(**{k: v for k, v in wanted.items() if k in known})

    def _model(self, P: dict[str, Any]):
        cfg = self.llm.cfg
        # 1 client OpenAI dùng chung; tắt retry ở SDK để không nhân retry với Pydantic AI
        client = AsyncOpenAI(base_url=cfg.base_url, api_key=cfg.api_key, timeout=cfg.timeout_s,
                             max_retries=int(self.cfg.options.get("sdk_max_retries", 0)),
                             default_headers=cfg.extra_headers or None)
        provider = P["OpenAIProvider"](openai_client=client)
        profile = self._profile(P)

        def build(name: str):
            kw: dict[str, Any] = {"provider": provider}
            if profile is not None:
                kw["profile"] = profile
            return P["OpenAIChatModel"](name, **kw)

        models = [build(n) for n in [cfg.model, *cfg.fallback_models]]
        if len(models) == 1:
            return models[0]
        from pydantic_ai.models.fallback import FallbackModel
        return FallbackModel(*models)

    def _settings(self) -> dict[str, Any]:
        cfg = self.llm.cfg
        s: dict[str, Any] = {"temperature": cfg.temperature,
                             "parallel_tool_calls": self.m.limits.parallel_tool_calls}
        if cfg.max_tokens:
            s["max_tokens"] = cfg.max_tokens
        if cfg.extra_body:
            s["extra_body"] = cfg.extra_body
        return s

    def _output_type(self, P: dict[str, Any]):
        schema = self.cfg.output_schema
        if not schema:
            return str
        StructuredDict = getattr(P["pydantic_ai"], "StructuredDict", None)
        if StructuredDict is None:
            log.warning("Bản Pydantic AI này không có StructuredDict — bỏ qua output_schema")
            return str
        return StructuredDict(schema, name=schema.get("title", "Result"),
                              description=schema.get("description"))

    # ------------------------------------------------------------------ messages
    def _history(self, P: dict[str, Any], messages: list[dict[str, Any]]) -> tuple[str, list[Any]]:
        """Tách tin nhắn cuối của user làm prompt, phần trước chuyển sang message_history của Pydantic AI."""
        if not messages or messages[-1].get("role") != "user":
            raise ValueError("Tin nhắn cuối cùng phải là của user")
        history: list[Any] = []
        for m in messages[:-1]:
            text = str(m.get("content") or "")
            if m.get("role") == "user":
                history.append(P["ModelRequest"](parts=[P["UserPromptPart"](content=text)]))
            elif m.get("role") == "assistant":
                history.append(P["ModelResponse"](parts=[P["TextPart"](content=text)]))
        return str(messages[-1]["content"]), history

    # ------------------------------------------------------------------ run
    async def _run(self, messages: list[dict[str, Any]], ctx: RunContext, emit: Emitter) -> RunResult:
        P = _pai()
        usage: dict[str, int] = {}
        step_box = {"n": 0}
        token_cb = self.token_callback(ctx, emit)

        async with self.mcp.connect(emit) as toolbox:
            specs = self.collect_tools(toolbox)

            def make_tool(name: str):
                spec = specs[name]

                async def fn(**kwargs: Any) -> str:
                    await self.check_cancel(ctx)
                    out, _ = await self.exec_tool(name, kwargs, f"call_{uuid.uuid4().hex[:10]}", specs, emit,
                                                  step_box["n"])
                    return out
                return P["Tool"].from_schema(fn, name=name, description=spec.description,
                                             json_schema=spec.parameters)

            agent = P["Agent"](
                self._model(P),
                instructions=self.system_prompt(ctx),
                tools=[make_tool(n) for n in specs],
                output_type=self._output_type(P),
                model_settings=self._settings(),
                retries=int(self.cfg.options.get("tool_retries", 1)),
            )
            prompt, history = self._history(P, messages)
            limits = P["UsageLimits"](request_limit=self.m.limits.max_steps + 1)
            output: Any = None
            try:
                async with agent.iter(prompt, message_history=history, usage_limits=limits) as run:
                    async for node in run:
                        await self.check_cancel(ctx)
                        if P["Agent"].is_model_request_node(node):
                            step_box["n"] += 1
                            await emit(Event(STEP, {"step": step_box["n"], "max_steps": self.m.limits.max_steps}))
                            if token_cb is not None:
                                async with node.stream(run.ctx) as stream:
                                    async for ev in stream:
                                        if isinstance(ev, P["PartDeltaEvent"]) and isinstance(ev.delta, P["TextPartDelta"]):
                                            await token_cb(ev.delta.content_delta)
                    output = run.result.output if run.result is not None else ""
                    merge_usage(usage, _usage_dict(run.usage()))
            except Exception as exc:
                if type(exc).__name__ != "UsageLimitExceeded":
                    raise
                # Hết bước => hỏi model 1 lần cuối, không tool (giống engine native)
                log.info("Hết max_steps, tổng hợp câu trả lời cuối")
                summary = P["Agent"](self._model(P), instructions=self.system_prompt(ctx),
                                     model_settings=self._settings())
                res = await summary.run(f"{prompt}\n\n{FINAL_ANSWER_PROMPT}", message_history=history)
                output = res.output
                merge_usage(usage, _usage_dict(res.usage()))

        text = output if isinstance(output, str) else json.dumps(output, ensure_ascii=False, indent=2, default=str)
        return RunResult("succeeded", text.strip(), step_box["n"], usage)
