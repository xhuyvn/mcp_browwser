"""Adapter LangGraph — StateGraph có checkpoint và con người phê duyệt tool (human-in-the-loop).

Khi nào dùng:
  * Tool nhạy cảm cần người duyệt trước khi chạy (ghi file, gửi mail, sửa dữ liệu…) — `engine.approval_required_tools`
  * Task dài cần trạng thái bền vững để chạy tiếp sau khi container restart — `engine.checkpointer: postgres`

Đồ thị:
      START → agent ──(có tool_calls)──► tools ──► agent …
                 └──(không / hết bước)──► END
  Node `tools` gọi `interrupt()` khi có tool cần duyệt → task chuyển sang `waiting_input`.
  Người dùng Duyệt / Từ chối trên UI (hoặc MCP `approve_task`) → backend giao lại task kèm quyết định
  → engine chạy tiếp bằng `Command(resume=quyết_định)` từ đúng checkpoint (thread_id = task_id).

State dùng message dạng dict OpenAI và LLMClient chung => chạy với mọi API OpenAI-compatible,
không cần langchain-openai. Tool/skill/MCP đi qua lớp tool dùng chung (BaseEngine.exec_tool).

Cài đặt:  pip install -r requirements-langgraph.txt
"""
from __future__ import annotations

import fnmatch
import logging
import operator
from contextlib import asynccontextmanager
from typing import Annotated, Any, AsyncIterator, TypedDict

from ..engine_base import FINAL_ANSWER_PROMPT, BaseEngine, RunContext, RunResult, merge_usage
from ..events import APPROVAL, MESSAGE, STEP, WARNING, Emitter, Event
from ..llm import ToolCall

log = logging.getLogger("agent.engine.langgraph")


def _lg():
    try:
        from langgraph.graph import END, START, StateGraph
        from langgraph.types import Command, interrupt
        try:
            from langgraph.checkpoint.memory import InMemorySaver
        except ImportError:  # bản cũ
            from langgraph.checkpoint.memory import MemorySaver as InMemorySaver
    except ImportError as exc:
        from . import EngineUnavailable
        raise EngineUnavailable(
            f"engine.type=langgraph cần thư viện LangGraph: pip install -r requirements-langgraph.txt (lỗi: {exc})"
        ) from exc
    return dict(END=END, START=START, StateGraph=StateGraph, Command=Command, interrupt=interrupt,
                InMemorySaver=InMemorySaver)


class GraphState(TypedDict, total=False):
    messages: Annotated[list[dict[str, Any]], operator.add]
    steps: int
    usage: dict[str, int]
    done: bool


# ---------------------------------------------------------------------- logic thuần (unit-test được)
def needs_approval(tool_name: str, patterns: list[str]) -> bool:
    return any(fnmatch.fnmatch(tool_name, p) for p in patterns)


def pending_approvals(tool_calls: list[dict[str, Any]], patterns: list[str]) -> list[dict[str, Any]]:
    out = []
    for tc in tool_calls:
        fn = tc.get("function") or {}
        if needs_approval(fn.get("name", ""), patterns):
            out.append({"id": tc.get("id"), "name": fn.get("name"),
                        "arguments": ToolCall(tc.get("id", ""), fn.get("name", ""), fn.get("arguments") or "{}").parsed_args()})
    return out


def normalize_decision(decision: Any, pending: list[dict[str, Any]]) -> dict[str, tuple[bool, str]]:
    """Chuẩn hoá quyết định của người dùng thành {call_id: (approved, comment)}.

    Chấp nhận: True/False · {"approved": bool, "comment": str} · {"calls": {call_id: bool}, "comment": str}
    """
    if isinstance(decision, bool):
        return {p["id"]: (decision, "") for p in pending}
    if not isinstance(decision, dict):
        return {p["id"]: (False, "quyết định không hợp lệ") for p in pending}
    comment = str(decision.get("comment") or "")
    default = bool(decision.get("approved", False))
    per_call = decision.get("calls") or {}
    return {p["id"]: (bool(per_call.get(p["id"], default)), comment) for p in pending}


def route_after_agent(state: GraphState) -> str:
    last = (state.get("messages") or [{}])[-1]
    if state.get("done") or not last.get("tool_calls"):
        return "end"
    return "tools"


def last_assistant_text(messages: list[dict[str, Any]]) -> str:
    for m in reversed(messages):
        if m.get("role") == "assistant" and (m.get("content") or "").strip():
            return str(m["content"]).strip()
    return ""


# ---------------------------------------------------------------------- engine
class LangGraphEngine(BaseEngine):
    engine_name = "langgraph"

    def __init__(self, *a: Any, **kw: Any):
        super().__init__(*a, **kw)
        self._memory_saver = None
        self._pg_ready = False

    def check_available(self) -> None:
        _lg()
        if self.cfg.checkpointer == "postgres":
            if not self.cfg.checkpoint_url:
                raise ValueError("engine.checkpointer=postgres cần engine.checkpoint_url")
            try:
                from langgraph.checkpoint.postgres.aio import AsyncPostgresSaver  # noqa: F401
            except ImportError as exc:
                from . import EngineUnavailable
                raise EngineUnavailable("Cần langgraph-checkpoint-postgres + psycopg 3 (requirements-langgraph.txt)") from exc
        if self.cfg.checkpointer == "none" and self.cfg.approval_required_tools:
            raise ValueError("approval_required_tools cần checkpointer (memory hoặc postgres)")
        if self.cfg.checkpointer == "memory" and self.cfg.approval_required_tools:
            log.warning("checkpointer=memory: task chờ duyệt sẽ mất nếu container restart hoặc chạy nhiều replica. "
                        "Production hãy dùng checkpointer=postgres.")

    # ------------------------------------------------------------------ checkpointer
    @asynccontextmanager
    async def _saver_cm(self, L: dict[str, Any]) -> AsyncIterator[Any]:
        """Checkpointer cho 1 lượt chạy: none | memory (dùng chung trong process) | postgres (bền vững)."""
        if self.cfg.checkpointer == "none":
            yield None
            return
        if self.cfg.checkpointer == "memory":
            if self._memory_saver is None:
                self._memory_saver = L["InMemorySaver"]()
            yield self._memory_saver
            return
        from langgraph.checkpoint.postgres.aio import AsyncPostgresSaver
        async with AsyncPostgresSaver.from_conn_string(self.cfg.checkpoint_url) as saver:
            if not self._pg_ready:
                await saver.setup()          # tạo bảng checkpoint (idempotent) — chỉ lần đầu
                self._pg_ready = True
            yield saver

    def _thread_id(self, ctx: RunContext) -> str:
        # Task: thread = task_id (để resume). Chat: thread mới mỗi lượt vì backend đã gửi kèm lịch sử.
        return ctx.task_id or f"chat-{ctx.run_id}"

    # ------------------------------------------------------------------ graph
    def _build(self, L: dict[str, Any], specs: dict[str, Any], ctx: RunContext, emit: Emitter, saver: Any):
        schemas = [s.openai_schema() for s in specs.values()] or None
        token_cb = self.token_callback(ctx, emit)
        max_steps = self.m.limits.max_steps
        patterns = self.cfg.approval_required_tools

        async def agent_node(state: GraphState) -> dict[str, Any]:
            await self.check_cancel(ctx)
            steps = int(state.get("steps") or 0)
            usage = dict(state.get("usage") or {})
            convo = list(state.get("messages") or [])
            if steps >= max_steps:
                resp = await self.llm.chat(convo + [{"role": "user", "content": FINAL_ANSWER_PROMPT}], None, token_cb)
                merge_usage(usage, resp.usage)
                return {"messages": [{"role": "assistant", "content": resp.content}], "usage": usage, "done": True}
            await emit(Event(STEP, {"step": steps + 1, "max_steps": max_steps}))
            resp = await self.llm.chat(convo, schemas, token_cb, self.m.limits.parallel_tool_calls)
            merge_usage(usage, resp.usage)
            msg = resp.as_message()
            msg["content"] = msg.get("content") or ""
            if resp.tool_calls and resp.content.strip():
                await emit(Event(MESSAGE, {"content": resp.content.strip(), "step": steps + 1}))
            return {"messages": [msg], "steps": steps + 1, "usage": usage}

        async def tools_node(state: GraphState) -> dict[str, Any]:
            last = state["messages"][-1]
            calls = last.get("tool_calls") or []
            step = int(state.get("steps") or 0)
            pending = pending_approvals(calls, patterns)
            decisions: dict[str, tuple[bool, str]] = {}
            if pending:
                if ctx.kind == "chat" or saver is None:
                    decisions = {p["id"]: (False, "Tool cần phê duyệt — hãy giao việc này dưới dạng task") for p in pending}
                else:
                    # interrupt(): lần đầu dừng đồ thị; khi resume trả về quyết định của người dùng.
                    # Đặt TRƯỚC mọi tool để khi node chạy lại không có tool nào bị chạy 2 lần.
                    decision = L["interrupt"]({"type": "tool_approval", "calls": pending,
                                               "message": f"Agent muốn chạy {len(pending)} tool cần phê duyệt"})
                    decisions = normalize_decision(decision, pending)
                for p in pending:
                    ok, comment = decisions[p["id"]]
                    await emit(Event(APPROVAL, {"id": p["id"], "name": p["name"], "approved": ok, "comment": comment}))
            results = []
            for tc in calls:
                await self.check_cancel(ctx)
                fn = tc.get("function") or {}
                name, cid = fn.get("name", ""), tc.get("id", "")
                if cid in decisions and not decisions[cid][0]:
                    reason = decisions[cid][1]
                    out = "ERROR: Người dùng TỪ CHỐI chạy tool này." + (f" Lý do: {reason}" if reason else "") + \
                          " Không thử lại tool này; hãy tiếp tục bằng cách khác hoặc báo lại cho người dùng."
                else:
                    args = ToolCall(cid, name, fn.get("arguments") or "{}").parsed_args()
                    out, _ = await self.exec_tool(name, args, cid, specs, emit, step)
                results.append({"role": "tool", "tool_call_id": cid, "content": out})
            return {"messages": results}

        g = L["StateGraph"](GraphState)
        g.add_node("agent", agent_node)
        g.add_node("tools", tools_node)
        g.add_edge(L["START"], "agent")
        g.add_conditional_edges("agent", route_after_agent, {"tools": "tools", "end": L["END"]})
        g.add_edge("tools", "agent")
        return g.compile(checkpointer=saver)

    # ------------------------------------------------------------------ run
    async def _run(self, messages: list[dict[str, Any]], ctx: RunContext, emit: Emitter) -> RunResult:
        L = _lg()
        thread_id = self._thread_id(ctx)
        recursion = self.m.limits.max_steps * 2 + 6
        config = {"configurable": {"thread_id": thread_id}, "recursion_limit": recursion}
        async with self.mcp.connect(emit) as toolbox, self._saver_cm(L) as saver:
            specs = self.collect_tools(toolbox)
            graph = self._build(L, specs, ctx, emit, saver)
            snap = await graph.aget_state(config) if saver is not None else None
            fresh_input = {"messages": [{"role": "system", "content": self.system_prompt(ctx)}, *messages],
                           "steps": 0, "usage": {}, "done": False}
            inp: Any
            if ctx.resume is not None:
                # Người dùng vừa duyệt / từ chối => chạy tiếp đúng node đang interrupt
                if saver is None:
                    raise RuntimeError("Không thể tiếp tục: engine không có checkpointer")
                if snap is None or not snap.next:
                    raise RuntimeError(f"Không tìm thấy checkpoint đang chờ của thread '{thread_id}' "
                                       "(container đã restart với checkpointer=memory?)")
                inp = L["Command"](resume=ctx.resume)
            elif snap is not None and snap.next:
                # Task được giao lại (worker trước chết giữa chừng): durable execution — chạy tiếp từ checkpoint
                pending = [i for t in (getattr(snap, "tasks", ()) or ()) for i in (getattr(t, "interrupts", ()) or ())]
                if pending:
                    value = getattr(pending[0], "value", pending[0])
                    payload = value if isinstance(value, dict) else {"value": value}
                    vals = dict(snap.values or {})
                    return RunResult("waiting_input", "", int(vals.get("steps") or 0), dict(vals.get("usage") or {}),
                                     interrupt={**payload, "engine": self.engine_name, "thread_id": thread_id})
                await emit(Event(WARNING, {"message": "Tiếp tục task từ checkpoint của lần chạy trước",
                                           "thread_id": thread_id, "next": list(snap.next)}))
                inp = None
            else:
                if snap is not None and snap.values:
                    # Thread đã chạy xong trước đó (task chạy lại thủ công) => dùng thread mới, tránh nối trùng lịch sử
                    thread_id = f"{thread_id}-r{ctx.run_id[:8]}"
                    config = {"configurable": {"thread_id": thread_id}, "recursion_limit": recursion}
                inp = fresh_input
            state = await graph.ainvoke(inp, config)

            interrupts: list[Any] = []
            if saver is not None:
                snap = await graph.aget_state(config)
                for t in getattr(snap, "tasks", ()) or ():
                    interrupts.extend(getattr(i, "value", i) for i in (getattr(t, "interrupts", ()) or ()))
                state = dict(snap.values or state)

        steps = int(state.get("steps") or 0)
        usage = dict(state.get("usage") or {})
        if interrupts:
            payload = interrupts[0] if isinstance(interrupts[0], dict) else {"value": interrupts[0]}
            return RunResult("waiting_input", "", steps, usage,
                             interrupt={**payload, "engine": self.engine_name, "thread_id": thread_id})
        msgs = list(state.get("messages") or [])
        return RunResult("succeeded", last_assistant_text(msgs), steps, usage, messages=msgs)
