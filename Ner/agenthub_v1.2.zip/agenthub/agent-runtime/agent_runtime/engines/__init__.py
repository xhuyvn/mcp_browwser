"""Registry engine: chọn engine theo `engine.type` trong agent.yaml.

  native        vòng lặp tự viết (mặc định, không cần thư viện thêm)
  pydantic_ai   Pydantic AI (OpenAIChatModel + Chat Completions) — kết quả có cấu trúc, FallbackModel
  langgraph     LangGraph StateGraph — checkpoint bền vững, con người phê duyệt tool (interrupt/resume)
  "pkg.mod:Cls" engine tự viết, kế thừa agent_runtime.engine_base.BaseEngine
"""
from __future__ import annotations

import importlib
from typing import TYPE_CHECKING

from ..engine_base import BaseEngine

if TYPE_CHECKING:
    from ..config import AgentManifest
    from ..llm import LLMClient
    from ..mcp_manager import MCPManager
    from ..skills import SkillLibrary
    from ..tools import ToolSpec

BUILTIN = {
    "native": "agent_runtime.engine:NativeEngine",
    "pydantic_ai": "agent_runtime.engines.pydantic_ai_engine:PydanticAIEngine",
    "langgraph": "agent_runtime.engines.langgraph_engine:LangGraphEngine",
}


class EngineUnavailable(RuntimeError):
    pass


def resolve_engine_class(engine_type: str) -> type[BaseEngine]:
    target = BUILTIN.get(engine_type, engine_type)
    if ":" not in target:
        raise ValueError(f"engine.type không hợp lệ: '{engine_type}'. Dùng: {', '.join(BUILTIN)} hoặc 'module:Class'")
    mod_name, cls_name = target.split(":", 1)
    module = importlib.import_module(mod_name)
    cls = getattr(module, cls_name)
    if not (isinstance(cls, type) and issubclass(cls, BaseEngine)):
        raise TypeError(f"{target} phải kế thừa BaseEngine")
    return cls


def create_engine(manifest: "AgentManifest", llm: "LLMClient", local_tools: list["ToolSpec"],
                  skills: "SkillLibrary", mcp: "MCPManager") -> BaseEngine:
    cls = resolve_engine_class(manifest.engine.type)
    engine = cls(manifest, llm, local_tools, skills, mcp)
    engine.check_available()
    return engine
