"""Test các engine adapter.

- Phần logic thuần (duyệt tool, usage, routing) luôn chạy.
- Test tích hợp Pydantic AI / LangGraph chỉ chạy khi đã cài thư viện:
    pip install -r requirements.txt -r requirements-pydantic-ai.txt -r requirements-langgraph.txt pytest
    python -m pytest -q tests
"""
from __future__ import annotations

import asyncio
import json
from pathlib import Path

import pytest

from agent_runtime.config import AgentManifest
from agent_runtime.engine_base import RunContext, merge_usage
from agent_runtime.llm import LLMClient
from agent_runtime.mcp_manager import MCPManager
from agent_runtime.skills import SkillLibrary
from agent_runtime.tools import make_tool, select_tools

ROOT = Path(__file__).resolve().parents[2]


# ----------------------------------------------------------------- fake OpenAI client (Chat Completions)
class O:
    def __init__(self, **kw):
        for k, v in kw.items():
            setattr(self, k, v)
        self._keys = list(kw)

    def model_dump(self):
        return {k: getattr(self, k) for k in self._keys}


class ScriptedCompletions:
    """Lượt đầu: gọi fs__write_file + calculator. Lượt sau: tổng hợp kết quả tool."""
    def __init__(self):
        self.calls = []

    async def create(self, **kw):
        self.calls.append(kw)
        tool_msgs = [m for m in kw["messages"] if m["role"] == "tool"]
        if not tool_msgs and kw.get("tools"):
            msg = O(content="", tool_calls=[
                O(id="c1", function=O(name="fs__write_file", arguments='{"path": "/workspace/r.md", "content": "# R"}')),
                O(id="c2", function=O(name="calculator", arguments='{"expression": "6*7"}')),
            ])
        else:
            msg = O(content="FINAL: " + " | ".join(m["content"][:45] for m in tool_msgs), tool_calls=None)
        return O(choices=[O(message=msg, finish_reason="stop")],
                 usage=O(prompt_tokens=10, completion_tokens=5, total_tokens=15), model="fake")


class FakeClient:
    def __init__(self):
        self.chat = O(completions=ScriptedCompletions())


WRITES: list[str] = []


def _write_file(path: str, content: str) -> str:
    WRITES.append(path)
    return f"đã ghi {path}"


def build(engine_cls, engine_cfg: dict, tmp_path: Path):
    manifest = AgentManifest.model_validate({
        "name": "writer", "model": {"model": "fake", "base_url": "http://x", "stream": False},
        "skills": [], "tools": ["builtin.calculator"], "mcp_servers": [], "engine": engine_cfg,
    })
    llm = LLMClient(manifest.model, client=FakeClient())
    wf = make_tool("fs__write_file", "ghi file", {"type": "object", "properties": {
        "path": {"type": "string"}, "content": {"type": "string"}}, "required": ["path", "content"]},
        _write_file, group="mcp")
    return engine_cls(manifest, llm, select_tools(manifest.tools) + [wf], SkillLibrary(tmp_path, "*"), MCPManager([]))


def run(engine, ctx):
    events = []

    async def emit(e):
        events.append(e)
    res = asyncio.run(engine.run([{"role": "user", "content": "viết báo cáo"}], ctx, emit))
    return res, [e.type for e in events]


# ----------------------------------------------------------------- logic thuần
def test_merge_usage_accepts_both_naming_styles():
    u: dict = {}
    merge_usage(u, {"input_tokens": 10, "output_tokens": 4})
    merge_usage(u, {"prompt_tokens": 1, "completion_tokens": 1, "total_tokens": 2})
    assert u == {"prompt_tokens": 11, "completion_tokens": 5, "total_tokens": 16}


def test_approval_helpers():
    from agent_runtime.engines.langgraph_engine import normalize_decision, pending_approvals, route_after_agent
    calls = [{"id": "c1", "function": {"name": "fs__write_file", "arguments": '{"path": "a"}'}},
             {"id": "c2", "function": {"name": "calculator", "arguments": "{}"}}]
    pend = pending_approvals(calls, ["fs__write_*"])
    assert [p["name"] for p in pend] == ["fs__write_file"] and pend[0]["arguments"] == {"path": "a"}
    assert normalize_decision(True, pend) == {"c1": (True, "")}
    assert normalize_decision({"approved": False, "comment": "no"}, pend) == {"c1": (False, "no")}
    assert normalize_decision({"calls": {"c1": True}}, pend) == {"c1": (True, "")}
    assert normalize_decision("garbage", pend)["c1"][0] is False
    assert route_after_agent({"messages": [{"role": "assistant", "tool_calls": calls}]}) == "tools"
    assert route_after_agent({"messages": [{"role": "assistant", "content": "x"}]}) == "end"


def test_registry_and_manifests():
    from agent_runtime.config import load_manifest
    from agent_runtime.engine import NativeEngine
    from agent_runtime.engines import resolve_engine_class
    assert resolve_engine_class("native") is NativeEngine
    assert resolve_engine_class("agent_runtime.engine:NativeEngine") is NativeEngine
    with pytest.raises(ValueError):
        resolve_engine_class("khong-ton-tai")
    assert load_manifest(ROOT / "agents" / "writer").engine.type in ("langgraph", "native", "pydantic_ai")


def test_native_engine_and_cancel(tmp_path):
    from agent_runtime.engine import NativeEngine
    WRITES.clear()
    res, _ = run(build(NativeEngine, {}, tmp_path), RunContext(kind="task", task_id="N1"))
    assert res.status == "succeeded" and "42" in res.output and WRITES == ["/workspace/r.md"]

    async def yes():
        return True
    res, types = run(build(NativeEngine, {}, tmp_path), RunContext(kind="task", task_id="N2", is_cancelled=yes))
    assert res.status == "cancelled" and types == ["run_started", "run_finished"]


# ----------------------------------------------------------------- LangGraph (thư viện thật)
def test_langgraph_approval_flow(tmp_path):
    pytest.importorskip("langgraph")
    from agent_runtime.engines.langgraph_engine import LangGraphEngine
    cfg = {"type": "langgraph", "checkpointer": "memory", "approval_required_tools": ["fs__write_*"]}

    # 1) dừng chờ duyệt, chưa chạy tool nào
    WRITES.clear()
    eng = build(LangGraphEngine, cfg, tmp_path)
    r1, t1 = run(eng, RunContext(kind="task", task_id="T-A"))
    assert r1.status == "waiting_input" and "interrupt" in t1 and WRITES == []
    assert [c["name"] for c in r1.interrupt["calls"]] == ["fs__write_file"]
    # 2) giao lại khi chưa có quyết định => vẫn chờ, không chạy trùng
    r_again, _ = run(eng, RunContext(kind="task", task_id="T-A"))
    assert r_again.status == "waiting_input" and WRITES == []
    # 3) duyệt => tool chạy đúng 1 lần, task xong
    r2, t2 = run(eng, RunContext(kind="task", task_id="T-A", resume={"approved": True}))
    assert r2.status == "succeeded" and WRITES == ["/workspace/r.md"] and "approval" in t2

    # 4) từ chối => không ghi file, agent nhận lý do
    WRITES.clear()
    eng = build(LangGraphEngine, cfg, tmp_path)
    run(eng, RunContext(kind="task", task_id="T-B"))
    r3, _ = run(eng, RunContext(kind="task", task_id="T-B", resume={"approved": False, "comment": "đổi tên"}))
    assert r3.status == "succeeded" and WRITES == [] and "TỪ CHỐI" in r3.output

    # 5) chat không có checkpoint chờ => tự từ chối tool nhạy cảm
    r4, _ = run(build(LangGraphEngine, cfg, tmp_path), RunContext(kind="chat"))
    assert r4.status == "succeeded" and WRITES == []


# ----------------------------------------------------------------- Pydantic AI (thư viện thật)
def test_pydantic_ai_engine_tools_and_structured_output(tmp_path, monkeypatch):
    pytest.importorskip("pydantic_ai")
    from pydantic_ai.messages import ModelResponse, TextPart, ToolCallPart, ToolReturnPart
    from pydantic_ai.models.function import FunctionModel

    from agent_runtime.engines.pydantic_ai_engine import PydanticAIEngine

    def scripted(messages, info):
        returns = [p for m in messages for p in getattr(m, "parts", []) if isinstance(p, ToolReturnPart)]
        if not returns:
            return ModelResponse(parts=[ToolCallPart("calculator", {"expression": "6*7"}, tool_call_id="c1")])
        if info.output_tools:      # output_schema => model trả kết quả qua output tool
            return ModelResponse(parts=[ToolCallPart(info.output_tools[0].name,
                                                     {"answer": str(returns[0].content)}, tool_call_id="o1")])
        return ModelResponse(parts=[TextPart(f"FINAL {returns[0].content}")])

    monkeypatch.setattr(PydanticAIEngine, "_model", lambda self, P: FunctionModel(scripted))
    eng = build(PydanticAIEngine, {"type": "pydantic_ai"}, tmp_path)
    res, types = run(eng, RunContext(kind="task", task_id="P1"))
    assert res.status == "succeeded" and "42" in res.output
    assert "tool_call" in types and "tool_result" in types and types[-1] == "run_finished"

    schema = {"title": "Answer", "type": "object", "properties": {"answer": {"type": "string"}}, "required": ["answer"]}
    eng = build(PydanticAIEngine, {"type": "pydantic_ai", "output_schema": schema}, tmp_path)
    res, _ = run(eng, RunContext(kind="task", task_id="P2"))
    assert res.status == "succeeded" and json.loads(res.output)["answer"] == "42"
