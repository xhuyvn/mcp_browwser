"""Unit/integration test cho Agent Runtime (không cần LLM thật, không cần Docker).

  cd agent-runtime && pip install -r requirements.txt pytest && python -m pytest -q tests
"""
from __future__ import annotations

import asyncio
import threading
import time
from pathlib import Path

import pytest

from agent_runtime.config import AgentManifest, MCPServerConfig, ModelConfig, interpolate_env
from agent_runtime.engine import AgentEngine, RunContext
from agent_runtime.llm import LLMClient
from agent_runtime.mcp_manager import MCPManager
from agent_runtime.skills import SkillLibrary
from agent_runtime.tools import select_tools

ROOT = Path(__file__).resolve().parents[2]


# ----------------------------------------------------------------- fake OpenAI client
class O:
    def __init__(self, **kw):
        for k, v in kw.items():
            setattr(self, k, v)
        self._keys = list(kw)

    def model_dump(self):
        return {k: getattr(self, k) for k in self._keys}


class FakeCompletions:
    """Lượt 1: gọi 3 tool (local, MCP, skill). Lượt 2: trả lời cuối dựa trên kết quả tool."""
    def __init__(self, mcp_tool: str | None):
        self.calls: list[dict] = []
        self.mcp_tool = mcp_tool

    async def create(self, **kw):
        self.calls.append(kw)
        if len(self.calls) == 1:
            tcs = [("c1", "calculator", '{"expression": "2*(3+4)"}'), ("c3", "load_skill", '{"name": "web-research"}')]
            if self.mcp_tool:
                tcs.append(("c2", self.mcp_tool, '{"text": "ab", "n": 2}'))
            content = ""
        else:
            tcs = []
            content = "FINAL: " + " | ".join(m["content"][:20] for m in kw["messages"] if m["role"] == "tool")
        msg = O(content=content, tool_calls=[O(id=i, function=O(name=n, arguments=a)) for i, n, a in tcs] or None)
        return O(choices=[O(message=msg, finish_reason="stop")],
                 usage=O(prompt_tokens=10, completion_tokens=5, total_tokens=15), model="fake")


class FakeClient:
    def __init__(self, mcp_tool=None):
        self.chat = O(completions=FakeCompletions(mcp_tool))


# ----------------------------------------------------------------- MCP server thử nghiệm
@pytest.fixture(scope="module")
def mcp_url():
    import uvicorn
    from mcp.server.fastmcp import FastMCP

    port = 18765
    srv = FastMCP("probe", host="127.0.0.1", port=port, stateless_http=True)

    @srv.tool()
    async def echo(text: str, n: int = 1) -> str:
        """Echo"""
        return text * n

    server = uvicorn.Server(uvicorn.Config(srv.streamable_http_app(), host="127.0.0.1", port=port, log_level="warning"))
    th = threading.Thread(target=server.run, daemon=True)
    th.start()
    for _ in range(100):
        if server.started:
            break
        time.sleep(0.05)
    yield f"http://127.0.0.1:{port}/mcp"
    server.should_exit = True


# ----------------------------------------------------------------- tests
def test_env_interpolation(monkeypatch):
    monkeypatch.setenv("FOO", "bar")
    assert interpolate_env({"a": "${FOO}", "b": ["${MISSING:-x}"]}) == {"a": "bar", "b": ["x"]}


def test_provider_resolution(monkeypatch):
    monkeypatch.setenv("LLM_PROVIDER", "ollama")
    monkeypatch.setenv("LLM_BASE_URL", "http://host:11434/v1")
    monkeypatch.setenv("LLM_MODEL", "qwen3:8b")
    monkeypatch.setenv("OPENROUTER_API_KEY", "sk-or")
    same = ModelConfig().resolved()
    assert (same.provider, same.base_url, same.model) == ("ollama", "http://host:11434/v1", "qwen3:8b")
    other = ModelConfig(provider="openrouter", model="x/y:free").resolved()
    assert other.base_url == "https://openrouter.ai/api/v1" and other.api_key == "sk-or"
    assert "X-Title" in other.extra_headers


def test_skills_and_tools():
    lib = SkillLibrary(ROOT / "agents" / "researcher" / "skills", ["web-research"])
    assert "web-research" in lib.catalog_prompt()
    body = lib._load_skill("web-research")
    assert body.startswith("# Skill: web-research") and "references/checklist.md" in body
    assert "ERROR" in lib._read_skill_file("web-research", "../../agent.yaml")   # chặn path traversal
    tools = {t.name: t for t in select_tools(["builtin.*"])}
    assert asyncio.run(tools["calculator"].invoke({"expression": "2**10 + sqrt(16)"})) == "1028.0"


def test_engine_loop_with_mcp(mcp_url):
    manifest = AgentManifest.model_validate({
        "name": "researcher", "model": {"model": "fake", "base_url": "http://x", "stream": False},
        "skills": ["web-research"], "tools": ["builtin.calculator"],
        "mcp_servers": [{"name": "probe", "url": mcp_url},
                        {"name": "dead", "url": "http://127.0.0.1:18799/mcp", "timeout_s": 3}],
    })
    llm = LLMClient(manifest.model, client=FakeClient("probe__echo"))
    engine = AgentEngine(manifest, llm, select_tools(manifest.tools),
                         SkillLibrary(ROOT / "agents" / "researcher" / "skills", manifest.skills),
                         MCPManager(manifest.mcp_servers))
    events = []

    async def emit(e):
        events.append(e)

    res = asyncio.run(engine.run([{"role": "user", "content": "hi"}], RunContext(kind="task", task_id="T1"), emit))
    assert res.status == "succeeded" and res.steps == 2
    assert "14" in res.output and "abab" in res.output
    types = [e.type for e in events]
    assert types[0] == "run_started" and types[-1] == "run_finished"
    assert any(e.type == "warning" for e in events)          # server 'dead' bị bỏ qua, không làm hỏng run
    sys_prompt = llm.client.chat.completions.calls[0]["messages"][0]["content"]
    assert "current_task_id: T1" in sys_prompt


def test_manifests_valid(monkeypatch):
    from agent_runtime.config import load_manifest
    for name in ("orchestrator", "researcher", "writer", "_template"):
        m = load_manifest(ROOT / "agents" / name)
        assert m.name and m.mcp_servers
