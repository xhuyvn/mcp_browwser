// API client + SSE helper (fetch-based, hỗ trợ POST + header Authorization)
import { AUTH_MODE, getAccessToken, login } from './auth'
export type AgentInfo = {
  name: string; version: string; description: string; status: 'online' | 'offline' | 'disabled'
  enabled: boolean; endpoint: string; tags: string[]
  model: { provider?: string; model?: string; fallback_models?: string[]
           engine?: { type: string; checkpointer?: string; approval_required_tools?: string[]; structured_output?: boolean } }
  skills: { name: string; description: string }[]
  tools: string[]
  mcp_servers: { name: string; url: string; connected: boolean; tools: string[]; error?: string | null }[]
  queue_depth: number | null; last_heartbeat: string | null; can_use?: boolean
}
export type Task = {
  id: string; agent: string; input: string
  status: 'queued' | 'running' | 'waiting_input' | 'succeeded' | 'failed' | 'cancelled'
  result: string | null; error: string | null; parent_id: string | null; root_id: string | null; depth: number
  source: string; created_by: string | null; created_by_name?: string | null; delegated_by?: string | null
  steps: number; duration_ms: number
  usage: Record<string, number>; created_at: string; started_at: string | null; finished_at: string | null
  metadata?: { interrupt?: Interrupt; approvals?: any[]; [k: string]: any }
  children?: Task[]
  approval?: ApprovalInfo | null
  can_cancel?: boolean
}
export type ApprovalInfo = { pending: boolean; tools: string[]; can_approve: boolean; reason: string
                             approver_roles: string[]; waiting_since?: string | null }
export type Me = { sub: string; name: string; email?: string | null; roles: string[]; kind: string; auth: string
                   permissions: string[]; auth_mode: string; maker_checker: boolean }
export type AuditEntry = { id: number; ts: string; actor: { sub: string; name: string; kind: string }; action: string
                           outcome: string; resource: { type: string; id: string }; ip: string | null; details: Record<string, any> }
export type PendingCall = { id: string; name: string; arguments: Record<string, any> }
export type Interrupt = { type?: string; message?: string; calls?: PendingCall[]; engine?: string; thread_id?: string }
export type TaskEvent = { id: number; task_id: string; type: string; data: Record<string, any>; ts: string }
export type AgentEvent = { type: string; data: Record<string, any>; ts?: number }

async function authHeaders(): Promise<Record<string, string>> {
  const t = await getAccessToken()
  return t ? { Authorization: `Bearer ${t}` } : {}
}

async function authFetch(path: string, init: RequestInit = {}): Promise<Response> {
  const res = await fetch(path, { ...init, headers: { ...(await authHeaders()), ...(init.headers || {}) } })
  if (res.status === 401 && AUTH_MODE === 'oidc') await login()     // phiên hết hạn => đăng nhập lại
  return res
}

export const hasPerm = (me: Me | null, perm: string) => !!me && me.permissions.includes(perm)

async function req<T>(path: string, init: RequestInit = {}): Promise<T> {
  const res = await authFetch(path, { ...init, headers: { 'Content-Type': 'application/json', ...(init.headers || {}) } })
  if (!res.ok) {
    let detail = res.statusText
    try { detail = (await res.json()).detail ?? detail } catch { /* ignore */ }
    throw new Error(`${res.status}: ${typeof detail === 'string' ? detail : JSON.stringify(detail)}`)
  }
  return res.json() as Promise<T>
}

export const api = {
  agents: () => req<AgentInfo[]>('/api/agents'),
  setAgentEnabled: (name: string, enabled: boolean) =>
    req<AgentInfo>(`/api/agents/${name}`, { method: 'PATCH', body: JSON.stringify({ enabled }) }),
  agentTools: (name: string) => req<any>(`/api/agents/${name}/tools`),
  tasks: (params: Record<string, string | number | boolean | undefined> = {}) => {
    const q = new URLSearchParams()
    Object.entries(params).forEach(([k, v]) => v !== undefined && v !== '' && q.set(k, String(v)))
    return req<Task[]>(`/api/tasks?${q}`)
  },
  task: (id: string) => req<Task>(`/api/tasks/${id}`),
  createTask: (agent: string, input: string) =>
    req<Task>('/api/tasks', { method: 'POST', body: JSON.stringify({ agent, input, source: 'ui' }) }),
  cancelTask: (id: string) => req<Task>(`/api/tasks/${id}/cancel`, { method: 'POST' }),
  approveTask: (id: string, approved: boolean, comment = '', calls: Record<string, boolean> = {}) =>
    req<Task>(`/api/tasks/${id}/approval`, { method: 'POST', body: JSON.stringify({ approved, comment, calls }) }),
  stats: () => req<any>('/api/stats'),
  me: () => req<Me>('/api/me'),
  approvals: () => req<{ count_actionable: number; items: Task[] }>('/api/approvals'),
  audit: (params: Record<string, string | number | undefined> = {}) => {
    const q = new URLSearchParams()
    Object.entries(params).forEach(([k, v]) => v !== undefined && v !== '' && q.set(k, String(v)))
    return req<AuditEntry[]>(`/api/audit?${q}`)
  },
  conversations: (agent?: string) => req<any[]>(`/api/conversations${agent ? `?agent=${agent}` : ''}`),
  messages: (cid: string) => req<any[]>(`/api/conversations/${cid}/messages`),
}

/** Đọc SSE từ fetch Response (dùng cho POST /chat và GET /tasks/:id/stream). */
export async function readSSE(res: Response, onEvent: (event: string, data: any) => void, signal?: AbortSignal) {
  if (!res.ok || !res.body) throw new Error(`HTTP ${res.status}`)
  const reader = res.body.getReader()
  const decoder = new TextDecoder()
  let buf = ''
  while (true) {
    if (signal?.aborted) break
    const { value, done } = await reader.read()
    if (done) break
    buf += decoder.decode(value, { stream: true })
    let idx: number
    while ((idx = buf.indexOf('\n\n')) >= 0) {
      const block = buf.slice(0, idx)
      buf = buf.slice(idx + 2)
      let ev = 'message'
      const data: string[] = []
      for (const line of block.split('\n')) {
        if (line.startsWith('event:')) ev = line.slice(6).trim()
        else if (line.startsWith('data:')) data.push(line.slice(5).trim())
      }
      if (!data.length) continue
      try { onEvent(ev, JSON.parse(data.join(''))) } catch { onEvent(ev, data.join('')) }
    }
  }
}

export function streamChat(agent: string, message: string, conversationId: string | null,
                           onEvent: (event: string, data: any) => void, signal?: AbortSignal) {
  return authFetch(`/api/agents/${agent}/chat`, {
    method: 'POST', signal,
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ message, conversation_id: conversationId }),
  }).then((res) => readSSE(res, onEvent, signal))
}

export function streamTask(taskId: string, after: number, onEvent: (event: string, data: any) => void,
                           signal?: AbortSignal) {
  return authFetch(`/api/tasks/${taskId}/stream?after=${after}`, { signal }).then((res) => readSSE(res, onEvent, signal))
}

export const fmtTime = (iso: string | null) => (iso ? new Date(iso).toLocaleString('vi-VN') : '—')
export const fmtMs = (ms: number) => (ms ? (ms < 1000 ? `${ms} ms` : `${(ms / 1000).toFixed(1).replace('.', ',')} s`) : '—')
