import ReactMarkdown from 'react-markdown'
import remarkGfm from 'remark-gfm'

export function Markdown({ text }: { text: string }) {
  return <div className="md"><ReactMarkdown remarkPlugins={[remarkGfm]}>{text}</ReactMarkdown></div>
}

const LABELS: Record<string, string> = {
  online: 'Online', offline: 'Offline', disabled: 'Tắt',
  queued: 'Chờ', running: 'Đang chạy', waiting_input: 'Chờ duyệt', succeeded: 'Thành công', failed: 'Lỗi', cancelled: 'Đã huỷ',
}

export function Badge({ status }: { status: string }) {
  return <span className={`badge badge-${status}`}>{LABELS[status] ?? status}</span>
}

export function ToolChip({ name, error, args, output }: { name: string; error?: boolean; args?: any; output?: string }) {
  return (
    <details className={`tool-chip ${error ? 'tool-error' : ''}`}>
      <summary>🔧 {name}{error ? ' ⚠' : ''}</summary>
      {args !== undefined && <pre>{JSON.stringify(args, null, 2)}</pre>}
      {output && <pre className="tool-output">{output}</pre>}
    </details>
  )
}
