import { useEffect, useState } from 'react'
import { NavLink, Navigate, Route, Routes, useNavigate } from 'react-router-dom'
import { Me, api, hasPerm } from './api'
import { AUTH_MODE, getStaticToken, handleCallback, login, logout, setStaticToken } from './auth'
import AgentsPage from './pages/AgentsPage'
import ApprovalsPage from './pages/ApprovalsPage'
import AuditPage from './pages/AuditPage'
import ChatPage from './pages/ChatPage'
import TaskDetailPage from './pages/TaskDetailPage'
import TasksPage from './pages/TasksPage'
import { MeContext } from './me'

function AuthCallback() {
  const nav = useNavigate()
  const [error, setError] = useState('')
  useEffect(() => { handleCallback().then((to) => nav(to, { replace: true })).catch((e) => setError(String(e))) }, [])
  return <div className="login">{error ? <div className="alert">Đăng nhập thất bại: {error}</div> : 'Đang đăng nhập…'}</div>
}

function LoginScreen({ error }: { error: string }) {
  const [token, setToken] = useState(getStaticToken())
  return (
    <div className="login">
      <div className="panel login-box">
        <div className="brand">⬡ AgentHub</div>
        {error && <div className="alert">{error}</div>}
        {AUTH_MODE === 'oidc' ? (
          <>
            <p className="muted">Đăng nhập bằng tài khoản tổ chức (SSO).</p>
            <button onClick={() => login()}>🔐 Đăng nhập</button>
          </>
        ) : (
          <>
            <p className="muted">Chế độ dev: nhập API token (xem <code>API_TOKENS</code> trong .env).</p>
            <input type="password" value={token} placeholder="API token" onChange={(e) => setToken(e.target.value)} />
            <button onClick={() => { setStaticToken(token); window.location.reload() }}>Vào</button>
          </>
        )}
      </div>
    </div>
  )
}

export default function App() {
  const [me, setMe] = useState<Me | null>(null)
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState('')
  const [pending, setPending] = useState(0)
  const isCallback = window.location.pathname === '/auth/callback'

  useEffect(() => {
    if (isCallback) { setLoading(false); return }
    api.me().then(setMe).catch((e) => setError(String(e).startsWith('Error: 401') ? '' : String(e))).finally(() => setLoading(false))
  }, [])

  useEffect(() => {                     // badge "Chờ duyệt": số task mình duyệt được
    if (!me || !hasPerm(me, 'tasks:approve')) return
    const load = () => api.approvals().then((r) => setPending(r.count_actionable)).catch(() => undefined)
    load(); const t = setInterval(load, 15000); return () => clearInterval(t)
  }, [me])

  if (isCallback) return <Routes><Route path="/auth/callback" element={<AuthCallback />} /></Routes>
  if (loading) return <div className="login">Đang tải…</div>
  if (!me) return <LoginScreen error={error} />

  return (
    <MeContext.Provider value={me}>
      <div className="layout">
        <aside className="sidebar">
          <div className="brand">⬡ AgentHub</div>
          <nav>
            <NavLink to="/agents">🤖 Agents</NavLink>
            {hasPerm(me, 'chat') && <NavLink to="/chat">💬 Chat</NavLink>}
            <NavLink to="/tasks">📋 Tasks</NavLink>
            {hasPerm(me, 'tasks:approve') && (
              <NavLink to="/approvals">🛂 Chờ duyệt {pending > 0 && <span className="count">{pending}</span>}</NavLink>
            )}
            {hasPerm(me, 'audit:read') && <NavLink to="/audit">📜 Audit</NavLink>}
          </nav>
          <div className="user-box">
            <b>{me.name}</b>
            <div>{me.roles.map((r) => <span key={r} className="tag">{r}</span>)}</div>
            <small className="muted">{me.auth}{me.kind === 'service' ? ' · service' : ''}</small>
            <button className="ghost small" onClick={() => logout()}>Đăng xuất</button>
          </div>
        </aside>
        <main className="content">
          <Routes>
            <Route path="/" element={<Navigate to="/agents" />} />
            <Route path="/agents" element={<AgentsPage />} />
            <Route path="/chat" element={<ChatPage />} />
            <Route path="/chat/:agent" element={<ChatPage />} />
            <Route path="/tasks" element={<TasksPage />} />
            <Route path="/tasks/:id" element={<TaskDetailPage />} />
            <Route path="/approvals" element={<ApprovalsPage />} />
            <Route path="/audit" element={<AuditPage />} />
            <Route path="*" element={<Navigate to="/agents" />} />
          </Routes>
        </main>
      </div>
    </MeContext.Provider>
  )
}
