import { useEffect, useRef, useState } from 'react'
import { Link, useParams } from 'react-router-dom'
import { Task, TaskEvent, api, fmtMs, fmtTime, streamTask } from '../api'
import { Badge, Markdown } from '../components'
import ApprovalPanel from './ApprovalPanel'

const ICON: Record<string, string> = {
  task_status: '🔄', run_started: '▶', step: '🧠', tool_call: '🔧', tool_result: '📥',
  message: '💭', warning: '⚠', error: '❌', run_finished: '🏁', cancel_requested: '✋',
  interrupt: '⏸', approval: '🛂', approval_submitted: '🙋',
}

function describe(e: TaskEvent): string {
  const d = e.data || {}
  switch (e.type) {
    case 'task_status': return `Trạng thái: ${d.status}${d.redelivered ? ' (chạy lại)' : ''}${d.error ? ` — ${d.error}` : ''}`
    case 'run_started': return `Bắt đầu chạy · engine ${d.engine ?? 'native'}${d.resumed ? ' · tiếp tục sau phê duyệt' : ''}`
    case 'interrupt': return `Tạm dừng chờ duyệt: ${(d.calls || []).map((c: any) => c.name).join(', ')}`
    case 'approval': return `${d.name}: ${d.approved ? 'được cho phép' : 'bị từ chối'}${d.comment ? ` — ${d.comment}` : ''}`
    case 'approval_submitted': return `${d.by} ${d.approved ? 'đã duyệt' : 'đã từ chối'}${d.comment ? `: ${d.comment}` : ''}`
    case 'step': return `Bước ${d.step}/${d.max_steps}: gọi LLM`
    case 'tool_call': return `Gọi ${d.name} (${d.source}) ${JSON.stringify(d.arguments ?? {}).slice(0, 160)}`
    case 'tool_result': return `${d.name} → ${d.is_error ? 'LỖI' : 'OK'} (${fmtMs(d.duration_ms)})`
    case 'message': return String(d.content || '').slice(0, 200)
    case 'warning': return `${d.message}: ${d.error ?? ''}`
    case 'run_finished': return `Kết thúc: ${d.status} · ${d.steps} bước · ${d.usage?.total_tokens ?? 0} tokens`
    default: return JSON.stringify(d).slice(0, 200)
  }
}

export default function TaskDetailPage() {
  const { id = '' } = useParams()
  const [task, setTask] = useState<Task | null>(null)
  const [events, setEvents] = useState<TaskEvent[]>([])
  const [error, setError] = useState('')
  const lastId = useRef(0)

  const refresh = () => api.task(id).then(setTask).catch((e) => setError(String(e)))

  useEffect(() => {
    setEvents([]); lastId.current = 0; refresh()
    const ctrl = new AbortController()
    streamTask(id, 0, (event, data) => {
      if (event === 'end') { refresh(); return }
      if (data && typeof data.id === 'number' && data.id > lastId.current) {
        lastId.current = data.id
        setEvents((p) => [...p, data as TaskEvent])
        if (event === 'task_status') refresh()
      }
    }, ctrl.signal).catch((e) => { if (!ctrl.signal.aborted) setError(String(e)) })
    const poll = setInterval(refresh, 5000)   // cập nhật danh sách task con
    return () => { ctrl.abort(); clearInterval(poll) }
  }, [id])

  if (!task) return <div>{error ? <div className="alert">{error}</div> : 'Đang tải…'}</div>
  const active = task.status === 'queued' || task.status === 'running' || task.status === 'waiting_input'

  return (
    <div>
      <p><Link to="/tasks">← Tasks</Link>{task.parent_id && <> · <Link to={`/tasks/${task.parent_id}`}>Task cha</Link></>}</p>
      <div className="card-head">
        <h1>Task <code>{task.id}</code></h1>
        <Badge status={task.status} />
      </div>
      {error && <div className="alert">{error}</div>}
      <div className="panel">
        <dl className="inline">
          <dt>Agent</dt><dd>{task.agent}</dd>
          <dt>Người tạo</dt><dd>{task.created_by_name || task.created_by}{task.delegated_by ? ` (giao qua ${task.delegated_by})` : ''} · {task.source}</dd>
          <dt>Tạo</dt><dd>{fmtTime(task.created_at)}</dd>
          <dt>Bắt đầu</dt><dd>{fmtTime(task.started_at)}</dd>
          <dt>Kết thúc</dt><dd>{fmtTime(task.finished_at)}</dd>
          <dt>Thời gian</dt><dd>{fmtMs(task.duration_ms)} · {task.steps} bước · {task.usage?.total_tokens ?? 0} tokens</dd>
        </dl>
        <h3>Yêu cầu</h3>
        <pre className="input">{task.input}</pre>
        {active && task.can_cancel && <button className="danger" onClick={() => api.cancelTask(task.id).then(refresh).catch((e) => setError(String(e)))}>✋ Huỷ task</button>}
      </div>

      {task.status === 'waiting_input' && <ApprovalPanel task={task} onDone={refresh} />}

      {task.children && task.children.length > 0 && (
        <div className="panel">
          <h3>Task con (giao qua MCP)</h3>
          <table className="table">
            <tbody>
              {task.children.map((c) => (
                <tr key={c.id}>
                  <td><Link to={`/tasks/${c.id}`}>{c.id.slice(0, 10)}…</Link></td>
                  <td>{c.agent}</td><td><Badge status={c.status} /></td>
                  <td className="ellipsis" title={c.input}>{c.input}</td><td>{fmtMs(c.duration_ms)}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}

      <div className="two-col">
        <div className="panel">
          <h3>Kết quả</h3>
          {task.result ? <Markdown text={task.result} /> : <p className="muted">{active ? 'Đang xử lý…' : '—'}</p>}
          {task.error && <div className="alert">{task.error}</div>}
        </div>
        <div className="panel">
          <h3>Timeline {active && <span className="pulse">● live</span>}</h3>
          <ul className="timeline">
            {events.map((e) => (
              <li key={e.id} className={`ev ev-${e.type}`}>
                <span className="ev-icon">{ICON[e.type] ?? '•'}</span>
                <span className="ev-time">{new Date(e.ts).toLocaleTimeString('vi-VN')}</span>
                <span className="ev-text">{describe(e)}</span>
              </li>
            ))}
          </ul>
        </div>
      </div>
    </div>
  )
}
