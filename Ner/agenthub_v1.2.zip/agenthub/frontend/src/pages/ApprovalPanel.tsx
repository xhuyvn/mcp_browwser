import { useState } from 'react'
import { Task, api } from '../api'

/** Khung phê duyệt tool khi task ở trạng thái waiting_input (LangGraph human-in-the-loop). */
export default function ApprovalPanel({ task, onDone }: { task: Task; onDone: () => void }) {
  const info = task.approval
  if (info && !info.can_approve) {
    return (
      <div className="panel approval">
        <h3>⏸ Task đang chờ phê duyệt</h3>
        <p>Tool chờ duyệt: {info.tools.map((t) => <span key={t} className="tag tag-bad">{t}</span>)}</p>
        <p className="muted">Bạn không duyệt được task này: {info.reason}</p>
        <p className="muted">Người có thể duyệt: vai trò {info.approver_roles.join(', ')}.</p>
      </div>
    )
  }
  return <ApprovalForm task={task} onDone={onDone} />
}

function ApprovalForm({ task, onDone }: { task: Task; onDone: () => void }) {
  const interrupt = task.metadata?.interrupt
  const calls = interrupt?.calls ?? []
  const [allow, setAllow] = useState<Record<string, boolean>>(() => Object.fromEntries(calls.map((c) => [c.id, true])))
  const [comment, setComment] = useState('')
  const [busy, setBusy] = useState(false)
  const [error, setError] = useState('')

  async function submit(mode: 'selected' | 'reject_all') {
    setBusy(true); setError('')
    try {
      if (mode === 'reject_all') await api.approveTask(task.id, false, comment)
      else {
        const anyAllowed = Object.values(allow).some(Boolean)
        await api.approveTask(task.id, anyAllowed, comment, allow)
      }
      onDone()
    } catch (e) { setError(String(e)) } finally { setBusy(false) }
  }

  return (
    <div className="panel approval">
      <h3>⏸ Agent đang chờ bạn phê duyệt</h3>
      <p className="muted">{interrupt?.message || 'Agent muốn chạy tool cần phê duyệt.'} Kiểm tra tham số trước khi cho phép.</p>
      {calls.map((c) => (
        <label key={c.id} className="approval-call">
          <input type="checkbox" checked={!!allow[c.id]} onChange={(e) => setAllow({ ...allow, [c.id]: e.target.checked })} />
          <div>
            <b>🔧 {c.name}</b> <small>({c.id})</small>
            <pre>{JSON.stringify(c.arguments, null, 2)}</pre>
          </div>
        </label>
      ))}
      <textarea rows={2} value={comment} onChange={(e) => setComment(e.target.value)}
                placeholder="Ghi chú cho agent (không bắt buộc), ví dụ: đổi tên file thành report-final.md" />
      {error && <div className="alert">{error}</div>}
      <div className="row">
        <button disabled={busy} onClick={() => submit('selected')}>✅ Cho phép tool đã chọn</button>
        <button disabled={busy} className="danger" onClick={() => submit('reject_all')}>⛔ Từ chối tất cả</button>
      </div>
      <small className="muted">Tool không được chọn sẽ bị từ chối; agent nhận lý do và tiếp tục bằng cách khác.</small>
    </div>
  )
}
