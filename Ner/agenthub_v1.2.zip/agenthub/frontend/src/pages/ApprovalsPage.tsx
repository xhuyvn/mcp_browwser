import { useEffect, useState } from 'react'
import { Link } from 'react-router-dom'
import { Task, api, fmtTime } from '../api'
import { Badge } from '../components'

/** Hộp thư phê duyệt: task đang chờ duyệt, tách "bạn duyệt được" và "chờ người khác". */
export default function ApprovalsPage() {
  const [items, setItems] = useState<Task[]>([])
  const [error, setError] = useState('')
  const load = () => api.approvals().then((r) => { setItems(r.items); setError('') }).catch((e) => setError(String(e)))
  useEffect(() => { load(); const t = setInterval(load, 10000); return () => clearInterval(t) }, [])

  const mine = items.filter((t) => t.approval?.can_approve)
  const others = items.filter((t) => !t.approval?.can_approve)
  const row = (t: Task) => (
    <tr key={t.id}>
      <td><Link to={`/tasks/${t.id}`}>{t.id.slice(0, 10)}…</Link></td>
      <td>{t.agent}</td>
      <td>{(t.approval?.tools || []).map((x) => <span key={x} className="tag tag-bad">{x}</span>)}</td>
      <td>{t.created_by_name || t.created_by}{t.delegated_by && <small className="muted"> (qua {t.delegated_by})</small>}</td>
      <td>{fmtTime(t.approval?.waiting_since || null)}</td>
      <td>{t.approval?.can_approve ? <Link to={`/tasks/${t.id}`}><button className="small">Xem & duyệt</button></Link>
                                   : <small className="muted">{t.approval?.reason}</small>}</td>
    </tr>
  )
  return (
    <div>
      <h1>Chờ duyệt</h1>
      {error && <div className="alert">{error}</div>}
      <div className="panel">
        <h3>Bạn có thể duyệt <Badge status="waiting_input" /> {mine.length}</h3>
        {mine.length ? (
          <table className="table"><thead><tr><th>Task</th><th>Agent</th><th>Tool chờ duyệt</th><th>Người yêu cầu</th><th>Chờ từ</th><th></th></tr></thead>
            <tbody>{mine.map(row)}</tbody></table>
        ) : <p className="muted">Không có việc nào cần bạn duyệt.</p>}
      </div>
      {others.length > 0 && (
        <div className="panel">
          <h3>Đang chờ người khác duyệt</h3>
          <table className="table"><tbody>{others.map(row)}</tbody></table>
        </div>
      )}
    </div>
  )
}
