import { useEffect, useState } from 'react'
import { useNavigate } from 'react-router-dom'
import { AgentInfo, api, fmtTime, hasPerm } from '../api'
import { useMe } from '../me'
import { Badge } from '../components'

export default function AgentsPage() {
  const [agents, setAgents] = useState<AgentInfo[]>([])
  const [stats, setStats] = useState<any>(null)
  const [error, setError] = useState('')
  const nav = useNavigate()
  const me = useMe()

  const load = () =>
    Promise.all([api.agents(), api.stats()])
      .then(([a, s]) => { setAgents(a); setStats(s); setError('') })
      .catch((e) => setError(String(e)))

  useEffect(() => { load(); const t = setInterval(load, 5000); return () => clearInterval(t) }, [])

  return (
    <div>
      <h1>Agents</h1>
      {error && <div className="alert">{error}</div>}
      {stats && (
        <div className="stats">
          <div className="stat"><b>{stats.agents.online}/{stats.agents.total}</b><span>agent online</span></div>
          <div className="stat"><b>{stats.tasks.running ?? 0}</b><span>đang chạy</span></div>
          <div className="stat"><b>{stats.tasks.queued ?? 0}</b><span>đang chờ</span></div>
          <div className="stat"><b>{stats.tasks.succeeded ?? 0}</b><span>thành công</span></div>
          <div className="stat"><b>{stats.tasks.failed ?? 0}</b><span>lỗi</span></div>
        </div>
      )}
      <div className="grid">
        {agents.map((a) => (
          <div className="card" key={a.name}>
            <div className="card-head">
              <h3>{a.name} <small>v{a.version}</small></h3>
              <Badge status={a.status} />
            </div>
            <p className="muted">{a.description}</p>
            <dl>
              <dt>Model</dt><dd><code>{a.model?.model || '—'}</code> <small>({a.model?.provider})</small></dd>
              <dt>Engine</dt>
              <dd>
                <span className="tag engine-tag">{a.model?.engine?.type ?? 'native'}</span>
                {a.model?.engine?.approval_required_tools?.length ? <span className="tag tag-bad" title={(a.model?.engine?.approval_required_tools ?? []).join(', ')}>🛂 cần duyệt</span> : null}
                {a.model?.engine?.structured_output ? <span className="tag tag-light">JSON schema</span> : null}
              </dd>
              <dt>Skills</dt><dd>{a.skills.map((s) => <span className="tag" key={s.name} title={s.description}>{s.name}</span>)}</dd>
              <dt>Tools</dt><dd>{a.tools.map((t) => <span className="tag tag-light" key={t}>{t}</span>)}</dd>
              <dt>MCP</dt>
              <dd>{a.mcp_servers.map((m) => (
                <span key={m.name} className={`tag ${m.connected ? 'tag-ok' : 'tag-bad'}`}
                      title={m.connected ? m.tools.join(', ') : m.error || 'chưa kết nối'}>
                  {m.connected ? '●' : '○'} {m.name} ({m.tools.length})
                </span>))}
              </dd>
              <dt>Hàng đợi</dt><dd>{a.queue_depth ?? 0} task</dd>
              <dt>Heartbeat</dt><dd>{fmtTime(a.last_heartbeat)}</dd>
            </dl>
            <div className="actions">
              <button onClick={() => nav(`/chat/${a.name}`)}
                      disabled={a.status !== 'online' || !a.can_use || !hasPerm(me, 'chat')}
                      title={a.can_use ? '' : 'Bạn không có quyền dùng agent này'}>💬 Chat</button>
              <button onClick={() => nav(`/tasks?agent=${a.name}`)} disabled={!a.can_use || !hasPerm(me, 'tasks:create')}>📋 Giao task</button>
              {hasPerm(me, 'agents:manage') && (
                <button className="ghost" onClick={() => api.setAgentEnabled(a.name, !a.enabled).then(load).catch((e) => setError(String(e)))}>
                  {a.enabled ? 'Tắt' : 'Bật'}
                </button>
              )}
            </div>
          </div>
        ))}
        {!agents.length && !error && <p className="muted">Chưa có agent nào đăng ký. Kiểm tra container agent.</p>}
      </div>
    </div>
  )
}
