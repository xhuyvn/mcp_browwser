import { useEffect, useState } from 'react'
import { Link } from 'react-router-dom'
import { AuditEntry, api, fmtTime } from '../api'

export default function AuditPage() {
  const [rows, setRows] = useState<AuditEntry[]>([])
  const [f, setF] = useState({ actor: '', action: '', outcome: '', resource_id: '' })
  const [error, setError] = useState('')
  const load = () => api.audit({ ...f, limit: 200 }).then((r) => { setRows(r); setError('') }).catch((e) => setError(String(e)))
  useEffect(() => { load() }, [])

  return (
    <div>
      <h1>Nhật ký audit</h1>
      {error && <div className="alert">{error}</div>}
      <div className="row filters">
        <input placeholder="Người thực hiện" value={f.actor} onChange={(e) => setF({ ...f, actor: e.target.value })} />
        <input placeholder="Hành động (vd. task.approve)" value={f.action} onChange={(e) => setF({ ...f, action: e.target.value })} />
        <input placeholder="Task / tài nguyên" value={f.resource_id} onChange={(e) => setF({ ...f, resource_id: e.target.value })} />
        <select value={f.outcome} onChange={(e) => setF({ ...f, outcome: e.target.value })}>
          <option value="">Mọi kết quả</option><option value="allow">allow</option><option value="deny">deny</option>
        </select>
        <button onClick={load}>Lọc</button>
      </div>
      <table className="table">
        <thead><tr><th>Thời gian</th><th>Người thực hiện</th><th>Hành động</th><th>Kết quả</th><th>Tài nguyên</th><th>Chi tiết</th></tr></thead>
        <tbody>
          {rows.map((r) => (
            <tr key={r.id}>
              <td>{fmtTime(r.ts)}</td>
              <td>{r.actor.name || r.actor.sub} <small className="muted">{r.actor.kind}</small></td>
              <td><code>{r.action}</code></td>
              <td><span className={`badge ${r.outcome === 'deny' ? 'badge-failed' : 'badge-succeeded'}`}>{r.outcome}</span></td>
              <td>{r.resource.type === 'task' && r.resource.id ? <Link to={`/tasks/${r.resource.id}`}>{r.resource.id.slice(0, 12)}…</Link>
                   : `${r.resource.type} ${r.resource.id}`}</td>
              <td className="ellipsis" title={JSON.stringify(r.details)}>{r.details.reason || JSON.stringify(r.details)}</td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  )
}
