import { useEffect, useState } from 'react'
import { Link, useNavigate, useSearchParams } from 'react-router-dom'
import { AgentInfo, Task, api, fmtMs, fmtTime, hasPerm } from '../api'
import { useMe } from '../me'
import { Badge } from '../components'

const EXAMPLES = [
  { agent: 'researcher', text: 'Tìm hiểu 3 điểm thay đổi chính của đặc tả MCP mới nhất, kèm link nguồn.' },
  { agent: 'writer', text: 'Viết báo cáo ngắn "Giới thiệu AgentHub" (5 mục) và lưu vào /workspace/reports.' },
  { agent: 'orchestrator', text: 'Nghiên cứu so sánh Ollama và OpenRouter cho việc chạy agent nội bộ, sau đó viết báo cáo Markdown lưu vào /workspace/reports và trả về đường dẫn file.' },
]

export default function TasksPage() {
  const [params, setParams] = useSearchParams()
  const nav = useNavigate()
  const me = useMe()
  const [agents, setAgents] = useState<AgentInfo[]>([])
  const [tasks, setTasks] = useState<Task[]>([])
  const [agent, setAgent] = useState(params.get('agent') || '')
  const [input, setInput] = useState('')
  const [status, setStatus] = useState('')
  const [rootOnly, setRootOnly] = useState(false)
  const [error, setError] = useState('')

  const load = () =>
    api.tasks({ status, agent: params.get('filter') || undefined, root_only: rootOnly || undefined, limit: 100 })
      .then((t) => { setTasks(t); setError('') }).catch((e) => setError(String(e)))

  useEffect(() => { api.agents().then((all) => { const a = all.filter((x) => x.can_use); setAgents(a); if (!agent && a.length) setAgent(a[0].name) }) }, [])
  useEffect(() => { load(); const t = setInterval(load, 3000); return () => clearInterval(t) }, [status, rootOnly, params])

  async function submit() {
    if (!agent || !input.trim()) return
    try {
      const t = await api.createTask(agent, input.trim())
      setInput('')
      nav(`/tasks/${t.id}`)
    } catch (e) { setError(String(e)) }
  }

  return (
    <div>
      <h1>Tasks</h1>
      {error && <div className="alert">{error}</div>}
      {hasPerm(me, 'tasks:create') && <div className="panel">
        <h3>Giao task mới</h3>
        <div className="row">
          <select value={agent} onChange={(e) => setAgent(e.target.value)}>
            {agents.map((a) => <option key={a.name} value={a.name}>{a.name} ({a.status})</option>)}
          </select>
          <div className="examples">
            {EXAMPLES.map((ex) => (
              <button key={ex.agent} className="ghost small" onClick={() => { setAgent(ex.agent); setInput(ex.text) }}>
                Ví dụ: {ex.agent}
              </button>
            ))}
          </div>
        </div>
        <textarea rows={4} value={input} onChange={(e) => setInput(e.target.value)}
                  placeholder="Mô tả task: mục tiêu, phạm vi, định dạng kết quả mong muốn…" />
        <button onClick={submit} disabled={!input.trim()}>🚀 Giao task</button>
      </div>}

      <div className="row filters">
        <select value={status} onChange={(e) => setStatus(e.target.value)}>
          <option value="">Mọi trạng thái</option>
          {['queued', 'running', 'waiting_input', 'succeeded', 'failed', 'cancelled'].map((s) => <option key={s}>{s}</option>)}
        </select>
        <select value={params.get('filter') || ''} onChange={(e) => setParams(e.target.value ? { filter: e.target.value } : {})}>
          <option value="">Mọi agent</option>
          {agents.map((a) => <option key={a.name}>{a.name}</option>)}
        </select>
        <label><input type="checkbox" checked={rootOnly} onChange={(e) => setRootOnly(e.target.checked)} /> Chỉ task gốc</label>
      </div>

      <table className="table">
        <thead><tr><th>Task</th><th>Agent</th><th>Trạng thái</th><th>Nội dung</th><th>Người tạo</th><th>Tạo lúc</th><th>Thời gian</th></tr></thead>
        <tbody>
          {tasks.map((t) => (
            <tr key={t.id}>
              <td><Link to={`/tasks/${t.id}`}>{t.id.slice(0, 10)}…</Link>{t.parent_id && <small className="muted"> ↳ con</small>}</td>
              <td>{t.agent}</td>
              <td><Badge status={t.status} /></td>
              <td className="ellipsis" title={t.input}>{t.input}</td>
              <td>{t.created_by_name || t.created_by}</td>
              <td>{fmtTime(t.created_at)}</td>
              <td>{fmtMs(t.duration_ms)}</td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  )
}
