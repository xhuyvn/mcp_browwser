import { useEffect, useRef, useState } from 'react'
import { useNavigate, useParams } from 'react-router-dom'
import { AgentInfo, api, streamChat } from '../api'
import { Markdown, ToolChip } from '../components'

type ToolItem = { id: string; name: string; args?: any; output?: string; error?: boolean }
type Msg = { role: 'user' | 'assistant'; content: string; tools?: ToolItem[]; status?: string; streaming?: boolean }

export default function ChatPage() {
  const { agent: agentParam } = useParams()
  const nav = useNavigate()
  const [agents, setAgents] = useState<AgentInfo[]>([])
  const [agent, setAgent] = useState(agentParam || '')
  const [convId, setConvId] = useState<string | null>(null)
  const [msgs, setMsgs] = useState<Msg[]>([])
  const [input, setInput] = useState('')
  const [busy, setBusy] = useState(false)
  const abortRef = useRef<AbortController | null>(null)
  const endRef = useRef<HTMLDivElement>(null)

  useEffect(() => { api.agents().then((all) => { const a = all.filter((x) => x.can_use); setAgents(a); if (!agent && a.length) setAgent(a[0].name) }) }, [])
  useEffect(() => { endRef.current?.scrollIntoView({ behavior: 'smooth' }) }, [msgs])
  useEffect(() => { setMsgs([]); setConvId(null); if (agent) nav(`/chat/${agent}`, { replace: true }) }, [agent])

  const patchLast = (fn: (m: Msg) => Msg) =>
    setMsgs((prev) => prev.map((m, i) => (i === prev.length - 1 ? fn(m) : m)))

  async function send() {
    const text = input.trim()
    if (!text || !agent || busy) return
    setInput('')
    setBusy(true)
    setMsgs((p) => [...p, { role: 'user', content: text }, { role: 'assistant', content: '', tools: [], streaming: true }])
    const ctrl = new AbortController()
    abortRef.current = ctrl
    try {
      await streamChat(agent, text, convId, (event, data) => {
        const d = data?.data ?? {}
        if (event === 'conversation') setConvId(data.conversation_id)
        else if (event === 'token') patchLast((m) => ({ ...m, content: m.content + (d.text || '') }))
        else if (event === 'message') patchLast((m) => ({ ...m, content: '' }))   // nội dung trung gian trước tool call
        else if (event === 'tool_call')
          patchLast((m) => ({ ...m, tools: [...(m.tools || []), { id: d.id, name: d.name, args: d.arguments }] }))
        else if (event === 'tool_result')
          patchLast((m) => ({ ...m, tools: (m.tools || []).map((t) => t.id === d.id ? { ...t, output: d.output, error: d.is_error } : t) }))
        else if (event === 'run_finished')
          patchLast((m) => ({ ...m, content: d.output || m.content || (d.error ? `⚠ ${d.error}` : ''), status: d.status, streaming: false }))
        else if (event === 'error') patchLast((m) => ({ ...m, content: `⚠ ${d.error || 'Lỗi'}`, streaming: false }))
      }, ctrl.signal)
    } catch (e) {
      if (!ctrl.signal.aborted) patchLast((m) => ({ ...m, content: `⚠ ${String(e)}`, streaming: false }))
    } finally {
      patchLast((m) => ({ ...m, streaming: false }))
      setBusy(false)
    }
  }

  return (
    <div className="chat">
      <div className="chat-head">
        <h1>Chat</h1>
        <select value={agent} onChange={(e) => setAgent(e.target.value)}>
          {agents.map((a) => <option key={a.name} value={a.name}>{a.name} ({a.status})</option>)}
        </select>
        <button className="ghost" onClick={() => { setMsgs([]); setConvId(null) }}>+ Hội thoại mới</button>
      </div>
      <div className="chat-body">
        {!msgs.length && <p className="muted">Bắt đầu trò chuyện với <b>{agent}</b>. Agent có thể gọi tool, skill và MCP server.</p>}
        {msgs.map((m, i) => (
          <div key={i} className={`bubble ${m.role}`}>
            {m.tools && m.tools.length > 0 && (
              <div className="tools">{m.tools.map((t) => <ToolChip key={t.id} name={t.name} args={t.args} output={t.output} error={t.error} />)}</div>
            )}
            {m.role === 'assistant' ? <Markdown text={m.content || (m.streaming ? '…' : '')} /> : <p>{m.content}</p>}
          </div>
        ))}
        <div ref={endRef} />
      </div>
      <div className="chat-input">
        <textarea value={input} placeholder="Nhập tin nhắn… (Enter để gửi, Shift+Enter xuống dòng)"
                  onChange={(e) => setInput(e.target.value)}
                  onKeyDown={(e) => { if (e.key === 'Enter' && !e.shiftKey) { e.preventDefault(); send() } }} />
        {busy ? <button onClick={() => abortRef.current?.abort()}>Dừng</button>
              : <button onClick={send} disabled={!input.trim()}>Gửi</button>}
      </div>
    </div>
  )
}
