// Đăng nhập: static token (dev) hoặc OIDC Authorization Code + PKCE (Keycloak, Entra ID, ...)
import { User, UserManager, WebStorageStateStore } from 'oidc-client-ts'

export const AUTH_MODE: 'static' | 'oidc' = import.meta.env.VITE_AUTH_MODE === 'oidc' ? 'oidc' : 'static'

// ---------------------------------------------------------------- static (dev)
// Token lưu sessionStorage (mất khi đóng tab) và KHÔNG nhúng sẵn vào bản build.
const TOKEN_KEY = 'agenthub_token'
export const getStaticToken = () => sessionStorage.getItem(TOKEN_KEY) || ''
export const setStaticToken = (t: string) => sessionStorage.setItem(TOKEN_KEY, t.trim())

// ---------------------------------------------------------------- OIDC
let manager: UserManager | null = null
export function oidc(): UserManager {
  if (!manager) {
    manager = new UserManager({
      authority: import.meta.env.VITE_OIDC_AUTHORITY,
      client_id: import.meta.env.VITE_OIDC_CLIENT_ID || 'agenthub-ui',
      redirect_uri: `${window.location.origin}/auth/callback`,
      post_logout_redirect_uri: window.location.origin,
      response_type: 'code',                 // Authorization Code + PKCE (oidc-client-ts tự tạo code_challenge)
      scope: 'openid profile email',
      automaticSilentRenew: true,            // dùng refresh token, không cần iframe
      userStore: new WebStorageStateStore({ store: window.sessionStorage }),
    })
  }
  return manager
}

export async function currentUser(): Promise<User | null> {
  if (AUTH_MODE !== 'oidc') return null
  const u = await oidc().getUser()
  return u && !u.expired ? u : null
}

export async function getAccessToken(): Promise<string> {
  if (AUTH_MODE === 'static') return getStaticToken()
  const u = await currentUser()
  if (u) return u.access_token
  try { return (await oidc().signinSilent())?.access_token ?? '' } catch { return '' }
}

export async function login(returnTo = window.location.pathname + window.location.search) {
  if (AUTH_MODE === 'oidc') await oidc().signinRedirect({ state: { returnTo } })
}

export async function logout() {
  if (AUTH_MODE === 'oidc') await oidc().signoutRedirect()
  else { sessionStorage.removeItem(TOKEN_KEY); window.location.reload() }
}

/** Xử lý /auth/callback: đổi code lấy token rồi quay về trang trước khi đăng nhập. */
export async function handleCallback(): Promise<string> {
  const u = await oidc().signinRedirectCallback()
  const st = (u.state as { returnTo?: string } | undefined)?.returnTo
  return st && st.startsWith('/') && !st.startsWith('//') ? st : '/'     // chống open redirect
}
