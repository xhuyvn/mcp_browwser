# AgentHub — Nền tảng quản lý AI Agent (FE/BE + Agent Template + MCP)

Quản lý agent, **chat với agent**, **giao task – theo dõi realtime – nhận kết quả**; agent chạy trên API
**OpenAI-compatible** (Ollama, OpenRouter…), có **Skills + Tools + MCP**, mỗi agent và mỗi MCP server một container.

📐 Thiết kế: [docs/BLUEPRINT.md](docs/BLUEPRINT.md) · 🧩 Tạo agent mới: [docs/AGENT_TEMPLATE.md](docs/AGENT_TEMPLATE.md) · 🧠 Chọn engine: [docs/ENGINES.md](docs/ENGINES.md) · 🔐 Bảo mật: [docs/SECURITY.md](docs/SECURITY.md)

> **v1.2**: đăng nhập **OIDC** (Keycloak demo, Entra ID…) + API key; **RBAC** (viewer / operator / approver / admin) theo `config/policy.yaml`; **maker-checker** khi duyệt tool; hộp thư **Chờ duyệt** + webhook nhắc việc + hết hạn tự động; **audit log**; rate limit; token riêng từng agent.

> **v1.1**: agent chọn được engine `native` · `pydantic_ai` (kết quả JSON đúng schema) · `langgraph` (checkpoint + **con người duyệt tool**). Agent `writer` trong demo dùng LangGraph: trước khi ghi file, task chuyển sang **Chờ duyệt**.

## Thành phần
| | |
|---|---|
| `frontend/` | React + Vite: Agents · Chat · Tasks · Task detail (timeline SSE) |
| `backend/` | FastAPI control plane: registry, task queue (Redis Streams), SSE, chat proxy |
| `agent-runtime/` | Template runtime dùng chung cho mọi agent; engine: native / Pydantic AI / LangGraph |
| `agents/` | `orchestrator`, `researcher`, `writer` + `_template` |
| `mcp-servers/agent-manager` | **MCP để quản lý agent / giao & theo dõi task** |
| `mcp-servers/bridge` | Chạy MCP server miễn phí: duckduckgo, fetch, time, filesystem, memory |

## Chạy nhanh
Yêu cầu: Docker + Docker Compose v2; một trong hai: **Ollama** (máy host) hoặc **API key OpenRouter**.

```bash
cp .env.example .env          # chọn Cách A (Ollama) hoặc Cách B (OpenRouter)
ollama pull qwen3:8b          # nếu dùng Ollama
docker compose up -d --build
```
- UI: http://localhost:3000 — chế độ dev đăng nhập bằng token: `dev-operator-token` (alice, giao việc), `dev-approver-token` (bob, duyệt), `dev-admin-token` (admin). Bản OIDC: docs/SECURITY.md §6.2
- API docs: http://localhost:8000/docs
- MCP agent-manager: http://localhost:8090/mcp

> Khuyến nghị hybrid: orchestrator dùng model mạnh qua OpenRouter (`ORCHESTRATOR_PROVIDER=openrouter`,
> `ORCHESTRATOR_MODEL=...`, `OPENROUTER_API_KEY=...`), researcher/writer dùng Ollama local.

## Demo
```bash
pip install "mcp>=1.23,<2"
python scripts/demo_mcp_client.py        # 3 kịch bản qua MCP; script hỏi bạn duyệt khi writer muốn ghi file
AUTO_APPROVE=1 python scripts/demo_mcp_client.py   # tự duyệt (không hỏi)
bash scripts/demo_rest.sh researcher     # REST + SSE
make scale                               # researcher x3 replicas (cùng consumer group)
```
Hoặc trên UI: **Tasks → Ví dụ: orchestrator → Giao task** → xem cây task con và timeline realtime.

### Kết nối Claude Desktop / Cursor tới AgentHub (MCP)
```json
{
  "mcpServers": {
    "agenthub": {
      "command": "npx",
      "args": ["-y", "mcp-remote", "http://localhost:8090/mcp", "--header", "Authorization: Bearer <API key hoặc token của bạn>"]
    }
  }
}
```

## Kiểm thử
```bash
make test     # unit + integration test agent runtime (LLM giả lập + MCP server thật in-process)
```

## Sự cố thường gặp
| Hiện tượng | Xử lý |
|---|---|
| Agent `offline` | `docker compose logs agent-researcher` — kiểm tra `LLM_*`, backend healthy |
| MCP `○` (chưa kết nối) trên thẻ agent | MCP container chưa sẵn sàng; agent tự probe lại mỗi 15s |
| Model không gọi tool | Dùng model hỗ trợ tools; với Ollama chọn qwen3 / llama3.1+; tắt `stream` nếu provider lỗi streaming+tools |
| OpenRouter 429 | Thêm `LLM_FALLBACK_MODELS` hoặc dùng model trả phí |
| Task writer kẹt ở "Chờ duyệt" | Mở trang chi tiết task và bấm Cho phép / Từ chối (xem docs/ENGINES.md) |
