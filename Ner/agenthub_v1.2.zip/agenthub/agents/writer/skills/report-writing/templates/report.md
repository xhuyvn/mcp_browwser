# {Tiêu đề báo cáo}

> Ngày: {YYYY-MM-DD} · Người thực hiện: AgentHub (researcher + writer)

## 1. Tóm tắt điều hành
{3–5 câu: kết luận quan trọng nhất trước}

## 2. Bối cảnh
{Vì sao vấn đề quan trọng}

## 3. Phát hiện chính
### 3.1 {Chủ đề}
{Nội dung} ([nguồn](url))

## 4. So sánh / số liệu
| Tiêu chí | A | B | Ghi chú |
|---|---|---|---|

## 5. Khuyến nghị
1. ...

## 6. Thông tin còn thiếu & rủi ro
- ...

## Nguồn tham khảo
- [Tiêu đề](url)
