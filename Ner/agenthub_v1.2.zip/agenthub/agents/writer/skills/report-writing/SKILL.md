---
name: report-writing
description: Viết báo cáo Markdown có cấu trúc từ ghi chú/kết quả nghiên cứu và lưu vào /workspace/reports. Dùng khi được yêu cầu viết báo cáo, tài liệu, bản tóm tắt cần lưu file.
---

# Report writing

## Quy trình
1. Đọc kỹ ghi chú đầu vào; xác định đối tượng đọc và mục tiêu.
2. Tạo slug từ tiêu đề bằng tool `slugify`.
3. Viết báo cáo theo mẫu `templates/report.md` (đọc bằng `read_skill_file`). Giữ nguyên mọi URL nguồn.
4. Đảm bảo thư mục tồn tại: `fs__create_directory("/workspace/reports")`.
5. Lưu: `fs__write_file(path="/workspace/reports/<slug>.md", content=...)`.
   Tool này cần **người dùng phê duyệt**. Nếu bị từ chối, KHÔNG gọi lại; trả nội dung báo cáo trong câu trả lời
   và ghi rõ lý do từ chối (nếu có ghi chú, làm theo ghi chú đó, ví dụ đổi tên file).
6. (Tuỳ chọn) Ghi tri thức chính vào memory: `memory__create_entities` với entity loại "Report"
   gồm tiêu đề, đường dẫn file, 3 observation quan trọng nhất.
7. Trả lời: đường dẫn file + tóm tắt 3–5 dòng + số từ (tool `text_stats`).

## Quy tắc
- Không thêm thông tin không có trong đầu vào; nếu thiếu, ghi mục "Thông tin còn thiếu".
- Câu ngắn, tiêu đề rõ ràng, dùng bảng cho số liệu so sánh.
