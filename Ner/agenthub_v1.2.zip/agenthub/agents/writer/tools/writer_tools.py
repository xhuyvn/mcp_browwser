"""Custom tools cho writer."""
import re
import unicodedata
from typing import Annotated

from pydantic import Field

from agent_runtime.tools import tool


@tool(description="Đếm số từ, số dòng, số tiêu đề Markdown của văn bản.")
def text_stats(text: Annotated[str, Field(description="Nội dung Markdown")]) -> dict:
    return {
        "words": len(text.split()),
        "lines": text.count("\n") + 1,
        "headings": len(re.findall(r"^#{1,6} ", text, flags=re.M)),
    }


@tool()
def slugify(title: str, max_len: int = 60) -> str:
    """Chuyển tiêu đề (có dấu tiếng Việt) thành slug an toàn để đặt tên file."""
    s = unicodedata.normalize("NFD", title.replace("đ", "d").replace("Đ", "D"))
    s = "".join(ch for ch in s if unicodedata.category(ch) != "Mn")
    s = re.sub(r"[^a-zA-Z0-9]+", "-", s).strip("-").lower()
    return s[:max_len].rstrip("-") or "untitled"
