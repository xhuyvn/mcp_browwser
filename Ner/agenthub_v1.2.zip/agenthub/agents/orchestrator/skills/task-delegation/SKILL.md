---
name: task-delegation
description: Quy trình chia nhỏ yêu cầu, giao task cho agent chuyên trách qua MCP (agents__*), theo dõi và tổng hợp kết quả. Dùng cho mọi yêu cầu nhiều bước hoặc cần nghiên cứu + viết.
---

# Task delegation (giao việc qua MCP agent-manager)

## Công cụ
- `agents__list_agents` — xem agent nào đang online và chuyên môn của chúng.
- `agents__assign_task(agent, instruction, parent_task_id, wait_seconds)` — giao 1 task.
- `agents__assign_tasks_parallel(assignments, parent_task_id, wait_seconds)` — giao nhiều task độc lập cùng lúc.
- `agents__wait_for_task(task_id, timeout_seconds)` — chờ đến khi task kết thúc, nhận kết quả.
- `agents__get_task(task_id)` / `agents__list_tasks(...)` — theo dõi trạng thái.
- `agents__cancel_task(task_id)` — huỷ task không còn cần.

## Quy trình
1. **Khảo sát**: gọi `agents__list_agents(only_online=true)`; chỉ chọn agent có mô tả phù hợp.
2. **Lập kế hoạch** (ngắn, trong đầu): chia yêu cầu thành 1–4 task con; xác định task nào độc lập
   (chạy song song) và task nào phụ thuộc (chạy tuần tự, truyền kết quả bước trước vào instruction bước sau).
3. **Giao việc**: instruction phải gồm: mục tiêu, phạm vi, định dạng đầu ra mong muốn, ràng buộc
   (ngôn ngữ, độ dài, đường dẫn file). Luôn truyền `parent_task_id` = `current_task_id` trong runtime_context.
4. **Theo dõi**: dùng `wait_for_task` (timeout 180–300s). Nếu `status` vẫn là queued/running thì gọi lại;
   nếu `failed` thì đọc `error`, sửa instruction và giao lại tối đa 1 lần.
   Nếu `waiting_input`: task con đang **chờ con người phê duyệt tool** (ví dụ writer muốn ghi file).
   KHÔNG tự duyệt. Gọi `wait_for_task(task_id, timeout_seconds=300, stop_on_waiting_input=false)` tối đa 3 lần
   để chờ người dùng duyệt trên UI; nếu vẫn chờ, kết thúc và ghi rõ task id cần người dùng duyệt.
5. **Tổng hợp**: kết hợp kết quả, kiểm tra mâu thuẫn, trả lời người dùng.

## Mẫu phân công điển hình
- "Nghiên cứu X rồi viết báo cáo":
  1) `researcher`: "Nghiên cứu X ... trả về các phát hiện chính kèm URL nguồn (Markdown)."
  2) `writer` (sau khi có kết quả 1): "Viết báo cáo từ ghi chú sau ... lưu vào /workspace/reports/<slug>.md, trả về đường dẫn và tóm tắt."

## Định dạng báo cáo cuối
```
## Kết quả
<tóm tắt 3-6 câu>

## Task con
| Task ID | Agent | Trạng thái | Ghi chú |

## Sản phẩm
- Đường dẫn file / link nguồn
```
