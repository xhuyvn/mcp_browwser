"""Custom tools cho researcher."""
from urllib.parse import urlparse

from agent_runtime.tools import tool


@tool(description="Lấy tên miền từ danh sách URL và đếm số nguồn khác nhau (để kiểm tra độ đa dạng nguồn).")
def source_diversity(urls: list[str]) -> dict:
    domains = sorted({urlparse(u).netloc.lower().removeprefix("www.") for u in urls if u.startswith("http")})
    return {"unique_domains": len(domains), "domains": domains}
