# Checklist chất lượng nghiên cứu
- [ ] Mỗi phát hiện có ít nhất 1 URL thật đã được đọc (không chỉ snippet search).
- [ ] Số liệu có ngày/thời điểm.
- [ ] Ghi rõ mâu thuẫn giữa các nguồn (nếu có).
- [ ] Không quá 400 từ cho phần phát hiện chính, trừ khi được yêu cầu.
- [ ] Ngôn ngữ đầu ra theo yêu cầu (mặc định tiếng Việt).
