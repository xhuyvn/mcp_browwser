"""Custom tools của agent. Mọi hàm có @tool sẽ được nạp khi container khởi động.

Schema JSON của tool được sinh tự động từ type hints; docstring = mô tả cho LLM.
Hàm có thể là sync (chạy trong thread) hoặc async.
"""
from typing import Annotated

from pydantic import Field

from agent_runtime.tools import tool


@tool(description="Đếm số từ và số ký tự của một đoạn văn bản.")
def text_stats(text: Annotated[str, Field(description="Văn bản cần đếm")]) -> dict:
    return {"words": len(text.split()), "chars": len(text)}


@tool()
async def slugify(title: str, max_len: int = 60) -> str:
    """Chuyển tiêu đề thành slug an toàn cho tên file (bỏ dấu tiếng Việt)."""
    import re
    import unicodedata

    s = unicodedata.normalize("NFD", title.replace("đ", "d").replace("Đ", "D"))
    s = "".join(ch for ch in s if unicodedata.category(ch) != "Mn")
    s = re.sub(r"[^a-zA-Z0-9]+", "-", s).strip("-").lower()
    return s[:max_len] or "untitled"
