---
name: example-skill
description: Ví dụ skill — dùng khi người dùng yêu cầu "tóm tắt có cấu trúc". Mô tả này luôn nằm trong system prompt, nên viết rõ KHI NÀO dùng.
allowed-tools: current_time
---

# Tóm tắt có cấu trúc

## Khi nào dùng
Người dùng yêu cầu tóm tắt tài liệu / nội dung dài thành dạng có cấu trúc.

## Quy trình
1. Xác định mục tiêu của người đọc.
2. Trích 3–5 ý chính, mỗi ý 1 câu.
3. Liệt kê số liệu quan trọng (nếu có).
4. Kết thúc bằng mục "Việc cần làm tiếp".

## Định dạng đầu ra
Dùng mẫu trong `templates/summary.md` (đọc bằng tool `read_skill_file`).
