"""MCP server "agent-manager" — biến Control Plane của AgentHub thành bộ tool MCP.

Bất kỳ MCP client nào (agent Orchestrator, Claude Desktop, Cursor, VS Code, script...) đều có thể:
  list_agents · assign_task · assign_tasks_parallel · get_task · wait_for_task · list_tasks · cancel_task

Chạy: python server.py  (Streamable HTTP, stateless, endpoint /mcp, cổng 8080)
"""
from __future__ import annotations

import asyncio
import os
from typing import Annotated, Any, Literal

import httpx
from mcp.server.fastmcp import Context, FastMCP
from pydantic import BaseModel, Field

BACKEND_URL = os.environ.get("BACKEND_URL", "http://backend:8000").rstrip("/")
SERVICE_TOKEN = os.environ.get("AGENTHUB_API_TOKEN", "")
ALLOW_FALLBACK = os.environ.get("ALLOW_SERVICE_TOKEN_FALLBACK", "false").lower() == "true"
TERMINAL = {"succeeded", "failed", "cancelled"}
WAITING = "waiting_input"          # task chờ con người phê duyệt tool

mcp = FastMCP(
    "agenthub-agent-manager",
    instructions=(
        "Quản lý các AI agent của AgentHub: liệt kê agent, giao task, theo dõi tiến độ và nhận kết quả. "
        "Quy trình chuẩn: list_agents -> assign_task -> wait_for_task (lặp lại nếu còn running). "
        "Task ở trạng thái waiting_input đang chờ con người duyệt tool: xem get_task, rồi approve_task."
    ),
    host=os.environ.get("HOST", "0.0.0.0"),
    port=int(os.environ.get("PORT", "8080")),
    stateless_http=True,
)


def _token(ctx: Context | None) -> str:
    """Dùng token của NGƯỜI GỌI (Authorization header) để backend phân quyền đúng chủ thể.

    Không có token => từ chối, trừ khi bật ALLOW_SERVICE_TOKEN_FALLBACK (chỉ cho dev): nếu bật, ai kết nối
    được tới cổng MCP cũng mượn được quyền của service token.
    """
    if ctx is not None:
        try:
            req = ctx.request_context.request
            auth = req.headers.get("authorization", "") if req is not None else ""
            if auth[:7].lower() == "bearer " and auth[7:].strip():
                return auth[7:].strip()
        except Exception:  # noqa: BLE001
            pass
    if ALLOW_FALLBACK and SERVICE_TOKEN:
        return SERVICE_TOKEN
    raise ValueError("Thiếu header Authorization: Bearer <token> (OIDC access token hoặc API key của bạn)")


async def _api(method: str, path: str, ctx: Context | None = None, **kw: Any) -> Any:
    async with httpx.AsyncClient(base_url=BACKEND_URL, timeout=30,
                                 headers={"Authorization": f"Bearer {_token(ctx)}"}) as c:
        r = await c.request(method, path, **kw)
        if r.status_code >= 400:
            detail = r.json().get("detail") if r.headers.get("content-type", "").startswith("application/json") else r.text
            if r.status_code in (401, 403):
                raise ValueError(f"Không có quyền ({r.status_code}): {detail}")
            raise ValueError(f"Backend {r.status_code}: {detail}")
        return r.json()


def _slim(task: dict[str, Any]) -> dict[str, Any]:
    keys = ("id", "agent", "status", "input", "result", "error", "parent_id", "created_at",
            "started_at", "finished_at", "steps", "duration_ms")
    out = {k: task.get(k) for k in keys if k in task}
    interrupt = (task.get("metadata") or {}).get("interrupt")
    if task.get("status") == WAITING and interrupt:
        out["pending_approval"] = interrupt
    if isinstance(out.get("input"), str) and len(out["input"]) > 500:
        out["input"] = out["input"][:500] + "…"
    return out


async def _wait(task_id: str, timeout_seconds: int, ctx: Context | None,
                stop_on_waiting_input: bool = True) -> dict[str, Any]:
    timeout_seconds = max(1, min(int(timeout_seconds), 600))
    loop = asyncio.get_running_loop()
    deadline = loop.time() + timeout_seconds
    delay = 1.0
    while True:
        task = await _api("GET", f"/api/tasks/{task_id}", ctx)
        waiting_stop = stop_on_waiting_input and task["status"] == WAITING
        if task["status"] in TERMINAL or waiting_stop or loop.time() >= deadline:
            out = _slim(task)
            if task["status"] == WAITING:
                out["note"] = ("Task đang CHỜ CON NGƯỜI PHÊ DUYỆT tool (xem pending_approval). "
                               "Không tự duyệt thay người dùng — hãy báo lại cho người dùng.")
            elif task["status"] not in TERMINAL:
                out["note"] = "Chưa xong — gọi lại wait_for_task để tiếp tục chờ."
            return out
        if ctx is not None:
            try:
                await ctx.report_progress(progress=loop.time() - (deadline - timeout_seconds), total=timeout_seconds,
                                          message=f"{task_id}: {task['status']}")
            except Exception:  # noqa: BLE001
                pass
        await asyncio.sleep(min(delay, max(0.1, deadline - loop.time())))
        delay = min(delay * 1.5, 5.0)


# ------------------------------------------------------------------ tools
@mcp.tool()
async def list_agents(ctx: Context, only_online: bool = False) -> list[dict[str, Any]]:
    """Liệt kê agent đã đăng ký: tên, mô tả, trạng thái online/offline, skills, MCP servers, model."""
    agents = await _api("GET", "/api/agents", ctx)
    out = []
    for a in agents:
        if only_online and a.get("status") != "online":
            continue
        out.append({
            "name": a["name"], "description": a.get("description"), "status": a.get("status"),
            "skills": [s.get("name") for s in a.get("skills") or []],
            "mcp_servers": [m.get("name") for m in a.get("mcp_servers") or []],
            "model": (a.get("model") or {}).get("model"),
            "queue_depth": a.get("queue_depth"),
        })
    return out


@mcp.tool()
async def assign_task(
    ctx: Context,
    agent: Annotated[str, Field(description="Tên agent nhận việc, ví dụ 'researcher'")],
    instruction: Annotated[str, Field(description="Mô tả task tự đủ ngữ cảnh: mục tiêu, phạm vi, định dạng đầu ra")],
    parent_task_id: Annotated[str | None, Field(description="ID task cha (truyền current_task_id nếu có)")] = None,
    wait_seconds: Annotated[int, Field(ge=0, le=600, description="Chờ kết quả tối đa N giây (0 = trả về ngay)")] = 0,
) -> dict[str, Any]:
    """Giao 1 task cho agent. Trả về task (id, status). Nếu wait_seconds>0 sẽ chờ và trả kết quả."""
    task = await _api("POST", "/api/tasks", ctx, json={
        "agent": agent, "input": instruction, "parent_id": parent_task_id, "source": "mcp",
    })
    if wait_seconds > 0:
        return await _wait(task["id"], wait_seconds, ctx)
    return _slim(task)


class Assignment(BaseModel):
    agent: str
    instruction: str


@mcp.tool()
async def assign_tasks_parallel(
    ctx: Context,
    assignments: list[Assignment],
    parent_task_id: str | None = None,
    wait_seconds: Annotated[int, Field(ge=0, le=600)] = 0,
) -> list[dict[str, Any]]:
    """Giao nhiều task độc lập cùng lúc (fan-out). Nếu wait_seconds>0 sẽ chờ tất cả (fan-in)."""
    tasks = await asyncio.gather(*[
        _api("POST", "/api/tasks", ctx, json={"agent": a.agent, "input": a.instruction,
                                              "parent_id": parent_task_id, "source": "mcp"})
        for a in assignments
    ])
    if wait_seconds > 0:
        return list(await asyncio.gather(*[_wait(t["id"], wait_seconds, ctx) for t in tasks]))
    return [_slim(t) for t in tasks]


@mcp.tool()
async def get_task(ctx: Context, task_id: str, include_events: bool = False) -> dict[str, Any]:
    """Xem trạng thái/kết quả của 1 task; include_events=true để xem timeline (tool calls, bước chạy)."""
    task = await _api("GET", f"/api/tasks/{task_id}", ctx)
    out = _slim(task)
    out["children"] = [_slim(c) for c in task.get("children") or []]
    if include_events:
        events = await _api("GET", f"/api/tasks/{task_id}/events", ctx, params={"limit": 100})
        out["events"] = [{"type": e["type"], "data": {k: v for k, v in (e.get("data") or {}).items()
                                                      if k in ("name", "step", "is_error", "status", "message", "error")}}
                         for e in events]
    return out


@mcp.tool()
async def wait_for_task(
    ctx: Context,
    task_id: str,
    timeout_seconds: Annotated[int, Field(ge=1, le=600)] = 180,
    stop_on_waiting_input: Annotated[bool, Field(description=(
        "true: trả về ngay khi task chuyển sang chờ con người duyệt; "
        "false: tiếp tục chờ trong lúc người dùng duyệt trên UI"))] = True,
) -> dict[str, Any]:
    """Chờ task kết thúc (succeeded/failed/cancelled), chuyển sang chờ duyệt, hoặc hết timeout."""
    return await _wait(task_id, timeout_seconds, ctx, stop_on_waiting_input)


@mcp.tool()
async def list_tasks(
    ctx: Context,
    status: Literal["queued", "running", "waiting_input", "succeeded", "failed", "cancelled"] | None = None,
    agent: str | None = None,
    parent_task_id: str | None = None,
    limit: Annotated[int, Field(ge=1, le=100)] = 20,
) -> list[dict[str, Any]]:
    """Liệt kê task mới nhất, lọc theo trạng thái / agent / task cha."""
    params = {k: v for k, v in {"status": status, "agent": agent, "parent_id": parent_task_id,
                                "limit": limit}.items() if v is not None}
    return [_slim(t) for t in await _api("GET", "/api/tasks", ctx, params=params)]


@mcp.tool()
async def cancel_task(ctx: Context, task_id: str) -> dict[str, Any]:
    """Huỷ task đang chờ hoặc đang chạy."""
    return _slim(await _api("POST", f"/api/tasks/{task_id}/cancel", ctx))


@mcp.tool()
async def approve_task(
    ctx: Context,
    task_id: str,
    approved: Annotated[bool, Field(description="true = cho phép chạy các tool đang chờ, false = từ chối")],
    comment: Annotated[str, Field(description="Lý do / ghi chú gửi cho agent")] = "",
    calls: Annotated[dict[str, bool] | None, Field(description="Duyệt riêng từng tool call: {call_id: true|false}")] = None,
) -> dict[str, Any]:
    """Phê duyệt hoặc từ chối các tool mà task đang chờ (trạng thái waiting_input). Agent sẽ chạy tiếp.

    Chỉ dùng khi NGƯỜI DÙNG đã đưa ra quyết định; agent không được tự duyệt thay người dùng.
    Backend kiểm tra: người gọi có quyền duyệt tool đó và không phải người tạo task (maker-checker)."""
    return _slim(await _api("POST", f"/api/tasks/{task_id}/approval", ctx,
                            json={"approved": approved, "comment": comment, "calls": calls or {}}))


@mcp.resource("agenthub://agents")
async def agents_resource() -> str:
    """Danh sách agent (resource dạng JSON)."""
    import json
    return json.dumps(await list_agents(None), ensure_ascii=False, indent=2)


if __name__ == "__main__":
    mcp.run(transport="streamable-http")
