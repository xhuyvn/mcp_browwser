"""Nghiệp vụ task: tạo/giao task, ghi event + phát realtime, chuyển trạng thái, dọn task treo."""
from __future__ import annotations

import logging
import uuid
from datetime import timedelta
from typing import Any

from fastapi import HTTPException
from sqlalchemy import select, update
from sqlalchemy.ext.asyncio import AsyncSession

from .authz import Principal
from .bus import Bus
from .config import settings
from .models import TERMINAL, WAITING, Agent, Task, TaskEvent, utcnow
from .notify import build_payload, notify

log = logging.getLogger("backend.tasks")


class State:
    bus: Bus | None = None


state = State()


def bus() -> Bus:
    assert state.bus is not None, "Bus chưa khởi tạo"
    return state.bus


class Forbidden(Exception):
    """Vi phạm phân quyền — route chuyển thành 403 + ghi audit."""


def _policy():
    from .security import policy        # import trễ để tránh vòng import
    return policy


async def resolve_owner(db: AsyncSession, p: Principal, agent: str, parent_id: str | None) -> tuple[str, dict[str, Any]]:
    """Xác định task mới thuộc về ai và kiểm tra quyền giao việc.

    * Người dùng giao task gốc     : cần tasks:create + quyền dùng agent.
    * Service account (orchestrator): cần tasks:delegate, task cha phải đang chạy & thuộc agent của nó;
      task con mang danh NGƯỜI TẠO TASK GỐC và bị giới hạn bởi quyền của người đó (không leo thang quyền).
    """
    pol = _policy()
    if parent_id is None:
        if not pol.has(p, "tasks:create"):
            raise Forbidden("Bạn không có quyền giao task (tasks:create)")
        if not pol.can_use_agent(p.roles, agent):
            raise Forbidden(f"Bạn không có quyền dùng agent '{agent}'")
        return p.sub, {"created_by_name": p.name, "created_by_roles": sorted(p.roles)}

    parent = await db.get(Task, parent_id)
    if parent is None:
        raise HTTPException(404, f"Task cha '{parent_id}' không tồn tại")
    pmeta = parent.meta or {}
    if pol.has(p, "tasks:delegate"):
        ok, reason = pol.check_delegation(p, parent_agent=parent.agent, parent_status=parent.status,
                                          root_roles=pmeta.get("created_by_roles") or [], target_agent=agent)
        if not ok:
            raise Forbidden(reason)
        return parent.created_by or "", {"created_by_name": pmeta.get("created_by_name"),
                                         "created_by_roles": pmeta.get("created_by_roles") or [],
                                         "delegated_by": p.sub}
    # người dùng tự tạo task con: phải là chủ task cha (hoặc admin)
    if not pol.has(p, "tasks:create") or not (parent.created_by == p.sub or pol.is_super(p.roles)):
        raise Forbidden("Chỉ người tạo task cha (hoặc admin) mới được thêm task con")
    if not pol.can_use_agent(p.roles, agent):
        raise Forbidden(f"Bạn không có quyền dùng agent '{agent}'")
    return p.sub, {"created_by_name": p.name, "created_by_roles": sorted(p.roles)}


def pending_tools(task: Task) -> list[str]:
    calls = ((task.meta or {}).get("interrupt") or {}).get("calls") or []
    return [str(c.get("name")) for c in calls if c.get("name")]


def approval_info(task: Task, p: Principal) -> dict[str, Any] | None:
    """Thông tin phê duyệt cho UI: người đang xem có duyệt được task này không, vì sao."""
    if task.status != WAITING:
        return None
    pol = _policy()
    tools = pending_tools(task)
    ok, reason = pol.check_approval(p, agent=task.agent, tools=tools, creator=task.created_by)
    return {"pending": True, "tools": tools, "can_approve": ok, "reason": reason,
            "approver_roles": pol.approver_roles(task.agent, tools),
            "waiting_since": (task.meta or {}).get("waiting_since")}


def _notify_approval(task: Task, event: str, extra: dict[str, Any] | None = None) -> None:
    tools = pending_tools(task)
    notify(build_payload(event, task_id=task.id, agent=task.agent, tools=tools,
                         approver_roles=_policy().approver_roles(task.agent, tools),
                         created_by_name=(task.meta or {}).get("created_by_name"), extra=extra))


def new_id(prefix: str = "t") -> str:
    return f"{prefix}_{uuid.uuid4().hex[:20]}"


def agent_status(a: Agent) -> str:
    if not a.enabled:
        return "disabled"
    if a.last_heartbeat is None:
        return "offline"
    hb = a.last_heartbeat if a.last_heartbeat.tzinfo else a.last_heartbeat.replace(tzinfo=utcnow().tzinfo)
    return "online" if utcnow() - hb <= timedelta(seconds=settings.heartbeat_ttl_s) else "offline"


async def add_event(db: AsyncSession, task_id: str, type_: str, data: dict[str, Any]) -> dict[str, Any]:
    ev = TaskEvent(task_id=task_id, type=type_, data=data)
    db.add(ev)
    await db.flush()
    payload = ev.to_dict()
    await db.commit()
    await bus().publish(task_id, payload)
    return payload


async def create_task(db: AsyncSession, *, agent: str, input_: str, parent_id: str | None,
                      source: str, created_by: str, metadata: dict[str, Any] | None = None) -> Task:
    ag = await db.get(Agent, agent)
    if ag is None:
        raise HTTPException(404, f"Agent '{agent}' chưa đăng ký")
    if not ag.enabled:
        raise HTTPException(409, f"Agent '{agent}' đang bị vô hiệu hoá")

    depth, root_id = 0, None
    if parent_id:
        parent = await db.get(Task, parent_id)
        if parent is None:
            raise HTTPException(404, f"Task cha '{parent_id}' không tồn tại")
        depth = parent.depth + 1
        root_id = parent.root_id or parent.id
        if depth > settings.max_task_depth:
            raise HTTPException(400, f"Vượt độ sâu ủy quyền tối đa ({settings.max_task_depth})")
        # Chống vòng lặp/deadlock: không giao cho agent đã có mặt trong chuỗi tổ tiên
        ancestors: set[str] = set()
        cur: Task | None = parent
        while cur is not None:
            ancestors.add(cur.agent)
            cur = await db.get(Task, cur.parent_id) if cur.parent_id else None
        if agent in ancestors:
            raise HTTPException(400, f"Không thể giao task cho '{agent}': agent này đã nằm trong chuỗi task cha (vòng lặp)")

    task = Task(id=new_id(), agent=agent, input=input_, status="queued", parent_id=parent_id, root_id=root_id,
                depth=depth, source=source, created_by=created_by, meta=metadata or {})
    db.add(task)
    await db.commit()
    await add_event(db, task.id, "task_status", {"status": "queued", "agent": agent, "source": source})
    await bus().enqueue(agent, task.id)
    return task


async def finish_task(db: AsyncSession, task: Task, status: str, *, result: str | None = None,
                      error: str | None = None, usage: dict[str, Any] | None = None,
                      steps: int = 0, duration_ms: int = 0) -> Task:
    if task.status == "cancelled" and status != "cancelled":
        status = "cancelled"  # người dùng đã huỷ: giữ nguyên trạng thái huỷ
    task.status = status
    task.result = result
    task.error = error
    task.usage = usage or task.usage or {}
    task.steps = steps or task.steps
    task.duration_ms = duration_ms or task.duration_ms
    task.finished_at = utcnow()
    await db.commit()
    await add_event(db, task.id, "task_status", {"status": status, "result": (result or "")[:4000], "error": error})
    return task


async def reap_stale_tasks(db: AsyncSession) -> int:
    """Đánh dấu failed các task 'running' quá lâu (worker chết, mất kết nối...)."""
    rows = (await db.execute(select(Task).where(Task.status == "running"))).scalars().all()
    count = 0
    for t in rows:
        ag = await db.get(Agent, t.agent)
        limit_s = float((ag.limits or {}).get("task_timeout_s", 600)) if ag else 600.0
        started = t.started_at
        if started is None:
            continue
        if started.tzinfo is None:
            started = started.replace(tzinfo=utcnow().tzinfo)
        if utcnow() - started > timedelta(seconds=limit_s * settings.stale_task_factor):
            await finish_task(db, t, "failed", error="Hết thời gian: không nhận được kết quả từ worker")
            count += 1
    return count


async def cancel_queued(db: AsyncSession, task_id: str) -> None:
    """Huỷ ngay task chưa chạy (queued) hoặc đang chờ duyệt (waiting_input)."""
    await db.execute(update(Task).where(Task.id == task_id, Task.status.in_(["queued", WAITING]))
                     .values(status="cancelled", finished_at=utcnow()))
    await db.commit()


async def mark_waiting(db: AsyncSession, task: Task, interrupt: dict[str, Any], *, usage: dict[str, Any] | None,
                       steps: int, duration_ms: int) -> Task:
    """Engine dừng chờ con người: lưu nội dung cần duyệt, KHÔNG đặt finished_at."""
    meta = dict(task.meta or {})
    meta["interrupt"] = interrupt
    meta["waiting_since"] = utcnow().isoformat()
    meta.pop("resume", None)
    meta.pop("reminded_at", None)
    task.meta = meta                      # gán dict mới để SQLAlchemy ghi nhận thay đổi JSON
    task.status = WAITING
    task.usage = usage or task.usage or {}
    task.steps = steps or task.steps
    task.duration_ms = (task.duration_ms or 0) + (duration_ms or 0)
    await db.commit()
    await add_event(db, task.id, "task_status", {"status": WAITING, "interrupt": interrupt})
    _notify_approval(task, "approval.required")
    return task


async def resume_task(db: AsyncSession, task: Task, decision: dict[str, Any], actor: dict[str, Any]) -> Task:
    """Người dùng duyệt / từ chối => giao lại task cho agent kèm quyết định (engine chạy tiếp từ checkpoint)."""
    if task.status != WAITING:
        raise HTTPException(409, f"Task đang ở trạng thái {task.status}, không chờ phê duyệt")
    meta = dict(task.meta or {})
    interrupt = meta.pop("interrupt", None)
    history = list(meta.get("approvals") or [])
    history.append({"by": actor.get("sub"), "by_name": actor.get("name"), "at": utcnow().isoformat(),
                    "decision": decision, "tools": [c.get("name") for c in (interrupt or {}).get("calls") or []]})
    meta["approvals"] = history
    meta["resume"] = decision
    meta.pop("waiting_since", None)
    meta.pop("reminded_at", None)
    task.meta = meta
    task.status = "queued"
    await db.commit()
    await add_event(db, task.id, "approval_submitted", {"by": actor.get("name") or actor.get("sub"), **decision})
    await bus().enqueue(task.agent, task.id)
    return task


def is_terminal(status: str) -> bool:
    return status in TERMINAL


async def maintain_approvals(db: AsyncSession) -> dict[str, int]:
    """Chạy định kỳ: nhắc người duyệt và xử lý task chờ duyệt quá hạn (APPROVAL_TIMEOUT_ACTION)."""
    from datetime import datetime

    from .audit import record
    stats = {"reminded": 0, "expired": 0}
    rows = (await db.execute(select(Task).where(Task.status == WAITING))).scalars().all()
    for t in rows:
        meta = t.meta or {}
        try:
            since = datetime.fromisoformat(meta.get("waiting_since") or "")
        except ValueError:
            continue
        age_min = (utcnow() - since).total_seconds() / 60
        if settings.approval_timeout_min > 0 and age_min >= settings.approval_timeout_min:
            reason = f"Hết hạn phê duyệt sau {settings.approval_timeout_min} phút"
            system = {"sub": "system", "name": "AgentHub (tự động)"}
            # gửi thông báo TRƯỚC khi xử lý (resume_task xoá thông tin tool đang chờ)
            _notify_approval(t, "approval.expired", {"action": settings.approval_timeout_action})
            if settings.approval_timeout_action == "cancel":
                await bus().request_cancel(t.id)
                await cancel_queued(db, t.id)
                await add_event(db, t.id, "task_status", {"status": "cancelled", "error": reason})
            else:   # reject: agent nhận "bị từ chối" và tiếp tục bằng cách khác
                await resume_task(db, t, {"approved": False, "comment": reason, "calls": {}}, system)
            await record("task.approval.expired", actor=system, resource_type="task", resource_id=t.id,
                         details={"action": settings.approval_timeout_action, "age_min": round(age_min)})
            stats["expired"] += 1
        elif (settings.approval_remind_after_min > 0 and age_min >= settings.approval_remind_after_min
              and not meta.get("reminded_at")):
            t.meta = {**meta, "reminded_at": utcnow().isoformat()}
            await db.commit()
            _notify_approval(t, "approval.reminder", {"waiting_minutes": round(age_min)})
            stats["reminded"] += 1
    return stats
