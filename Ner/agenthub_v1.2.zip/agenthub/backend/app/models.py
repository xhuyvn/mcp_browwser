"""Mô hình dữ liệu: Agent registry, Task (cây task cha/con), TaskEvent (timeline), Conversation/Message (chat)."""
from __future__ import annotations

from datetime import datetime, timezone
from typing import Any

from sqlalchemy import JSON, BigInteger, Boolean, DateTime, ForeignKey, Integer, String, Text
from sqlalchemy.orm import Mapped, mapped_column

from .db import Base

PK_INT = BigInteger().with_variant(Integer, "sqlite")
TERMINAL = {"succeeded", "failed", "cancelled"}
WAITING = "waiting_input"   # task tạm dừng chờ con người duyệt (LangGraph interrupt)


def utcnow() -> datetime:
    return datetime.now(timezone.utc)


def iso(dt: datetime | None) -> str | None:
    if dt is None:
        return None
    if dt.tzinfo is None:
        dt = dt.replace(tzinfo=timezone.utc)
    return dt.isoformat()


class Agent(Base):
    __tablename__ = "agents"
    name: Mapped[str] = mapped_column(String(64), primary_key=True)
    version: Mapped[str] = mapped_column(String(32), default="0.0.0")
    description: Mapped[str] = mapped_column(Text, default="")
    endpoint: Mapped[str] = mapped_column(String(255), default="")
    tags: Mapped[list[Any]] = mapped_column(JSON, default=list)
    card: Mapped[dict[str, Any]] = mapped_column(JSON, default=dict)
    model: Mapped[dict[str, Any]] = mapped_column(JSON, default=dict)
    skills: Mapped[list[Any]] = mapped_column(JSON, default=list)
    tools: Mapped[list[Any]] = mapped_column(JSON, default=list)
    mcp_servers: Mapped[list[Any]] = mapped_column(JSON, default=list)
    limits: Mapped[dict[str, Any]] = mapped_column(JSON, default=dict)
    enabled: Mapped[bool] = mapped_column(Boolean, default=True)
    registered_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=utcnow)
    last_heartbeat: Mapped[datetime | None] = mapped_column(DateTime(timezone=True), nullable=True)


class Task(Base):
    __tablename__ = "tasks"
    id: Mapped[str] = mapped_column(String(32), primary_key=True)
    agent: Mapped[str] = mapped_column(String(64), index=True)
    input: Mapped[str] = mapped_column(Text)
    status: Mapped[str] = mapped_column(String(16), index=True, default="queued")  # queued|running|waiting_input|succeeded|failed|cancelled
    result: Mapped[str | None] = mapped_column(Text, nullable=True)
    error: Mapped[str | None] = mapped_column(Text, nullable=True)
    parent_id: Mapped[str | None] = mapped_column(String(32), ForeignKey("tasks.id"), nullable=True, index=True)
    root_id: Mapped[str | None] = mapped_column(String(32), nullable=True, index=True)
    depth: Mapped[int] = mapped_column(Integer, default=0)
    source: Mapped[str] = mapped_column(String(16), default="api")   # ui | api | mcp
    created_by: Mapped[str | None] = mapped_column(String(64), nullable=True)
    steps: Mapped[int] = mapped_column(Integer, default=0)
    duration_ms: Mapped[int] = mapped_column(Integer, default=0)
    usage: Mapped[dict[str, Any]] = mapped_column(JSON, default=dict)
    meta: Mapped[dict[str, Any]] = mapped_column("metadata", JSON, default=dict)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=utcnow, index=True)
    started_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True), nullable=True)
    finished_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True), nullable=True)

    def to_dict(self) -> dict[str, Any]:
        return {
            "id": self.id, "agent": self.agent, "input": self.input, "status": self.status,
            "result": self.result, "error": self.error, "parent_id": self.parent_id, "root_id": self.root_id,
            "depth": self.depth, "source": self.source, "created_by": self.created_by,
            "created_by_name": (self.meta or {}).get("created_by_name") or self.created_by,
            "delegated_by": (self.meta or {}).get("delegated_by"), "steps": self.steps,
            "duration_ms": self.duration_ms, "usage": self.usage or {}, "metadata": self.meta or {},
            "created_at": iso(self.created_at), "started_at": iso(self.started_at), "finished_at": iso(self.finished_at),
        }


class TaskEvent(Base):
    __tablename__ = "task_events"
    id: Mapped[int] = mapped_column(PK_INT, primary_key=True, autoincrement=True)
    task_id: Mapped[str] = mapped_column(String(32), ForeignKey("tasks.id", ondelete="CASCADE"), index=True)
    type: Mapped[str] = mapped_column(String(32))
    data: Mapped[dict[str, Any]] = mapped_column(JSON, default=dict)
    ts: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=utcnow)

    def to_dict(self) -> dict[str, Any]:
        return {"id": self.id, "task_id": self.task_id, "type": self.type, "data": self.data or {}, "ts": iso(self.ts)}


class Conversation(Base):
    __tablename__ = "conversations"
    id: Mapped[str] = mapped_column(String(32), primary_key=True)
    agent: Mapped[str] = mapped_column(String(64), index=True)
    title: Mapped[str] = mapped_column(String(200), default="")
    created_by: Mapped[str | None] = mapped_column(String(64), nullable=True)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=utcnow)
    updated_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=utcnow, index=True)

    def to_dict(self) -> dict[str, Any]:
        return {"id": self.id, "agent": self.agent, "title": self.title, "created_by": self.created_by,
                "created_at": iso(self.created_at), "updated_at": iso(self.updated_at)}


class Message(Base):
    __tablename__ = "messages"
    id: Mapped[int] = mapped_column(PK_INT, primary_key=True, autoincrement=True)
    conversation_id: Mapped[str] = mapped_column(String(32), ForeignKey("conversations.id", ondelete="CASCADE"), index=True)
    role: Mapped[str] = mapped_column(String(16))
    content: Mapped[str] = mapped_column(Text, default="")
    meta: Mapped[dict[str, Any]] = mapped_column("metadata", JSON, default=dict)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=utcnow)

    def to_dict(self) -> dict[str, Any]:
        return {"id": self.id, "conversation_id": self.conversation_id, "role": self.role,
                "content": self.content, "metadata": self.meta or {}, "created_at": iso(self.created_at)}


class AuditLog(Base):
    """Nhật ký audit chỉ-ghi-thêm (append-only). Không sửa / xoá qua API."""
    __tablename__ = "audit_log"
    id: Mapped[int] = mapped_column(PK_INT, primary_key=True, autoincrement=True)
    ts: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=utcnow, index=True)
    actor_sub: Mapped[str] = mapped_column(String(128), index=True, default="")
    actor_name: Mapped[str] = mapped_column(String(200), default="")
    actor_kind: Mapped[str] = mapped_column(String(16), default="")
    action: Mapped[str] = mapped_column(String(64), index=True)
    outcome: Mapped[str] = mapped_column(String(16), default="allow")      # allow | deny | error
    resource_type: Mapped[str] = mapped_column(String(32), default="")
    resource_id: Mapped[str] = mapped_column(String(64), index=True, default="")
    ip: Mapped[str | None] = mapped_column(String(64), nullable=True)
    user_agent: Mapped[str | None] = mapped_column(String(200), nullable=True)
    details: Mapped[dict[str, Any]] = mapped_column(JSON, default=dict)

    def to_dict(self) -> dict[str, Any]:
        return {"id": self.id, "ts": iso(self.ts), "actor": {"sub": self.actor_sub, "name": self.actor_name,
                                                               "kind": self.actor_kind},
                "action": self.action, "outcome": self.outcome,
                "resource": {"type": self.resource_type, "id": self.resource_id},
                "ip": self.ip, "details": self.details or {}}
