"""Phân quyền (RBAC) — module thuần, không phụ thuộc FastAPI / DB (dễ test, dễ review).

Ba lớp kiểm tra:
  1. Permission theo vai trò        : agents:read, tasks:create, tasks:approve, ...
  2. Quyền dùng agent (agent_access): vai trò nào được chat / giao task cho agent nào
  3. Quy tắc phê duyệt tool         : vai trò nào được duyệt tool nào của agent nào + maker-checker

Chính sách đọc từ config/policy.yaml (không có file => DEFAULT_POLICY bên dưới).
"""
from __future__ import annotations

import fnmatch
import logging
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Iterable

import yaml

log = logging.getLogger("backend.authz")

PERMISSIONS: dict[str, str] = {
    "agents:read": "Xem danh sách và thông tin agent",
    "agents:manage": "Bật / tắt agent",
    "tasks:read": "Xem task do chính mình tạo (kể cả task con được giao thay mặt mình)",
    "tasks:read:all": "Xem mọi task",
    "tasks:create": "Giao task cho agent",
    "tasks:delegate": "Service account của agent giao task con thay mặt người tạo task gốc",
    "tasks:cancel": "Huỷ task của chính mình",
    "tasks:cancel:any": "Huỷ mọi task",
    "tasks:approve": "Phê duyệt tool (còn phải thoả quy tắc approvals)",
    "chat": "Chat với agent",
    "chat:read:all": "Xem hội thoại của mọi người",
    "audit:read": "Xem nhật ký audit",
}
SUPER = "*"

DEFAULT_POLICY: dict[str, Any] = {
    "roles": {
        "viewer": {"permissions": ["agents:read", "tasks:read:all"]},
        "operator": {"permissions": ["agents:read", "tasks:read", "tasks:create", "tasks:cancel", "chat"]},
        "approver": {"inherits": ["viewer"], "permissions": ["tasks:approve"]},
        "admin": {"permissions": ["*"]},
        "delegator": {"permissions": ["agents:read", "tasks:delegate", "tasks:read:all"]},
    },
    "agent_access": {"*": ["operator", "admin"]},
    "approvals": {
        "maker_checker": True,
        "rules": [
            {"agents": ["*"], "tools": ["fs__write_file", "fs__edit_file", "fs__move_file"],
             "roles": ["approver", "admin"]},
            {"agents": ["*"], "tools": ["*"], "roles": ["admin"]},
        ],
    },
}


@dataclass(frozen=True)
class Principal:
    sub: str                                  # định danh ổn định (OIDC `sub` / tên API key)
    name: str
    roles: frozenset[str] = frozenset()
    kind: str = "user"                        # user | service
    auth: str = "static"                      # static | api_key | oidc | jwt
    email: str | None = None
    agent: str | None = None                  # service account gắn với 1 agent (vd. orchestrator)

    def audit_actor(self) -> dict[str, Any]:
        return {"sub": self.sub, "name": self.name, "kind": self.kind, "auth": self.auth,
                "roles": sorted(self.roles), **({"agent": self.agent} if self.agent else {})}


class PolicyError(ValueError):
    pass


def _match(value: str, patterns: Iterable[str]) -> bool:
    return any(fnmatch.fnmatchcase(value, p) for p in patterns)


class Policy:
    def __init__(self, data: dict[str, Any]):
        self.data = data
        self.roles: dict[str, dict[str, Any]] = data.get("roles") or {}
        self.agent_access: dict[str, list[str]] = data.get("agent_access") or {}
        appr = data.get("approvals") or {}
        self.maker_checker: bool = bool(appr.get("maker_checker", True))
        self.rules: list[dict[str, Any]] = list(appr.get("rules") or [])
        self._perms: dict[str, frozenset[str]] = {}
        self._validate()

    # ------------------------------------------------------------------ load / validate
    @classmethod
    def load(cls, path: str | None) -> "Policy":
        if path and Path(path).is_file():
            data = yaml.safe_load(Path(path).read_text(encoding="utf-8")) or {}
            log.info("Nạp chính sách phân quyền từ %s", path)
            return cls(data)
        log.warning("Không thấy file chính sách (%s) — dùng chính sách mặc định", path)
        return cls(DEFAULT_POLICY)

    def _validate(self) -> None:
        if not self.roles:
            raise PolicyError("policy: phải khai báo ít nhất 1 vai trò")
        for role, spec in self.roles.items():
            for p in spec.get("permissions") or []:
                if p != SUPER and p not in PERMISSIONS:
                    raise PolicyError(f"policy: vai trò '{role}' có permission không hợp lệ '{p}'")
            for parent in spec.get("inherits") or []:
                if parent not in self.roles:
                    raise PolicyError(f"policy: vai trò '{role}' kế thừa vai trò không tồn tại '{parent}'")
        for role in self.roles:
            self.role_permissions(role)          # phát hiện vòng kế thừa
        referenced = [r for rs in self.agent_access.values() for r in rs] + \
                     [r for rule in self.rules for r in rule.get("roles") or []]
        unknown = sorted({r for r in referenced if r not in self.roles})
        if unknown:
            raise PolicyError(f"policy: tham chiếu vai trò không tồn tại: {unknown}")
        for i, rule in enumerate(self.rules):
            if not rule.get("tools") or not rule.get("roles"):
                raise PolicyError(f"policy: approvals.rules[{i}] cần 'tools' và 'roles'")

    # ------------------------------------------------------------------ permissions
    def role_permissions(self, role: str, _stack: tuple[str, ...] = ()) -> frozenset[str]:
        if role in self._perms:
            return self._perms[role]
        if role in _stack:
            raise PolicyError(f"policy: vòng kế thừa vai trò {' -> '.join(_stack + (role,))}")
        spec = self.roles.get(role)
        if spec is None:
            return frozenset()
        perms = set(spec.get("permissions") or [])
        for parent in spec.get("inherits") or []:
            perms |= self.role_permissions(parent, _stack + (role,))
        self._perms[role] = frozenset(perms)
        return self._perms[role]

    def known_roles(self) -> set[str]:
        return set(self.roles)

    def permissions(self, roles: Iterable[str]) -> frozenset[str]:
        out: set[str] = set()
        for r in roles:
            out |= self.role_permissions(r)
        return frozenset(out)

    def is_super(self, roles: Iterable[str]) -> bool:
        return SUPER in self.permissions(roles)

    def has(self, p: Principal, perm: str) -> bool:
        perms = self.permissions(p.roles)
        return SUPER in perms or perm in perms

    def effective_permissions(self, p: Principal) -> list[str]:
        perms = self.permissions(p.roles)
        return sorted(PERMISSIONS) if SUPER in perms else sorted(perms)

    # ------------------------------------------------------------------ agent access
    def can_use_agent(self, roles: Iterable[str], agent: str) -> bool:
        roles = set(roles)
        if self.is_super(roles):
            return True
        # luật cụ thể (tên chính xác) ưu tiên hơn wildcard; wildcard dài hơn ưu tiên hơn
        if agent in self.agent_access:
            allowed = self.agent_access[agent]
        else:
            patterns = sorted((k for k in self.agent_access if fnmatch.fnmatchcase(agent, k)), key=len, reverse=True)
            allowed = self.agent_access[patterns[0]] if patterns else []
        return bool(roles & set(allowed))

    # ------------------------------------------------------------------ tasks
    def can_view_task(self, p: Principal, created_by: str | None) -> bool:
        return self.has(p, "tasks:read:all") or (self.has(p, "tasks:read") and created_by == p.sub)

    def can_cancel_task(self, p: Principal, created_by: str | None) -> bool:
        return self.has(p, "tasks:cancel:any") or (self.has(p, "tasks:cancel") and created_by == p.sub)

    def check_delegation(self, p: Principal, *, parent_agent: str, parent_status: str,
                         root_roles: Iterable[str], target_agent: str) -> tuple[bool, str]:
        """Service account (vd. orchestrator) giao task con thay mặt người tạo task gốc."""
        if not self.has(p, "tasks:delegate"):
            return False, "Không có quyền giao task con (tasks:delegate)"
        if p.agent and p.agent != parent_agent:
            return False, f"Service account của '{p.agent}' chỉ được giao việc từ task của chính agent đó"
        if parent_status != "running":
            return False, f"Task cha đang ở trạng thái '{parent_status}', không thể giao thêm việc"
        if not self.can_use_agent(root_roles, target_agent):
            return False, (f"Người tạo task gốc không có quyền dùng agent '{target_agent}' — "
                           "orchestrator không được vượt quyền người dùng")
        return True, ""

    # ------------------------------------------------------------------ approvals
    def approval_rule(self, agent: str, tool: str) -> dict[str, Any] | None:
        for rule in self.rules:
            if _match(agent, rule.get("agents") or ["*"]) and _match(tool, rule.get("tools") or []):
                return rule
        return None

    def approver_roles(self, agent: str, tools: Iterable[str]) -> list[str]:
        """Vai trò duyệt được TẤT CẢ các tool đang chờ (dùng để gửi thông báo đúng người)."""
        eligible: set[str] | None = None
        for tool in tools:
            rule = self.approval_rule(agent, tool)
            roles = set(rule.get("roles") or []) if rule else set()
            eligible = roles if eligible is None else eligible & roles
        supers = {r for r in self.roles if SUPER in self.role_permissions(r)}
        return sorted((eligible or set()) | supers)

    def check_approval(self, p: Principal, *, agent: str, tools: Iterable[str],
                       creator: str | None) -> tuple[bool, str]:
        if p.kind != "user":
            return False, "Chỉ con người mới được phê duyệt tool (service account / agent bị chặn)"
        if not self.has(p, "tasks:approve"):
            return False, "Bạn không có quyền phê duyệt (cần quyền tasks:approve)"
        if self.maker_checker and creator and p.sub == creator:
            return False, "Maker-checker: người tạo task không được tự duyệt — cần một người duyệt khác"
        superuser = self.is_super(p.roles)
        for tool in tools:
            rule = self.approval_rule(agent, tool)
            allowed = set(rule.get("roles") or []) if rule else set()
            if not superuser and not (set(p.roles) & allowed):
                need = ", ".join(sorted(allowed)) or "admin"
                return False, f"Không có quyền duyệt tool '{tool}' của agent '{agent}' (cần vai trò: {need})"
        return True, ""


def sanitize_task_metadata(meta: dict[str, Any] | None) -> dict[str, Any]:
    """Bỏ các khoá hệ thống khỏi metadata do client gửi (chống giả mạo người tạo / quyết định duyệt)."""
    reserved = {"created_by_name", "created_by_roles", "delegated_by", "interrupt", "resume", "approvals",
                "waiting_since", "reminded_at"}
    return {k: v for k, v in (meta or {}).items() if k not in reserved}
