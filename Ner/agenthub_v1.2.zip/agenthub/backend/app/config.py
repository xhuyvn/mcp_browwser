"""Cấu hình backend từ biến môi trường (xem .env.example và docs/SECURITY.md)."""
from __future__ import annotations

import os
from dataclasses import dataclass, field


def _env(name: str, default: str = "") -> str:
    return os.environ.get(name, default).strip()


def _bool(name: str, default: bool) -> bool:
    v = os.environ.get(name)
    return default if v is None else v.strip().lower() in ("1", "true", "yes", "on")


def _list(name: str, default: str = "") -> list[str]:
    return [x.strip() for x in _env(name, default).split(",") if x.strip()]


def _map(name: str, default: str = "") -> dict[str, str]:
    """"a:1,b:2" -> {"a": "1", "b": "2"}"""
    out: dict[str, str] = {}
    for item in _list(name, default):
        if ":" in item:
            k, v = item.split(":", 1)
            if k.strip() and v.strip():
                out[k.strip()] = v.strip()
    return out


@dataclass
class AuthConfig:
    """Cấu hình xác thực — tách riêng để module auth không phụ thuộc biến toàn cục (dễ test)."""
    mode: str = "static"                     # static | oidc | both
    static_tokens: str = ""                   # "name:token:role1|role2[:agent],..."  (dev / service)
    api_keys_file: str = ""                   # YAML chứa sha256 của API key (production)
    oidc_issuer: str = ""                     # giá trị `iss` mong đợi
    oidc_audience: str = ""                   # giá trị `aud` mong đợi (bỏ trống = không kiểm tra)
    oidc_jwks_url: str = ""                   # bỏ trống = lấy từ <issuer>/.well-known/openid-configuration
    oidc_algorithms: list[str] = field(default_factory=lambda: ["RS256", "ES256", "PS256"])
    oidc_role_claims: list[str] = field(default_factory=lambda: ["realm_access.roles", "roles", "groups"])
    oidc_role_map: dict[str, str] = field(default_factory=dict)   # claim value -> role AgentHub
    oidc_name_claims: list[str] = field(default_factory=lambda: ["name", "preferred_username", "email"])
    oidc_leeway_s: int = 30
    jwt_hs256_secret: str = ""                # JWT ký HS256 (vd. token broker của MCP Tool Platform)


DEFAULT_ROLE_MAP = ("agenthub-viewer:viewer,agenthub-operator:operator,"
                    "agenthub-approver:approver,agenthub-admin:admin")


@dataclass
class Settings:
    database_url: str = _env("DATABASE_URL", "sqlite+aiosqlite:///./data/agenthub.db")
    redis_url: str = _env("REDIS_URL", "redis://localhost:6379/0")

    # ---- xác thực người dùng / service
    auth: AuthConfig = field(default_factory=lambda: AuthConfig(
        mode=_env("AUTH_MODE", "static").lower(),
        static_tokens=",".join(x for x in [_env("API_TOKENS"),
                                           f"admin:{_env('API_TOKEN')}:admin" if _env("API_TOKEN") else ""] if x),
        api_keys_file=_env("API_KEYS_FILE"),
        oidc_issuer=_env("OIDC_ISSUER"),
        oidc_audience=_env("OIDC_AUDIENCE"),
        oidc_jwks_url=_env("OIDC_JWKS_URL"),
        oidc_algorithms=_list("OIDC_ALGORITHMS", "RS256,ES256,PS256"),
        oidc_role_claims=_list("OIDC_ROLE_CLAIMS", "realm_access.roles,roles,groups"),
        oidc_role_map=_map("OIDC_ROLE_MAP", DEFAULT_ROLE_MAP),
        oidc_name_claims=_list("OIDC_NAME_CLAIMS", "name,preferred_username,email"),
        oidc_leeway_s=int(_env("OIDC_LEEWAY_S", "30")),
        jwt_hs256_secret=_env("JWT_HS256_SECRET"),
    ))
    allow_query_token: bool = _bool("ALLOW_QUERY_TOKEN", False)   # ?token= trên URL (lộ token vào log) — mặc định tắt
    policy_file: str = _env("POLICY_FILE", "/srv/config/policy.yaml")

    # ---- xác thực agent <-> backend
    agent_tokens: dict[str, str] = field(default_factory=lambda: _map("AGENT_TOKENS"))  # agent -> token riêng
    internal_token: str = _env("INTERNAL_TOKEN")            # token chung (chỉ dùng khi chưa khai báo AGENT_TOKENS)
    agent_api_token: str = _env("AGENT_API_TOKEN")          # backend -> agent (/v1/chat, /v1/tools)

    # ---- rate limit (số request / phút / người dùng; 0 = tắt)
    rl_tasks_per_min: int = int(_env("RATE_LIMIT_TASKS_PER_MIN", "30"))
    rl_chat_per_min: int = int(_env("RATE_LIMIT_CHAT_PER_MIN", "20"))
    rl_approvals_per_min: int = int(_env("RATE_LIMIT_APPROVALS_PER_MIN", "30"))

    # ---- thông báo & thời hạn phê duyệt
    public_ui_url: str = _env("PUBLIC_UI_URL", "http://localhost:3000").rstrip("/")
    notify_webhook_url: str = _env("NOTIFY_WEBHOOK_URL")
    notify_webhook_format: str = _env("NOTIFY_WEBHOOK_FORMAT", "generic").lower()   # generic | slack
    notify_webhook_secret: str = _env("NOTIFY_WEBHOOK_SECRET")
    approval_remind_after_min: int = int(_env("APPROVAL_REMIND_AFTER_MIN", "30"))
    approval_timeout_min: int = int(_env("APPROVAL_TIMEOUT_MIN", "1440"))
    approval_timeout_action: str = _env("APPROVAL_TIMEOUT_ACTION", "reject").lower()  # reject | cancel

    # ---- khác
    cors_origins: list[str] = field(default_factory=lambda: _list("CORS_ORIGINS", "http://localhost:3000,http://localhost:5173"))
    enable_docs: bool = _bool("ENABLE_API_DOCS", True)
    heartbeat_ttl_s: int = int(_env("HEARTBEAT_TTL_S", "45"))
    max_task_depth: int = int(_env("MAX_TASK_DEPTH", "3"))
    stale_task_factor: float = float(_env("STALE_TASK_FACTOR", "2.0"))
    chat_history_limit: int = int(_env("CHAT_HISTORY_LIMIT", "20"))


settings = Settings()
