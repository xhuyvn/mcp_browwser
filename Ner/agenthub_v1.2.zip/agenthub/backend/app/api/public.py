"""API công khai: agents, tasks, phê duyệt, chat, audit — mọi endpoint đều xác thực + phân quyền.

Quy ước:
  * Permission kiểm tra bằng require("...") ở chữ ký endpoint.
  * Quyền trên TỪNG tài nguyên (task của ai, agent nào, tool nào) kiểm tra trong thân hàm qua `policy`.
  * Mọi thao tác thay đổi trạng thái và mọi lần bị từ chối (403) đều ghi audit.
"""
from __future__ import annotations

import asyncio
import json
from typing import Any, AsyncIterator, Literal

import httpx
from fastapi import APIRouter, Depends, HTTPException, Query, Request
from fastapi.responses import StreamingResponse
from pydantic import BaseModel, Field
from sqlalchemy import func, select
from sqlalchemy.ext.asyncio import AsyncSession

from ..audit import record
from ..authz import PERMISSIONS, Principal, sanitize_task_metadata
from ..config import settings
from ..db import SessionLocal, get_session
from ..models import WAITING, Agent, AuditLog, Conversation, Message, Task, TaskEvent, iso, utcnow
from ..ratelimit import hit
from ..security import authenticator, current_principal, deny, policy, require
from ..services import (Forbidden, add_event, agent_status, approval_info, bus, cancel_queued, create_task,
                        is_terminal, new_id, pending_tools, resolve_owner, resume_task)

router = APIRouter(prefix="/api", dependencies=[Depends(current_principal)])


async def _task_or_404(db: AsyncSession, task_id: str) -> Task:
    t = await db.get(Task, task_id)
    if not t:
        raise HTTPException(404, "Task không tồn tại")
    return t


async def _visible_task(request: Request, db: AsyncSession, p: Principal, task_id: str) -> Task:
    t = await _task_or_404(db, task_id)
    if not policy.can_view_task(p, t.created_by):
        # trả 404 thay vì 403 để không lộ sự tồn tại của task người khác
        await record("task.read", principal=p, outcome="deny", resource_type="task", resource_id=task_id,
                     request=request, details={"reason": "không phải chủ task"})
        raise HTTPException(404, "Task không tồn tại")
    return t


# ------------------------------------------------------------------ me
@router.get("/me")
async def me(p: Principal = Depends(current_principal)) -> dict[str, Any]:
    return {"sub": p.sub, "name": p.name, "email": p.email, "roles": sorted(p.roles), "kind": p.kind,
            "auth": p.auth, "agent": p.agent, "permissions": policy.effective_permissions(p),
            "auth_mode": authenticator.mode, "maker_checker": policy.maker_checker}


@router.get("/permissions")
async def permissions_catalog(_: Principal = Depends(require("agents:read"))) -> dict[str, Any]:
    return {"permissions": PERMISSIONS, "roles": {r: sorted(policy.role_permissions(r)) for r in policy.roles}}


# ------------------------------------------------------------------ agents
async def agent_dict(a: Agent, p: Principal, with_queue: bool = True) -> dict[str, Any]:
    return {
        "name": a.name, "version": a.version, "description": a.description, "endpoint": a.endpoint,
        "tags": a.tags or [], "status": agent_status(a), "enabled": a.enabled,
        "model": a.model or {}, "skills": a.skills or [], "tools": a.tools or [],
        "mcp_servers": a.mcp_servers or [], "limits": a.limits or {}, "card": a.card or {},
        "registered_at": iso(a.registered_at), "last_heartbeat": iso(a.last_heartbeat),
        "queue_depth": await bus().queue_depth(a.name) if with_queue else None,
        "can_use": policy.can_use_agent(p.roles, a.name),
    }


@router.get("/agents")
async def list_agents(p: Principal = Depends(require("agents:read")),
                      db: AsyncSession = Depends(get_session)) -> list[dict[str, Any]]:
    agents = (await db.execute(select(Agent).order_by(Agent.name))).scalars().all()
    return list(await asyncio.gather(*(agent_dict(a, p) for a in agents)))


@router.get("/agents/{name}")
async def get_agent(name: str, p: Principal = Depends(require("agents:read")),
                    db: AsyncSession = Depends(get_session)) -> dict[str, Any]:
    a = await db.get(Agent, name)
    if not a:
        raise HTTPException(404, "Agent không tồn tại")
    return await agent_dict(a, p)


class AgentPatch(BaseModel):
    enabled: bool | None = None


@router.patch("/agents/{name}")
async def patch_agent(name: str, body: AgentPatch, request: Request,
                      p: Principal = Depends(require("agents:manage")),
                      db: AsyncSession = Depends(get_session)) -> dict[str, Any]:
    a = await db.get(Agent, name)
    if not a:
        raise HTTPException(404, "Agent không tồn tại")
    if body.enabled is not None:
        a.enabled = body.enabled
    await db.commit()
    await record("agent.update", principal=p, resource_type="agent", resource_id=name, request=request,
                 details=body.model_dump(exclude_none=True))
    return await agent_dict(a, p)


@router.get("/agents/{name}/tools")
async def agent_tools(name: str, _: Principal = Depends(require("agents:read")),
                      db: AsyncSession = Depends(get_session)) -> dict[str, Any]:
    a = await db.get(Agent, name)
    if not a:
        raise HTTPException(404, "Agent không tồn tại")
    headers = {"X-Agent-Token": settings.agent_api_token} if settings.agent_api_token else {}
    try:
        async with httpx.AsyncClient(timeout=10) as c:
            r = await c.get(f"{a.endpoint}/v1/tools", headers=headers)
            r.raise_for_status()
            return r.json()
    except httpx.HTTPError as exc:
        raise HTTPException(502, f"Không gọi được agent: {exc}") from exc


# ------------------------------------------------------------------ tasks
class TaskCreate(BaseModel):
    agent: str
    input: str = Field(min_length=1, max_length=50_000)
    parent_id: str | None = None
    source: Literal["ui", "api", "mcp"] = "api"
    metadata: dict[str, Any] = Field(default_factory=dict)


@router.post("/tasks", status_code=201)
async def post_task(body: TaskCreate, request: Request, p: Principal = Depends(current_principal),
                    db: AsyncSession = Depends(get_session)) -> dict[str, Any]:
    await hit("tasks", p, settings.rl_tasks_per_min)
    try:
        owner, owner_meta = await resolve_owner(db, p, body.agent, body.parent_id)
    except Forbidden as exc:
        await deny(request, p, "task.create", str(exc), "agent", body.agent)
    meta = {**sanitize_task_metadata(body.metadata), **owner_meta}
    task = await create_task(db, agent=body.agent, input_=body.input, parent_id=body.parent_id,
                             source=body.source, created_by=owner, metadata=meta)
    await record("task.create", principal=p, resource_type="task", resource_id=task.id, request=request,
                 details={"agent": body.agent, "parent_id": body.parent_id, "source": body.source,
                          "on_behalf_of": owner if owner != p.sub else None})
    return task.to_dict()


@router.get("/tasks")
async def list_tasks(status: str | None = None, agent: str | None = None, parent_id: str | None = None,
                     root_only: bool = False, mine: bool = False,
                     limit: int = Query(50, ge=1, le=200), offset: int = Query(0, ge=0),
                     p: Principal = Depends(current_principal),
                     db: AsyncSession = Depends(get_session)) -> list[dict[str, Any]]:
    if not (policy.has(p, "tasks:read") or policy.has(p, "tasks:read:all")):
        raise HTTPException(403, "Bạn không có quyền xem task")
    q = select(Task).order_by(Task.created_at.desc()).limit(limit).offset(offset)
    if mine or not policy.has(p, "tasks:read:all"):
        q = q.where(Task.created_by == p.sub)       # chỉ thấy task của mình (kể cả task con giao thay mặt mình)
    if status:
        q = q.where(Task.status == status)
    if agent:
        q = q.where(Task.agent == agent)
    if parent_id:
        q = q.where(Task.parent_id == parent_id)
    if root_only:
        q = q.where(Task.parent_id.is_(None))
    return [t.to_dict() for t in (await db.execute(q)).scalars().all()]


@router.get("/tasks/{task_id}")
async def get_task(task_id: str, request: Request, p: Principal = Depends(current_principal),
                   db: AsyncSession = Depends(get_session)) -> dict[str, Any]:
    t = await _visible_task(request, db, p, task_id)
    children = (await db.execute(select(Task).where(Task.parent_id == task_id)
                                 .order_by(Task.created_at))).scalars().all()
    return {**t.to_dict(), "children": [c.to_dict() for c in children if policy.can_view_task(p, c.created_by)],
            "approval": approval_info(t, p),
            "can_cancel": policy.can_cancel_task(p, t.created_by) and not is_terminal(t.status)}


@router.get("/tasks/{task_id}/events")
async def task_events(task_id: str, request: Request, after: int = 0, limit: int = Query(500, ge=1, le=2000),
                      p: Principal = Depends(current_principal),
                      db: AsyncSession = Depends(get_session)) -> list[dict[str, Any]]:
    await _visible_task(request, db, p, task_id)
    q = (select(TaskEvent).where(TaskEvent.task_id == task_id, TaskEvent.id > after)
         .order_by(TaskEvent.id).limit(limit))
    return [e.to_dict() for e in (await db.execute(q)).scalars().all()]


@router.post("/tasks/{task_id}/cancel")
async def cancel_task(task_id: str, request: Request, p: Principal = Depends(current_principal),
                      db: AsyncSession = Depends(get_session)) -> dict[str, Any]:
    t = await _visible_task(request, db, p, task_id)
    if not policy.can_cancel_task(p, t.created_by):
        await deny(request, p, "task.cancel", "Bạn chỉ được huỷ task của mình", "task", task_id)
    if is_terminal(t.status):
        return t.to_dict()
    await bus().request_cancel(task_id)
    if t.status in ("queued", WAITING):
        reason = "Huỷ khi đang chờ duyệt" if t.status == WAITING else "Huỷ trước khi chạy"
        await cancel_queued(db, task_id)
        await db.refresh(t)
        await add_event(db, task_id, "task_status", {"status": "cancelled", "error": reason, "by": p.name})
    else:
        await add_event(db, task_id, "cancel_requested", {"by": p.name})
    await record("task.cancel", principal=p, resource_type="task", resource_id=task_id, request=request)
    return t.to_dict()


class ApprovalIn(BaseModel):
    approved: bool
    comment: str = Field(default="", max_length=2000)
    calls: dict[str, bool] = Field(default_factory=dict, description="Duyệt riêng từng tool call: {call_id: true|false}")


@router.post("/tasks/{task_id}/approval")
async def approve_task(task_id: str, body: ApprovalIn, request: Request,
                       p: Principal = Depends(current_principal),
                       db: AsyncSession = Depends(get_session)) -> dict[str, Any]:
    """Duyệt / từ chối các tool đang chờ. Kiểm tra: quyền duyệt theo tool + maker-checker."""
    await hit("approvals", p, settings.rl_approvals_per_min)
    t = await _visible_task(request, db, p, task_id)
    if t.status != WAITING:
        raise HTTPException(409, f"Task đang ở trạng thái {t.status}, không chờ phê duyệt")
    tools = pending_tools(t)
    ok, reason = policy.check_approval(p, agent=t.agent, tools=tools, creator=t.created_by)
    if not ok:
        await deny(request, p, "task.approve", reason, "task", task_id)
    pending_ids = {c.get("id") for c in ((t.meta or {}).get("interrupt") or {}).get("calls") or []}
    unknown = set(body.calls) - pending_ids
    if unknown:
        raise HTTPException(400, f"call_id không thuộc task này: {sorted(unknown)}")
    await resume_task(db, t, body.model_dump(), {"sub": p.sub, "name": p.name})
    await record("task.approve" if body.approved else "task.reject", principal=p, resource_type="task",
                 resource_id=task_id, request=request,
                 details={"tools": tools, "calls": body.calls, "comment": body.comment[:200]})
    return t.to_dict()


@router.get("/approvals")
async def my_approvals(p: Principal = Depends(current_principal),
                       db: AsyncSession = Depends(get_session)) -> dict[str, Any]:
    """Hộp thư phê duyệt: task đang chờ duyệt mà người gọi nhìn thấy, kèm cờ có duyệt được không."""
    rows = (await db.execute(select(Task).where(Task.status == WAITING)
                             .order_by(Task.created_at).limit(200))).scalars().all()
    items = []
    for t in rows:
        if not policy.can_view_task(p, t.created_by):
            continue
        info = approval_info(t, p) or {}
        items.append({**t.to_dict(), "approval": info})
    return {"count_actionable": sum(1 for i in items if i["approval"].get("can_approve")), "items": items}


@router.get("/tasks/{task_id}/stream")
async def stream_task(task_id: str, request: Request, after: int = 0,
                      p: Principal = Depends(current_principal)) -> StreamingResponse:
    """SSE: phát lại event đã lưu (id > after) rồi đẩy event mới realtime đến khi task kết thúc."""
    async with SessionLocal() as db:
        await _visible_task(request, db, p, task_id)

    async def gen() -> AsyncIterator[str]:
        sub = await bus().subscribe(task_id)       # subscribe TRƯỚC khi replay để không mất event
        last_id = after
        try:
            async with SessionLocal() as db:
                rows = (await db.execute(select(TaskEvent).where(TaskEvent.task_id == task_id, TaskEvent.id > after)
                                         .order_by(TaskEvent.id))).scalars().all()
                task = await db.get(Task, task_id)
                for e in rows:
                    last_id = max(last_id, e.id)
                    yield f"id: {e.id}\nevent: {e.type}\ndata: {json.dumps(e.to_dict(), ensure_ascii=False)}\n\n"
                if task and is_terminal(task.status):
                    yield "event: end\ndata: {}\n\n"
                    return
            while True:
                if await request.is_disconnected():
                    return
                ev = await sub.get(timeout=15)
                if ev is None:
                    yield ": keep-alive\n\n"
                    continue
                if int(ev.get("id") or 0) <= last_id:
                    continue
                last_id = int(ev["id"])
                yield f"id: {last_id}\nevent: {ev['type']}\ndata: {json.dumps(ev, ensure_ascii=False)}\n\n"
                if ev["type"] == "task_status" and is_terminal(ev.get("data", {}).get("status", "")):
                    yield "event: end\ndata: {}\n\n"
                    return
        finally:
            await sub.close()

    return StreamingResponse(gen(), media_type="text/event-stream",
                             headers={"Cache-Control": "no-cache", "X-Accel-Buffering": "no"})


@router.get("/stats")
async def stats(p: Principal = Depends(require("agents:read")),
                db: AsyncSession = Depends(get_session)) -> dict[str, Any]:
    q = select(Task.status, func.count()).group_by(Task.status)
    if not policy.has(p, "tasks:read:all"):
        q = q.where(Task.created_by == p.sub)
    rows = (await db.execute(q)).all()
    agents = (await db.execute(select(Agent))).scalars().all()
    return {
        "tasks": {s: c for s, c in rows},
        "agents": {"total": len(agents), "online": sum(1 for a in agents if agent_status(a) == "online")},
        "redis": await bus().ping(),
        "time": iso(utcnow()),
    }


# ------------------------------------------------------------------ audit
@router.get("/audit")
async def audit(actor: str | None = None, action: str | None = None, resource_id: str | None = None,
                outcome: str | None = None, limit: int = Query(100, ge=1, le=500), before_id: int | None = None,
                _: Principal = Depends(require("audit:read")),
                db: AsyncSession = Depends(get_session)) -> list[dict[str, Any]]:
    q = select(AuditLog).order_by(AuditLog.id.desc()).limit(limit)
    if actor:
        q = q.where((AuditLog.actor_sub == actor) | (AuditLog.actor_name == actor))
    if action:
        q = q.where(AuditLog.action.like(f"{action}%"))
    if resource_id:
        q = q.where(AuditLog.resource_id == resource_id)
    if outcome:
        q = q.where(AuditLog.outcome == outcome)
    if before_id:
        q = q.where(AuditLog.id < before_id)
    return [a.to_dict() for a in (await db.execute(q)).scalars().all()]


# ------------------------------------------------------------------ chat
class ChatIn(BaseModel):
    message: str = Field(min_length=1, max_length=20_000)
    conversation_id: str | None = None


@router.get("/conversations")
async def list_conversations(agent: str | None = None, limit: int = 30,
                             p: Principal = Depends(require("chat")),
                             db: AsyncSession = Depends(get_session)) -> list[dict[str, Any]]:
    q = select(Conversation).order_by(Conversation.updated_at.desc()).limit(limit)
    if not policy.has(p, "chat:read:all"):
        q = q.where(Conversation.created_by == p.sub)
    if agent:
        q = q.where(Conversation.agent == agent)
    return [c.to_dict() for c in (await db.execute(q)).scalars().all()]


@router.get("/conversations/{cid}/messages")
async def conversation_messages(cid: str, p: Principal = Depends(require("chat")),
                                db: AsyncSession = Depends(get_session)) -> list[dict[str, Any]]:
    conv = await db.get(Conversation, cid)
    if conv is None or not (conv.created_by == p.sub or policy.has(p, "chat:read:all")):
        raise HTTPException(404, "Hội thoại không tồn tại")
    q = select(Message).where(Message.conversation_id == cid).order_by(Message.id)
    return [m.to_dict() for m in (await db.execute(q)).scalars().all()]


@router.post("/agents/{name}/chat")
async def chat(name: str, body: ChatIn, request: Request,
               p: Principal = Depends(require("chat"))) -> StreamingResponse:
    """Proxy SSE tới agent, lưu hội thoại. Event đầu tiên: `conversation` {conversation_id}."""
    await hit("chat", p, settings.rl_chat_per_min)
    if not policy.can_use_agent(p.roles, name):
        await deny(request, p, "chat.start", f"Bạn không có quyền dùng agent '{name}'", "agent", name)
    async with SessionLocal() as db:
        ag = await db.get(Agent, name)
        if not ag:
            raise HTTPException(404, "Agent không tồn tại")
        if agent_status(ag) != "online":
            raise HTTPException(409, f"Agent '{name}' đang {agent_status(ag)}")
        conv = await db.get(Conversation, body.conversation_id) if body.conversation_id else None
        if conv is not None and (conv.created_by != p.sub or conv.agent != name):
            raise HTTPException(404, "Hội thoại không tồn tại")
        is_new = conv is None
        if conv is None:
            conv = Conversation(id=new_id("c"), agent=name, title=body.message[:80], created_by=p.sub)
            db.add(conv)
            await db.commit()
        history = (await db.execute(select(Message).where(Message.conversation_id == conv.id)
                                    .order_by(Message.id.desc()).limit(settings.chat_history_limit))).scalars().all()
        messages = [{"role": m.role, "content": m.content} for m in reversed(history) if m.role in ("user", "assistant")]
        messages.append({"role": "user", "content": body.message})
        db.add(Message(conversation_id=conv.id, role="user", content=body.message))
        await db.commit()
        endpoint, conv_id = ag.endpoint, conv.id
    if is_new:   # ghi audit khi bắt đầu hội thoại (không ghi nội dung tin nhắn)
        await record("chat.start", principal=p, resource_type="conversation", resource_id=conv_id,
                     request=request, details={"agent": name})

    async def gen() -> AsyncIterator[str]:
        yield f"event: conversation\ndata: {json.dumps({'conversation_id': conv_id})}\n\n"
        final, status, tool_calls, usage, error = "", "failed", [], {}, None
        headers = {"X-Agent-Token": settings.agent_api_token} if settings.agent_api_token else {}
        try:
            async with httpx.AsyncClient(timeout=httpx.Timeout(30, read=900)) as c:
                async with c.stream("POST", f"{endpoint}/v1/chat", headers=headers,
                                    json={"messages": messages, "stream": True, "conversation_id": conv_id,
                                          "user": p.sub}) as resp:
                    if resp.status_code != 200:
                        error = f"Agent trả về HTTP {resp.status_code}"
                        yield f"event: error\ndata: {json.dumps({'type': 'error', 'data': {'error': error}})}\n\n"
                    else:
                        data_lines: list[str] = []
                        async for line in resp.aiter_lines():
                            yield line + "\n"
                            if line.startswith("data:"):
                                data_lines.append(line[5:].strip())
                            elif line == "" and data_lines:
                                try:
                                    ev = json.loads("".join(data_lines))
                                except ValueError:
                                    ev = {}
                                data_lines = []
                                if ev.get("type") == "tool_call":
                                    tool_calls.append(ev["data"].get("name"))
                                elif ev.get("type") == "run_finished":
                                    d = ev.get("data", {})
                                    final, status = d.get("output", ""), d.get("status", "failed")
                                    usage, error = d.get("usage", {}), d.get("error")
        except httpx.HTTPError as exc:
            error = f"Mất kết nối tới agent: {exc}"
            yield f"event: error\ndata: {json.dumps({'type': 'error', 'data': {'error': error}})}\n\n"
        finally:
            async with SessionLocal() as db:
                db.add(Message(conversation_id=conv_id, role="assistant", content=final or (error or ""),
                               meta={"status": status, "tool_calls": tool_calls, "usage": usage, "error": error}))
                conv2 = await db.get(Conversation, conv_id)
                if conv2:
                    conv2.updated_at = utcnow()
                await db.commit()

    return StreamingResponse(gen(), media_type="text/event-stream",
                             headers={"Cache-Control": "no-cache", "X-Accel-Buffering": "no"})
