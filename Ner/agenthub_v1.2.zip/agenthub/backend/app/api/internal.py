"""API nội bộ cho agent container: đăng ký, heartbeat, báo cáo task.

Xác thực bằng X-Agent-Name + X-Internal-Token RIÊNG của từng agent (AGENT_TOKENS).
Agent chỉ được đăng ký / heartbeat cho chính nó và chỉ báo cáo task được giao cho chính nó.
"""
from __future__ import annotations

from typing import Any

from fastapi import APIRouter, Depends, HTTPException
from pydantic import BaseModel, Field
from sqlalchemy.ext.asyncio import AsyncSession

from ..db import get_session
from ..models import Agent, Task, utcnow
from ..security import current_agent
from ..models import WAITING
from ..services import add_event, finish_task, is_terminal, mark_waiting

router = APIRouter(prefix="/internal")


async def _own_task(db: AsyncSession, task_id: str, agent: str) -> Task:
    t = await db.get(Task, task_id)
    if t is None:
        raise HTTPException(404, "Task không tồn tại")
    if t.agent != agent:
        raise HTTPException(403, f"Task {task_id} không được giao cho agent '{agent}'")
    return t


class RegisterIn(BaseModel):
    name: str
    version: str = "0.0.0"
    description: str = ""
    endpoint: str
    tags: list[str] = Field(default_factory=list)
    card: dict[str, Any] = Field(default_factory=dict)
    model: dict[str, Any] = Field(default_factory=dict)
    skills: list[dict[str, Any]] = Field(default_factory=list)
    tools: list[str] = Field(default_factory=list)
    mcp_servers: list[dict[str, Any]] = Field(default_factory=list)
    limits: dict[str, Any] = Field(default_factory=dict)


@router.post("/agents/register")
async def register(body: RegisterIn, agent: str = Depends(current_agent),
                   db: AsyncSession = Depends(get_session)) -> dict[str, Any]:
    if body.name != agent:
        raise HTTPException(403, f"Agent '{agent}' không được đăng ký thay cho '{body.name}'")
    a = await db.get(Agent, body.name)
    if a is None:
        a = Agent(name=body.name)
        db.add(a)
    for field in ("version", "description", "endpoint", "tags", "card", "model", "skills", "tools",
                  "mcp_servers", "limits"):
        setattr(a, field, getattr(body, field))
    a.last_heartbeat = utcnow()
    await db.commit()
    return {"ok": True}


class HeartbeatIn(BaseModel):
    mcp_servers: list[dict[str, Any]] | None = None


@router.post("/agents/{name}/heartbeat")
async def heartbeat(name: str, body: HeartbeatIn, agent: str = Depends(current_agent),
                    db: AsyncSession = Depends(get_session)) -> dict[str, Any]:
    if name != agent:
        raise HTTPException(403, "Chỉ được gửi heartbeat cho chính mình")
    a = await db.get(Agent, name)
    if a is None:
        raise HTTPException(404, "Chưa đăng ký")
    a.last_heartbeat = utcnow()
    if body.mcp_servers is not None:
        a.mcp_servers = body.mcp_servers
    await db.commit()
    return {"ok": True}


@router.post("/tasks/{task_id}/start")
async def start(task_id: str, agent: str = Depends(current_agent),
                db: AsyncSession = Depends(get_session)) -> dict[str, Any]:
    t = await _own_task(db, task_id, agent)
    if is_terminal(t.status) or t.status == WAITING:
        raise HTTPException(409, f"Task đang ở trạng thái {t.status}")
    redelivered = t.status == "running"     # worker trước bị mất => chạy lại (at-least-once)
    t.status = "running"
    t.started_at = utcnow()
    await db.commit()
    await add_event(db, task_id, "task_status", {"status": "running", "redelivered": redelivered})
    return t.to_dict()


RESERVED_EVENT_TYPES = {"task_status", "approval_submitted", "cancel_requested"}


class EventsIn(BaseModel):
    events: list[dict[str, Any]]


@router.post("/tasks/{task_id}/events")
async def events(task_id: str, body: EventsIn, agent: str = Depends(current_agent),
                 db: AsyncSession = Depends(get_session)) -> dict[str, Any]:
    await _own_task(db, task_id, agent)
    for ev in body.events[:100]:
        etype = str(ev.get("type", "event"))[:32]
        if etype in RESERVED_EVENT_TYPES:          # agent không được giả sự kiện do backend phát
            etype = f"agent_{etype}"[:32]
        await add_event(db, task_id, etype, ev.get("data") or {})
    return {"ok": True}


class CompleteIn(BaseModel):
    status: str
    result: str = ""
    error: str | None = None
    usage: dict[str, Any] = Field(default_factory=dict)
    steps: int = 0
    duration_ms: int = 0
    interrupt: dict[str, Any] | None = None


@router.post("/tasks/{task_id}/complete")
async def complete(task_id: str, body: CompleteIn, agent: str = Depends(current_agent),
                   db: AsyncSession = Depends(get_session)) -> dict[str, Any]:
    t = await _own_task(db, task_id, agent)
    if is_terminal(t.status) and t.status != "cancelled":
        return t.to_dict()  # idempotent
    if body.status == WAITING and t.status != "cancelled":
        await mark_waiting(db, t, body.interrupt or {}, usage=body.usage, steps=body.steps,
                           duration_ms=body.duration_ms)
        return t.to_dict()
    status = body.status if body.status in ("succeeded", "failed", "cancelled") else "failed"
    if t.meta and "resume" in t.meta:
        t.meta = {k: v for k, v in t.meta.items() if k != "resume"}
    await finish_task(db, t, status, result=body.result, error=body.error, usage=body.usage,
                      steps=body.steps, duration_ms=body.duration_ms)
    return t.to_dict()
