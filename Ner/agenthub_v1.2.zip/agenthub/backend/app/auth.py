"""Xác thực — biến 1 bearer token thành Principal.

Hỗ trợ (chọn bằng AUTH_MODE = static | oidc | both):
  * Static token / API key  : so sánh SHA-256 bằng hmac.compare_digest (không lưu khoá dạng rõ trong file).
  * OIDC JWT                 : Keycloak, Microsoft Entra ID, ADFS, Okta… — kiểm tra chữ ký qua JWKS,
                               iss, aud, exp, nbf; chỉ nhận thuật toán bất đối xứng đã khai báo.
  * JWT HS256                : token do token broker nội bộ phát hành (vd. MCP Tool Platform) với secret chung.

Vai trò lấy từ claim (realm_access.roles, roles, groups…) rồi ÁNH XẠ qua OIDC_ROLE_MAP.
Không ánh xạ ngầm "admin" -> admin: vai trò của ứng dụng khác trong cùng IdP không tự có quyền ở AgentHub.
"""
from __future__ import annotations

import asyncio
import hashlib
import hmac
import logging
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Iterable

import jwt
import yaml

from .authz import Principal
from .config import AuthConfig

log = logging.getLogger("backend.auth")


class AuthError(Exception):
    """Token thiếu / sai / hết hạn. Thông điệp an toàn để trả cho client."""


def sha256_hex(value: str) -> str:
    return hashlib.sha256(value.encode("utf-8")).hexdigest()


@dataclass(frozen=True)
class StaticCredential:
    name: str
    token_sha256: str
    roles: frozenset[str]
    kind: str = "user"
    agent: str | None = None
    source: str = "static"


def parse_static_tokens(spec: str, known_roles: Iterable[str]) -> list[StaticCredential]:
    """API_TOKENS="tên:token:vai_trò1|vai_trò2[:agent],..."  — dùng cho dev hoặc service account đơn giản.

    Tương thích ngược "tên:token": nếu tên trùng vai trò thì dùng vai trò đó, ngược lại là operator.
    Có `:agent` => service account gắn với agent đó (kind=service).
    """
    known = set(known_roles)
    out: list[StaticCredential] = []
    for item in [x.strip() for x in (spec or "").split(",") if x.strip()]:
        parts = item.split(":")
        if len(parts) < 2 or not parts[0] or not parts[1]:
            log.warning("Bỏ qua mục API_TOKENS sai định dạng (cần tên:token[:roles[:agent]])")
            continue
        name, token = parts[0], parts[1]
        roles = [r for r in (parts[2].split("|") if len(parts) > 2 and parts[2] else []) if r]
        if not roles:
            roles = [name] if name in known else ["operator"]
        bad = [r for r in roles if r not in known]
        if bad:
            log.warning("Token '%s' có vai trò không tồn tại trong policy: %s (bỏ qua)", name, bad)
        agent = parts[3] if len(parts) > 3 and parts[3] else None
        out.append(StaticCredential(name=name, token_sha256=sha256_hex(token),
                                    roles=frozenset(r for r in roles if r in known),
                                    kind="service" if agent else "user", agent=agent))
    return out


def load_api_keys_file(path: str, known_roles: Iterable[str]) -> list[StaticCredential]:
    """File YAML: danh sách {name, sha256, roles, kind?, agent?, disabled?}. Tạo bằng scripts/gen_api_key.py."""
    p = Path(path)
    if not path or not p.is_file():
        return []
    known = set(known_roles)
    data = yaml.safe_load(p.read_text(encoding="utf-8")) or []
    out: list[StaticCredential] = []
    for i, e in enumerate(data.get("keys", data) if isinstance(data, dict) else data):
        if e.get("disabled"):
            continue
        h = str(e.get("sha256", "")).lower()
        if len(h) != 64:
            log.warning("api_keys[%d]: sha256 không hợp lệ — bỏ qua", i)
            continue
        roles = frozenset(r for r in e.get("roles") or [] if r in known)
        agent = e.get("agent") or None
        out.append(StaticCredential(name=str(e["name"]), token_sha256=h, roles=roles,
                                    kind=e.get("kind") or ("service" if agent else "user"),
                                    agent=agent, source="api_key"))
    return out


def _claim(claims: dict[str, Any], path: str) -> Any:
    cur: Any = claims
    for part in path.split("."):
        if not isinstance(cur, dict) or part not in cur:
            return None
        cur = cur[part]
    return cur


def extract_roles(claims: dict[str, Any], claim_paths: Iterable[str], role_map: dict[str, str],
                  known_roles: Iterable[str]) -> frozenset[str]:
    known = set(known_roles)
    found: set[str] = set()
    for path in claim_paths:
        val = _claim(claims, path)
        if isinstance(val, str):
            val = val.split()
        if isinstance(val, (list, tuple)):
            for v in val:
                mapped = role_map.get(str(v)) or role_map.get(str(v).lstrip("/"))
                if mapped and mapped in known:
                    found.add(mapped)
    return frozenset(found)


class Authenticator:
    def __init__(self, cfg: AuthConfig, known_roles: Iterable[str]):
        self.cfg = cfg
        self.known_roles = set(known_roles)
        self.mode = cfg.mode if cfg.mode in ("static", "oidc", "both") else "static"
        self.credentials = (parse_static_tokens(cfg.static_tokens, self.known_roles)
                            + load_api_keys_file(cfg.api_keys_file, self.known_roles))
        self._jwk_client: jwt.PyJWKClient | None = None
        self._jwks_url = cfg.oidc_jwks_url
        if self.mode in ("oidc", "both") and not cfg.oidc_issuer and not cfg.jwt_hs256_secret:
            raise ValueError("AUTH_MODE=oidc/both cần OIDC_ISSUER (hoặc JWT_HS256_SECRET cho token broker)")
        if cfg.jwt_hs256_secret and len(cfg.jwt_hs256_secret.encode()) < 32:
            log.warning("JWT_HS256_SECRET ngắn hơn 32 byte — nên dùng secret ngẫu nhiên >= 32 byte (RFC 7518 §3.2)")
        if any(c.source == "static" and not c.agent and "admin" in c.roles for c in self.credentials):
            log.warning("Đang có static token vai trò admin — chỉ nên dùng cho dev; production dùng OIDC / API key file")

    # ------------------------------------------------------------------ public
    def summary(self) -> dict[str, Any]:
        return {"mode": self.mode, "static_credentials": len(self.credentials),
                "oidc_issuer": self.cfg.oidc_issuer or None, "audience": self.cfg.oidc_audience or None}

    async def authenticate(self, token: str) -> Principal:
        token = (token or "").strip()
        if not token:
            raise AuthError("Thiếu token")
        if self.mode in ("oidc", "both") and token.count(".") == 2:
            return await self._verify_jwt(token)
        if self.mode in ("static", "both"):
            p = self._lookup_static(token)
            if p is not None:
                return p
        raise AuthError("Token không hợp lệ")

    # ------------------------------------------------------------------ static / API key
    def _lookup_static(self, token: str) -> Principal | None:
        digest = sha256_hex(token)
        match: StaticCredential | None = None
        for c in self.credentials:                  # duyệt hết danh sách: thời gian không phụ thuộc vị trí khoá
            if hmac.compare_digest(digest, c.token_sha256):
                match = c
        if match is None:
            return None
        return Principal(sub=match.name, name=match.name, roles=match.roles, kind=match.kind,
                         auth=match.source, agent=match.agent)

    # ------------------------------------------------------------------ JWT
    def _jwks(self) -> jwt.PyJWKClient:
        if self._jwk_client is None:
            url = self._jwks_url
            if not url:                              # OIDC discovery
                import json
                import urllib.request
                disc = self.cfg.oidc_issuer.rstrip("/") + "/.well-known/openid-configuration"
                with urllib.request.urlopen(disc, timeout=10) as r:   # noqa: S310 - URL do admin cấu hình
                    url = json.loads(r.read())["jwks_uri"]
                self._jwks_url = url
            self._jwk_client = jwt.PyJWKClient(url, cache_keys=True, lifespan=600, timeout=10)
        return self._jwk_client

    async def _verify_jwt(self, token: str) -> Principal:
        try:
            header = jwt.get_unverified_header(token)
        except jwt.PyJWTError as exc:
            raise AuthError("JWT không đọc được") from exc
        alg = header.get("alg", "")
        # Chặn alg=none và tấn công nhầm thuật toán (dùng public key làm secret HS256)
        if alg == "HS256" and self.cfg.jwt_hs256_secret:
            key: Any = self.cfg.jwt_hs256_secret
        elif alg in self.cfg.oidc_algorithms and alg != "HS256":
            try:
                key = (await asyncio.to_thread(self._jwks().get_signing_key_from_jwt, token)).key
            except jwt.PyJWKClientError as exc:
                raise AuthError("Không tìm thấy khoá ký phù hợp (kid)") from exc
            except Exception as exc:  # noqa: BLE001 - mạng / IdP lỗi
                log.error("Không lấy được JWKS: %s", exc)
                raise AuthError("Không kiểm tra được token (IdP không phản hồi)") from exc
        else:
            raise AuthError(f"Thuật toán ký '{alg}' không được chấp nhận")
        aud = self.cfg.oidc_audience or None
        try:
            claims = jwt.decode(
                token, key, algorithms=[alg], audience=aud, issuer=self.cfg.oidc_issuer or None,
                leeway=self.cfg.oidc_leeway_s,
                options={"require": ["exp", "sub"] + (["iss"] if self.cfg.oidc_issuer else []),
                         "verify_aud": aud is not None},
            )
        except jwt.ExpiredSignatureError as exc:
            raise AuthError("Token đã hết hạn") from exc
        except jwt.InvalidAudienceError as exc:
            raise AuthError("Token không dành cho AgentHub (aud sai)") from exc
        except jwt.InvalidIssuerError as exc:
            raise AuthError("Token do nguồn không tin cậy phát hành (iss sai)") from exc
        except jwt.PyJWTError as exc:
            raise AuthError("Token không hợp lệ") from exc

        roles = extract_roles(claims, self.cfg.oidc_role_claims, self.cfg.oidc_role_map, self.known_roles)
        username = str(claims.get("preferred_username") or "")
        kind = "service" if username.startswith("service-account-") or claims.get("agenthub_kind") == "service" else "user"
        name = next((str(claims[c]) for c in self.cfg.oidc_name_claims if claims.get(c)), str(claims["sub"]))
        return Principal(sub=str(claims["sub"]), name=name, roles=roles, kind=kind,
                         auth="oidc" if alg != "HS256" else "jwt", email=claims.get("email"),
                         agent=claims.get("agenthub_agent"))
