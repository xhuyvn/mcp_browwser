"""Rate limit theo người dùng (cửa sổ cố định 1 phút, đếm bằng Redis INCR).

Redis lỗi => cho qua (fail-open) và ghi cảnh báo: rate limit là lớp bảo vệ phụ, không được làm sập API.
"""
from __future__ import annotations

import logging
import time

from fastapi import HTTPException, status

from .authz import Principal
from .services import bus

log = logging.getLogger("backend.ratelimit")


async def hit(bucket: str, p: Principal, limit_per_min: int) -> None:
    if limit_per_min <= 0:
        return
    now = time.time()
    window = int(now // 60)
    key = f"agenthub:rl:{bucket}:{p.sub}:{window}"
    try:
        r = bus().r
        n = await r.incr(key)
        if n == 1:
            await r.expire(key, 70)
    except Exception as exc:  # noqa: BLE001
        log.warning("Rate limit tạm tắt (Redis lỗi): %s", exc)
        return
    if n > limit_per_min:
        retry = max(1, 60 - int(now % 60))
        raise HTTPException(status.HTTP_429_TOO_MANY_REQUESTS,
                            f"Quá nhiều yêu cầu ({bucket}): tối đa {limit_per_min}/phút. Thử lại sau {retry} giây.",
                            headers={"Retry-After": str(retry)})
