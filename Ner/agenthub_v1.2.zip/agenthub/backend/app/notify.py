"""Thông báo khi có task chờ phê duyệt (mới / nhắc lại / hết hạn).

Kênh:
  * In-app : UI đọc GET /api/approvals (badge + trang "Chờ duyệt") — luôn bật.
  * Webhook: NOTIFY_WEBHOOK_URL
      - NOTIFY_WEBHOOK_FORMAT=slack   -> {"text": "..."}  (Slack, Mattermost, Google Chat nhận dạng này)
      - NOTIFY_WEBHOOK_FORMAT=generic -> JSON đầy đủ + header X-AgentHub-Signature: sha256=<HMAC>
Payload KHÔNG chứa tham số tool (nội dung file có thể nhạy cảm) — chỉ có tên tool và link tới UI.
"""
from __future__ import annotations

import asyncio
import hashlib
import hmac
import json
import logging
from typing import Any

import httpx

from .config import settings

log = logging.getLogger("backend.notify")
_background: set[asyncio.Task] = set()

TITLES = {
    "approval.required": "⏸ Cần phê duyệt",
    "approval.reminder": "⏰ Nhắc: vẫn đang chờ phê duyệt",
    "approval.expired": "⌛ Hết hạn phê duyệt",
}


def build_payload(event: str, *, task_id: str, agent: str, tools: list[str], approver_roles: list[str],
                  created_by_name: str | None, extra: dict[str, Any] | None = None) -> dict[str, Any]:
    return {
        "event": event, "task_id": task_id, "agent": agent, "tools": tools,
        "approver_roles": approver_roles, "requested_by": created_by_name,
        "url": f"{settings.public_ui_url}/tasks/{task_id}", **(extra or {}),
    }


def render(payload: dict[str, Any]) -> tuple[bytes, dict[str, str]]:
    if settings.notify_webhook_format == "slack":
        title = TITLES.get(payload["event"], payload["event"])
        text = (f"*{title}* — agent `{payload['agent']}` muốn chạy: {', '.join(payload['tools'])}\n"
                f"Người yêu cầu: {payload.get('requested_by') or '—'} · Ai được duyệt: "
                f"{', '.join(payload['approver_roles'])}\n<{payload['url']}|Mở task {payload['task_id']}>")
        if payload.get("action"):
            text += f"\nTự động: {payload['action']}"
        body = json.dumps({"text": text}, ensure_ascii=False).encode()
    else:
        body = json.dumps(payload, ensure_ascii=False).encode()
    headers = {"Content-Type": "application/json", "User-Agent": "AgentHub-Notifier/1.2"}
    if settings.notify_webhook_secret:
        sig = hmac.new(settings.notify_webhook_secret.encode(), body, hashlib.sha256).hexdigest()
        headers["X-AgentHub-Signature"] = f"sha256={sig}"
    return body, headers


async def _send(payload: dict[str, Any]) -> None:
    body, headers = render(payload)
    for attempt in range(3):
        try:
            async with httpx.AsyncClient(timeout=5) as c:
                r = await c.post(settings.notify_webhook_url, content=body, headers=headers)
            if r.status_code < 400:
                return
            log.warning("Webhook trả %s (lần %d)", r.status_code, attempt + 1)
        except httpx.HTTPError as exc:
            log.warning("Webhook lỗi (lần %d): %s", attempt + 1, exc)
        await asyncio.sleep(2 ** attempt)


def notify(payload: dict[str, Any]) -> None:
    """Gửi nền (không chặn request của agent)."""
    log.info("notify %s task=%s tools=%s", payload["event"], payload["task_id"], payload["tools"])
    if not settings.notify_webhook_url:
        return
    t = asyncio.create_task(_send(payload))
    _background.add(t)
    t.add_done_callback(_background.discard)
