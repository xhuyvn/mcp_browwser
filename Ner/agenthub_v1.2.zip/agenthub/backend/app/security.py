"""FastAPI dependencies cho xác thực & phân quyền.

  current_principal   → Principal của người gọi (401 nếu thiếu / sai token)
  require("perm")     → kiểm tra permission (403 + ghi audit nếu bị từ chối)
  current_agent       → tên agent đang gọi API nội bộ (token RIÊNG cho từng agent)
"""
from __future__ import annotations

import hmac
import logging

from fastapi import Depends, Header, HTTPException, Query, Request, status

from .audit import record
from .auth import Authenticator, AuthError
from .authz import Policy, Principal
from .config import settings

log = logging.getLogger("backend.security")

policy = Policy.load(settings.policy_file)
authenticator = Authenticator(settings.auth, policy.known_roles())


def _bearer(authorization: str | None) -> str:
    if authorization and authorization[:7].lower() == "bearer ":
        return authorization[7:].strip()
    return ""


async def current_principal(
    request: Request,
    authorization: str | None = Header(default=None),
    token: str | None = Query(default=None, include_in_schema=False),
) -> Principal:
    raw = _bearer(authorization) or (token if settings.allow_query_token and token else "")
    if not raw:
        raise HTTPException(status.HTTP_401_UNAUTHORIZED, "Thiếu header Authorization: Bearer <token>",
                            headers={"WWW-Authenticate": "Bearer"})
    try:
        p = await authenticator.authenticate(raw)
    except AuthError as exc:
        # 401 chỉ ghi log (không ghi DB) để kẻ tấn công không làm phình bảng audit
        log.info("401 %s %s from %s: %s", request.method, request.url.path,
                 request.client.host if request.client else "-", exc)
        raise HTTPException(status.HTTP_401_UNAUTHORIZED, str(exc), headers={"WWW-Authenticate": "Bearer"}) from None
    request.state.principal = p
    return p


def require(*perms: str):
    """Dependency: người gọi phải có TẤT CẢ permission liệt kê."""
    async def dep(request: Request, p: Principal = Depends(current_principal)) -> Principal:
        missing = [x for x in perms if not policy.has(p, x)]
        if missing:
            await deny(request, p, f"perm:{','.join(missing)}", "Bạn không có quyền: " + ", ".join(missing))
        return p
    return dep


async def deny(request: Request, p: Principal, action: str, message: str,
               resource_type: str = "", resource_id: str = "") -> None:
    await record(action, principal=p, outcome="deny", resource_type=resource_type, resource_id=resource_id,
                 request=request, details={"reason": message, "path": request.url.path})
    raise HTTPException(status.HTTP_403_FORBIDDEN, message)


async def current_agent(
    request: Request,
    x_internal_token: str | None = Header(default=None),
    x_agent_name: str | None = Header(default=None),
) -> str:
    """Mỗi agent có token riêng (AGENT_TOKENS) => agent bị chiếm quyền không giả mạo được agent khác."""
    name = (x_agent_name or "").strip()
    token = x_internal_token or ""
    if settings.agent_tokens:
        expected = settings.agent_tokens.get(name, "")
        ok = bool(expected) and hmac.compare_digest(token, expected)
    else:
        ok = bool(settings.internal_token) and hmac.compare_digest(token, settings.internal_token)
    if not ok or not name:
        log.warning("Internal 401 agent=%s path=%s", name or "-", request.url.path)
        raise HTTPException(status.HTTP_401_UNAUTHORIZED, "Internal token không hợp lệ")
    return name
