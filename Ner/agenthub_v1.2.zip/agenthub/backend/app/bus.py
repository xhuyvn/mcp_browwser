"""Redis: hàng đợi task (Streams), fan-out sự kiện realtime (Pub/Sub), cờ huỷ task."""
from __future__ import annotations

import json
import logging
from typing import Any

import redis.asyncio as aioredis

log = logging.getLogger("backend.bus")


def task_stream(agent: str) -> str:
    return f"agenthub:tasks:{agent}"


def event_channel(task_id: str) -> str:
    return f"agenthub:events:{task_id}"


class Subscription:
    def __init__(self, pubsub: Any, channel: str):
        self.pubsub = pubsub
        self.channel = channel

    async def get(self, timeout: float = 15.0) -> dict[str, Any] | None:
        msg = await self.pubsub.get_message(ignore_subscribe_messages=True, timeout=timeout)
        if not msg or msg.get("type") != "message":
            return None
        try:
            return json.loads(msg["data"])
        except (TypeError, ValueError):
            return None

    async def close(self) -> None:
        try:
            await self.pubsub.unsubscribe(self.channel)
            await self.pubsub.aclose()
        except Exception:  # noqa: BLE001
            pass


class Bus:
    def __init__(self, url: str):
        self.r = aioredis.from_url(url, decode_responses=True)

    async def ping(self) -> bool:
        try:
            return bool(await self.r.ping())
        except Exception:  # noqa: BLE001
            return False

    async def enqueue(self, agent: str, task_id: str) -> str:
        return await self.r.xadd(task_stream(agent), {"task_id": task_id}, maxlen=100_000, approximate=True)

    async def queue_depth(self, agent: str) -> int:
        """Số task chưa được worker nhận (lag) + đang xử lý (pending)."""
        stream = task_stream(agent)
        try:
            for g in await self.r.xinfo_groups(stream):
                if g.get("name") == "workers":
                    return int(g.get("lag") or 0) + int(g.get("pending") or 0)
            return int(await self.r.xlen(stream))
        except Exception:  # noqa: BLE001 - stream chưa tồn tại
            return 0

    async def publish(self, task_id: str, event: dict[str, Any]) -> None:
        try:
            await self.r.publish(event_channel(task_id), json.dumps(event, ensure_ascii=False, default=str))
        except Exception as exc:  # noqa: BLE001
            log.warning("publish lỗi: %s", exc)

    async def subscribe(self, task_id: str) -> Subscription:
        pubsub = self.r.pubsub()
        await pubsub.subscribe(event_channel(task_id))
        return Subscription(pubsub, event_channel(task_id))

    async def request_cancel(self, task_id: str) -> None:
        await self.r.set(f"agenthub:cancel:{task_id}", "1", ex=86_400)

    async def aclose(self) -> None:
        await self.r.aclose()
