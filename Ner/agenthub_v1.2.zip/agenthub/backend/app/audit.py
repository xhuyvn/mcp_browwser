"""Nhật ký audit: ai — làm gì — trên tài nguyên nào — được phép hay bị từ chối.

Ghi 2 nơi: bảng `audit_log` (tra cứu trên UI / API) và logger "agenthub.audit" dạng JSON một dòng
(chuyển sang SIEM bằng log shipper). Không ghi nội dung tin nhắn / tham số tool nhạy cảm.
"""
from __future__ import annotations

import json
import logging
from typing import TYPE_CHECKING, Any

from .db import SessionLocal
from .models import AuditLog, utcnow

if TYPE_CHECKING:
    from fastapi import Request

    from .authz import Principal

log = logging.getLogger("backend.audit")
audit_log = logging.getLogger("agenthub.audit")


async def record(action: str, *, principal: "Principal | None" = None, actor: dict[str, Any] | None = None,
                 outcome: str = "allow", resource_type: str = "", resource_id: str = "",
                 request: "Request | None" = None, details: dict[str, Any] | None = None) -> None:
    who = principal.audit_actor() if principal is not None else (actor or {"sub": "system", "kind": "system"})
    ip = request.client.host if request is not None and request.client else None
    ua = request.headers.get("user-agent", "")[:200] if request is not None else None
    entry = {"ts": utcnow().isoformat(), "action": action, "outcome": outcome, "actor": who,
             "resource": {"type": resource_type, "id": resource_id}, "ip": ip, "details": details or {}}
    audit_log.info(json.dumps(entry, ensure_ascii=False, default=str))
    try:
        async with SessionLocal() as db:
            db.add(AuditLog(actor_sub=str(who.get("sub", ""))[:128], actor_name=str(who.get("name", ""))[:200],
                            actor_kind=str(who.get("kind", ""))[:16], action=action[:64], outcome=outcome[:16],
                            resource_type=resource_type[:32], resource_id=resource_id[:64], ip=ip, user_agent=ua,
                            details={**(details or {}), "roles": who.get("roles", [])}))
            await db.commit()
    except Exception as exc:  # noqa: BLE001 - audit lỗi không được làm hỏng request chính
        log.error("Không ghi được audit vào DB: %s", exc)
