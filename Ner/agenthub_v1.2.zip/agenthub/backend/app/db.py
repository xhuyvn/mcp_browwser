"""SQLAlchemy 2.0 async — PostgreSQL (asyncpg) cho production, SQLite (aiosqlite) cho dev."""
from __future__ import annotations

from pathlib import Path

from sqlalchemy.ext.asyncio import AsyncSession, async_sessionmaker, create_async_engine
from sqlalchemy.orm import DeclarativeBase

from .config import settings


class Base(DeclarativeBase):
    pass


if settings.database_url.startswith("sqlite"):
    Path("./data").mkdir(exist_ok=True)

engine = create_async_engine(settings.database_url, pool_pre_ping=True, future=True)
SessionLocal = async_sessionmaker(engine, expire_on_commit=False, class_=AsyncSession)


async def get_session():
    async with SessionLocal() as session:
        yield session


async def init_db() -> None:
    from . import models  # noqa: F401  - đăng ký bảng
    async with engine.begin() as conn:
        # Production: dùng Alembic migration; create_all đủ cho demo / lần chạy đầu
        await conn.run_sync(Base.metadata.create_all)
