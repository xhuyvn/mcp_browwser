"""AgentHub Control Plane — FastAPI."""
from __future__ import annotations

import asyncio
import logging
import os
from contextlib import asynccontextmanager

from fastapi import FastAPI, Request
from fastapi.middleware.cors import CORSMiddleware

from .api import internal, public
from .bus import Bus
from .config import settings
from .db import SessionLocal, init_db
from .security import authenticator, policy
from .services import maintain_approvals, reap_stale_tasks, state

logging.basicConfig(level=os.environ.get("LOG_LEVEL", "INFO"),
                    format="%(asctime)s %(levelname)s %(name)s: %(message)s")
log = logging.getLogger("backend")


async def _reaper() -> None:
    while True:
        await asyncio.sleep(60)
        try:
            async with SessionLocal() as db:
                n = await reap_stale_tasks(db)
                if n:
                    log.warning("Đã đánh dấu %d task treo là failed", n)
                st = await maintain_approvals(db)
                if any(st.values()):
                    log.info("Phê duyệt: nhắc %(reminded)d, hết hạn %(expired)d", st)
        except Exception as exc:  # noqa: BLE001
            log.warning("Reaper lỗi: %s", exc)


@asynccontextmanager
async def lifespan(_app: FastAPI):
    await init_db()
    state.bus = Bus(settings.redis_url)
    log.info("Auth: %s | roles: %s | maker-checker: %s | agent tokens riêng: %s",
             authenticator.summary(), sorted(policy.roles), policy.maker_checker, bool(settings.agent_tokens))
    if not settings.agent_tokens:
        log.warning("AGENT_TOKENS chưa cấu hình — mọi agent dùng chung INTERNAL_TOKEN (chỉ nên dùng cho dev)")
    if settings.allow_query_token:
        log.warning("ALLOW_QUERY_TOKEN=true — token có thể lộ vào access log / lịch sử trình duyệt")
    reaper = asyncio.create_task(_reaper())
    try:
        yield
    finally:
        reaper.cancel()
        await state.bus.aclose()


app = FastAPI(title="AgentHub Control Plane", version="1.2.0", lifespan=lifespan,
              docs_url="/docs" if settings.enable_docs else None,
              redoc_url=None, openapi_url="/openapi.json" if settings.enable_docs else None)
app.add_middleware(CORSMiddleware, allow_origins=settings.cors_origins, allow_credentials=False,
                   allow_methods=["GET", "POST", "PATCH"], allow_headers=["Authorization", "Content-Type"])


@app.middleware("http")
async def security_headers(request: Request, call_next):
    resp = await call_next(request)
    resp.headers.setdefault("X-Content-Type-Options", "nosniff")
    resp.headers.setdefault("X-Frame-Options", "DENY")
    resp.headers.setdefault("Referrer-Policy", "no-referrer")
    if request.url.path.startswith("/api/"):
        resp.headers.setdefault("Cache-Control", "no-store")
    return resp


app.include_router(public.router)
app.include_router(internal.router)


@app.get("/healthz")
async def healthz() -> dict:
    return {"status": "ok", "redis": await state.bus.ping() if state.bus else False}
