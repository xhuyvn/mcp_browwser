#!/usr/bin/env python3
"""Sinh API key ngẫu nhiên + dòng YAML (chỉ chứa SHA-256) cho config/api_keys.yaml.

  python backend/scripts/gen_api_key.py --name ci-bot --roles operator
  python backend/scripts/gen_api_key.py --name svc-orchestrator --roles delegator --agent orchestrator

Khoá chỉ hiện MỘT lần — lưu vào secret manager. Mất khoá: tạo khoá mới, đặt disabled: true cho khoá cũ.
"""
import argparse
import hashlib
import secrets

ap = argparse.ArgumentParser()
ap.add_argument("--name", required=True)
ap.add_argument("--roles", required=True, help="vd. operator hoặc approver,operator")
ap.add_argument("--agent", default="", help="gắn service account với 1 agent (vd. orchestrator)")
a = ap.parse_args()
key = "ahk_" + secrets.token_urlsafe(32)
digest = hashlib.sha256(key.encode()).hexdigest()
roles = ", ".join(r.strip() for r in a.roles.split(",") if r.strip())
print("API key (chỉ hiện 1 lần):", key)
print("\nThêm vào config/api_keys.yaml:")
print(f"  - name: {a.name}\n    sha256: \"{digest}\"\n    roles: [{roles}]" + (f"\n    agent: {a.agent}" if a.agent else ""))
