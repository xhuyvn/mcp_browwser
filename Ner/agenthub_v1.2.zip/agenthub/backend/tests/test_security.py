"""Test phân quyền & xác thực (không cần DB / Redis).

  cd backend && pip install -r requirements.txt pytest && python -m pytest -q tests
"""
from __future__ import annotations

import asyncio
import json
import threading
import time
from pathlib import Path

import jwt
import pytest
from cryptography.hazmat.primitives.asymmetric import rsa
from jwt.algorithms import RSAAlgorithm

from app.auth import Authenticator, AuthError, sha256_hex
from app.authz import DEFAULT_POLICY, Policy, PolicyError, Principal, sanitize_task_metadata
from app.config import AuthConfig

ROOT = Path(__file__).resolve().parents[2]
POL = Policy(DEFAULT_POLICY)
alice = Principal("alice", "Alice", frozenset({"operator"}))
bob = Principal("bob", "Bob", frozenset({"approver", "operator"}))
dave = Principal("dave", "Dave", frozenset({"viewer"}))
carol = Principal("carol", "Carol", frozenset({"admin"}))
svc = Principal("svc-orchestrator", "svc", frozenset({"delegator"}), kind="service", agent="orchestrator")


# ----------------------------------------------------------------- authz
def test_policy_file_matches_default():
    pf = Policy.load(str(ROOT / "config" / "policy.yaml"))
    assert all(pf.role_permissions(r) == POL.role_permissions(r) for r in POL.roles)


def test_permissions_and_visibility():
    assert POL.has(alice, "tasks:create") and not POL.has(dave, "tasks:create")
    assert POL.can_view_task(alice, "alice") and not POL.can_view_task(alice, "bob")
    assert POL.can_view_task(dave, "anyone")                      # viewer xem mọi task
    assert POL.can_cancel_task(alice, "alice") and not POL.can_cancel_task(alice, "bob")
    assert POL.can_cancel_task(carol, "bob")


@pytest.mark.parametrize("who,creator,ok", [
    (bob, "alice", True),        # checker duyệt việc của maker
    (bob, "bob", False),         # maker-checker: không tự duyệt
    (alice, "carol", False),     # operator không có tasks:approve
    (dave, "alice", False),
    (carol, "alice", True),      # admin
    (svc, "alice", False),       # service account không bao giờ được duyệt
])
def test_approval_matrix(who, creator, ok):
    assert POL.check_approval(who, agent="writer", tools=["fs__write_file"], creator=creator)[0] is ok


def test_approval_rules_per_tool():
    assert not POL.check_approval(bob, agent="writer", tools=["db__drop"], creator="alice")[0]   # chỉ admin
    assert POL.approver_roles("writer", ["fs__write_file"]) == ["admin", "approver"]
    assert POL.approver_roles("writer", ["fs__write_file", "db__drop"]) == ["admin"]


def test_delegation_cannot_escalate():
    ok = POL.check_delegation(svc, parent_agent="orchestrator", parent_status="running",
                              root_roles={"operator"}, target_agent="writer")
    assert ok[0]
    assert not POL.check_delegation(svc, parent_agent="researcher", parent_status="running",
                                    root_roles={"operator"}, target_agent="writer")[0]
    assert not POL.check_delegation(svc, parent_agent="orchestrator", parent_status="running",
                                    root_roles={"viewer"}, target_agent="writer")[0]   # gốc là viewer
    assert not POL.check_delegation(svc, parent_agent="orchestrator", parent_status="succeeded",
                                    root_roles={"operator"}, target_agent="writer")[0]
    assert not POL.check_delegation(alice, parent_agent="orchestrator", parent_status="running",
                                    root_roles={"operator"}, target_agent="writer")[0]


def test_agent_access_specificity():
    p = Policy({"roles": {"operator": {"permissions": ["chat"]}, "fin": {"permissions": ["chat"]}},
                "agent_access": {"*": ["operator"], "finance-*": ["fin"], "finance-report": ["fin", "operator"]}})
    assert not p.can_use_agent({"operator"}, "finance-x") and p.can_use_agent({"fin"}, "finance-x")
    assert p.can_use_agent({"operator"}, "finance-report") and p.can_use_agent({"operator"}, "writer")


@pytest.mark.parametrize("bad", [
    {"roles": {"x": {"permissions": ["nope"]}}},
    {"roles": {"a": {"inherits": ["b"]}, "b": {"inherits": ["a"]}}},
    {"roles": {"a": {"permissions": ["chat"]}}, "agent_access": {"*": ["ghost"]}},
])
def test_invalid_policy_rejected(bad):
    with pytest.raises(PolicyError):
        Policy(bad)


def test_reserved_metadata_stripped():
    assert sanitize_task_metadata({"resume": {"approved": True}, "created_by_name": "x", "foo": 1}) == {"foo": 1}


# ----------------------------------------------------------------- static tokens / API keys
def test_static_tokens_and_api_keys(tmp_path):
    keys = tmp_path / "keys.yaml"
    keys.write_text(json.dumps({"keys": [{"name": "ci", "sha256": sha256_hex("k1"), "roles": ["operator"]},
                                         {"name": "old", "sha256": sha256_hex("k2"), "roles": ["admin"],
                                          "disabled": True}]}))
    a = Authenticator(AuthConfig(mode="static", api_keys_file=str(keys),
                                 static_tokens="svc:t-svc:delegator:orchestrator,legacy:t-old"), POL.known_roles())
    p = asyncio.run(a.authenticate("t-svc"))
    assert p.kind == "service" and p.agent == "orchestrator" and p.roles == {"delegator"}
    assert asyncio.run(a.authenticate("t-old")).roles == {"operator"}
    assert asyncio.run(a.authenticate("k1")).auth == "api_key"
    for bad in ("k2", "nope", ""):
        with pytest.raises(AuthError):
            asyncio.run(a.authenticate(bad))


# ----------------------------------------------------------------- OIDC JWT
ISS = "http://localhost:8081/realms/agenthub"
KEY = rsa.generate_private_key(public_exponent=65537, key_size=2048)


@pytest.fixture(scope="module")
def jwks_url():
    import uvicorn
    from starlette.applications import Starlette
    from starlette.responses import JSONResponse
    from starlette.routing import Route
    jwk = json.loads(RSAAlgorithm.to_jwk(KEY.public_key()))
    jwk.update({"kid": "k1", "use": "sig", "alg": "RS256"})

    async def certs(_):
        return JSONResponse({"keys": [jwk]})
    srv = uvicorn.Server(uvicorn.Config(Starlette(routes=[Route("/certs", certs)]), host="127.0.0.1",
                                        port=18766, log_level="warning"))
    threading.Thread(target=srv.run, daemon=True).start()
    for _ in range(100):
        if srv.started:
            break
        time.sleep(0.05)
    yield "http://127.0.0.1:18766/certs"
    srv.should_exit = True


def _auth(jwks: str) -> Authenticator:
    return Authenticator(AuthConfig(mode="both", oidc_issuer=ISS, oidc_audience="agenthub-api", oidc_jwks_url=jwks,
                                    oidc_role_map={"agenthub-approver": "approver", "agenthub-operator": "operator"},
                                    jwt_hs256_secret="x" * 40), POL.known_roles())


def _tok(**over):
    now = int(time.time())
    c = {"iss": ISS, "aud": "agenthub-api", "sub": "uuid-bob", "exp": now + 300, "iat": now, "name": "Bob",
         "realm_access": {"roles": ["agenthub-approver", "agenthub-operator", "admin"]}}
    c.update(over)
    return jwt.encode(c, KEY, algorithm="RS256", headers={"kid": "k1"})


def test_oidc_valid_token_maps_roles(jwks_url):
    p = asyncio.run(_auth(jwks_url).authenticate(_tok()))
    assert p.sub == "uuid-bob" and p.roles == {"approver", "operator"}       # "admin" của IdP KHÔNG được map
    assert p.auth == "oidc" and p.kind == "user"


@pytest.mark.parametrize("over", [{"exp": 1}, {"aud": "other"}, {"iss": "https://evil/realms/x"}])
def test_oidc_rejects_bad_claims(jwks_url, over):
    with pytest.raises(AuthError):
        asyncio.run(_auth(jwks_url).authenticate(_tok(**over)))


def test_oidc_rejects_alg_none_and_foreign_key(jwks_url):
    a = _auth(jwks_url)
    with pytest.raises(AuthError):
        asyncio.run(a.authenticate(jwt.encode({"sub": "x", "iss": ISS, "exp": int(time.time()) + 60}, None, algorithm="none")))
    other = rsa.generate_private_key(public_exponent=65537, key_size=2048)
    forged = jwt.encode({"sub": "x", "iss": ISS, "aud": "agenthub-api", "exp": int(time.time()) + 60}, other,
                        algorithm="RS256", headers={"kid": "k1"})
    with pytest.raises(AuthError):
        asyncio.run(a.authenticate(forged))
