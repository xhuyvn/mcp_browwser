#!/usr/bin/env bash
# Demo qua REST API: giao task, stream timeline (SSE), lấy kết quả.
set -euo pipefail
API=${API:-http://localhost:8000}
TOKEN=${API_TOKEN:-dev-operator-token}     # alice (operator)
AGENT=${1:-researcher}
INPUT=${2:-"Giờ hiện tại ở Hà Nội và Tokyo là mấy giờ? Tìm 1 tin công nghệ AI mới nhất kèm link."}
H=(-H "Authorization: Bearer $TOKEN" -H "Content-Type: application/json")

echo "== Agents =="
curl -s "${H[@]}" "$API/api/agents" | python3 -c 'import sys,json;[print(f"- {a[\"name\"]:<13} {a[\"status\"]}") for a in json.load(sys.stdin)]'

echo "== Giao task cho $AGENT =="
TASK_ID=$(curl -s "${H[@]}" -X POST "$API/api/tasks" \
  -d "$(python3 -c 'import json,sys;print(json.dumps({"agent":sys.argv[1],"input":sys.argv[2],"source":"api"}))' "$AGENT" "$INPUT")" \
  | python3 -c 'import sys,json;print(json.load(sys.stdin)["id"])')
echo "Task: $TASK_ID"

echo "== Timeline (SSE) =="
curl -sN -H "Authorization: Bearer $TOKEN" "$API/api/tasks/$TASK_ID/stream" |   # token ở header, không đặt trên URL while IFS= read -r line; do
  case "$line" in
    event:\ end) break ;;
    event:*) printf '%s ' "${line#event: }" ;;
    data:*) echo "${line#data: }" | cut -c1-160 ;;
  esac
done

echo "== Kết quả =="
curl -s "${H[@]}" "$API/api/tasks/$TASK_ID" | python3 -c 'import sys,json;t=json.load(sys.stdin);print(t["status"]);print(t["result"] or t["error"])'
