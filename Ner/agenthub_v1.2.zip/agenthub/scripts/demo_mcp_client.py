#!/usr/bin/env python3
"""Demo: quản lý agent HOÀN TOÀN qua MCP (server agent-manager) — liệt kê agent, giao task,
theo dõi tiến độ và nhận kết quả. Đây cũng chính là bộ tool mà agent Orchestrator sử dụng.

  pip install "mcp>=1.23,<2"
  python scripts/demo_mcp_client.py                 # chạy cả 3 kịch bản
  python scripts/demo_mcp_client.py researcher      # chỉ kịch bản 1
  AUTO_APPROVE=1 python scripts/demo_mcp_client.py  # tự duyệt tool ghi file của writer (không hỏi)

Writer chạy engine LangGraph: trước khi ghi file, task chuyển sang `waiting_input` và script hỏi bạn
có cho phép không. Có maker-checker nên script dùng 2 danh tính (2 phiên MCP):
  API_TOKEN      người giao việc  (mặc định alice / operator)
  APPROVER_TOKEN người duyệt      (mặc định bob / approver) — người tạo task KHÔNG được tự duyệt.
Cũng có thể duyệt trên UI: đăng nhập bằng token / tài khoản của người duyệt, mở trang "Chờ duyệt".
"""
from __future__ import annotations

import asyncio
import json
import os
import sys
import time

from mcp import ClientSession
from mcp.client.streamable_http import streamablehttp_client

URL = os.environ.get("AGENT_MANAGER_MCP_URL", "http://localhost:8090/mcp")
TOKEN = os.environ.get("API_TOKEN", "dev-operator-token")
APPROVER_TOKEN = os.environ.get("APPROVER_TOKEN", "dev-approver-token")
APPROVER: dict = {}                       # phiên MCP thứ 2, mang danh người duyệt
TERMINAL = {"succeeded", "failed", "cancelled"}
AUTO_APPROVE = os.environ.get("AUTO_APPROVE", "").lower() in ("1", "true", "yes")


def parse(res) -> object:
    sc = getattr(res, "structuredContent", None)
    if sc is not None:
        return sc.get("result", sc) if isinstance(sc, dict) and set(sc) == {"result"} else sc
    texts = [c.text for c in res.content if getattr(c, "type", "") == "text"]
    items = []
    for t in texts:
        try:
            items.append(json.loads(t))
        except ValueError:
            items.append(t)
    return items[0] if len(items) == 1 else items


async def call(s: ClientSession, tool: str, **args) -> object:
    res = await s.call_tool(tool, args)
    if res.isError:
        raise RuntimeError(f"{tool} lỗi: {parse(res)}")
    return parse(res)


async def handle_approvals(s: ClientSession, root_id: str) -> None:
    """Đóng vai NGƯỜI DÙNG: duyệt các tool đang chờ của task gốc và task con (human-in-the-loop)."""
    waiting = await call(s, "list_tasks", status="waiting_input", limit=20)
    waiting = waiting if isinstance(waiting, list) else [waiting]
    for t in waiting:
        if not t or (t.get("id") != root_id and t.get("parent_id") != root_id):
            continue
        pa = t.get("pending_approval") or {}
        print(f"\n  ⏸ Task {t['id']} [{t['agent']}] chờ duyệt: {pa.get('message', '')}")
        for c in pa.get("calls", []):
            args = json.dumps(c.get("arguments"), ensure_ascii=False)
            print(f"     🔧 {c['name']} {args[:300]}{'…' if len(args) > 300 else ''}")
        if AUTO_APPROVE:
            ok, comment = True, "auto-approve (demo)"
        else:
            ans = (await asyncio.to_thread(input, "     Cho phép? [y/N/ghi chú để từ chối]: ")).strip()
            ok, comment = ans.lower() in ("y", "yes", "c", "co", "có"), ("" if ans.lower() in ("y", "yes", "n", "") else ans)
        try:
            await call(APPROVER["s"], "approve_task", task_id=t["id"], approved=ok, comment=comment)
            print(f"     → {'ĐÃ DUYỆT' if ok else 'ĐÃ TỪ CHỐI'} (bởi người duyệt)")
        except RuntimeError as exc:          # vd. 403 maker-checker / không đủ vai trò
            print(f"     ⚠ Không duyệt được: {exc}")


async def run_and_wait(s: ClientSession, agent: str, instruction: str, timeout: int = 900) -> dict:
    task = await call(s, "assign_task", agent=agent, instruction=instruction)
    root_id = task["id"]
    print(f"  → Đã giao task {root_id} cho {agent} (status={task['status']})")
    t0 = time.time()
    while True:
        task = await call(s, "wait_for_task", task_id=root_id, timeout_seconds=15)
        print(f"    … {int(time.time() - t0)}s  status={task['status']}")
        await handle_approvals(s, root_id)
        if task["status"] in TERMINAL or time.time() - t0 > timeout:
            break
    info = await call(s, "get_task", task_id=root_id, include_events=True)
    tools_used = [e["data"].get("name") for e in info.get("events", []) if e["type"] == "tool_call"]
    print(f"  ✓ {task['status']} · tools: {', '.join(t for t in tools_used if t) or '(không)'}")
    if info.get("children"):
        print("  Task con:")
        for c in info["children"]:
            print(f"    - {c['id']} [{c['agent']}] {c['status']}")
    print("\n" + (task.get("result") or task.get("error") or "") + "\n")
    return task


async def main(which: str = "all") -> None:
    print(f"Kết nối MCP agent-manager: {URL}")
    async with streamablehttp_client(URL, headers={"Authorization": f"Bearer {TOKEN}"},
                                     timeout=30, sse_read_timeout=900) as (read, write, _), \
            streamablehttp_client(URL, headers={"Authorization": f"Bearer {APPROVER_TOKEN}"},
                                  timeout=30, sse_read_timeout=900) as (read2, write2, _2):
        async with ClientSession(read, write) as s, ClientSession(read2, write2) as approver:
            await s.initialize()
            await approver.initialize()
            APPROVER["s"] = approver
            tools = await s.list_tools()
            print("Tools:", ", ".join(t.name for t in tools.tools))

            agents = await call(s, "list_agents")
            agents = agents if isinstance(agents, list) else [agents]
            print("\nAgents:")
            for a in agents:
                print(f"  - {a['name']:<13} {a['status']:<8} skills={a['skills']} mcp={a['mcp_servers']}")

            if which in ("all", "researcher"):
                print("\n=== Kịch bản 1: giao task cho RESEARCHER (MCP: duckduckgo + fetch) ===")
                r1 = await run_and_wait(s, "researcher",
                    "Tìm 3 điểm khác nhau chính giữa Ollama và OpenRouter khi dùng làm backend LLM "
                    "OpenAI-compatible cho AI agent. Trả về Markdown ngắn, mỗi ý có URL nguồn.")
            else:
                r1 = {"result": "Ollama chạy local; OpenRouter là gateway cloud nhiều model."}

            if which in ("all", "writer"):
                print("\n=== Kịch bản 2: giao task cho WRITER (MCP: filesystem + memory) ===")
                await run_and_wait(s, "writer",
                    "Viết báo cáo ngắn 'Ollama vs OpenRouter cho AI agent' từ ghi chú sau và lưu vào "
                    "/workspace/reports. Trả về đường dẫn file.\n\nGHI CHÚ:\n" + (r1.get("result") or ""))

            if which in ("all", "orchestrator"):
                print("\n=== Kịch bản 3: ORCHESTRATOR tự điều phối researcher + writer qua MCP ===")
                await run_and_wait(s, "orchestrator",
                    "Nghiên cứu các thay đổi chính của đặc tả Model Context Protocol (MCP) mới nhất, "
                    "sau đó viết báo cáo Markdown lưu vào /workspace/reports. Trả về tóm tắt và đường dẫn file.",
                    timeout=1500)


if __name__ == "__main__":
    asyncio.run(main(sys.argv[1] if len(sys.argv) > 1 else "all"))
